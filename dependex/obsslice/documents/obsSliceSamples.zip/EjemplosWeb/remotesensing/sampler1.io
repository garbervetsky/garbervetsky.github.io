Input:{}
Output:{{SAMPLEV1},{STOREV1}}

