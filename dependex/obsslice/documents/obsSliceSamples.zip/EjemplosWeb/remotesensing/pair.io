Input:{{UPPAIR}}
Output:{{V1V2PAIRED},{ip}}

