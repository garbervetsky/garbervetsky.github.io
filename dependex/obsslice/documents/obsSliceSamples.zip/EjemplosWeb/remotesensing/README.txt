remoteBR Example:

There are 2 network specification files: 

remoteBR.esp: network with observer whose property is not satisfied
remoteBR_HIT.esp: network with observer whose property is not satisfied

To run the tool:

java obsslice -openkronos -uppaal -d sliced remoteBR.esp 

or java obsslice -openkronos -uppaal -d sliced remoteBR_HIT.esp 

wil write the obssliced  files in folder 'sliced' and generate the corresponding OPENKRONOS and UPPAAL files. 


To generate the non-reduced system in UPPAAL in the current directory do:

java uppaal.UPPAALTranslator . remoteBR.esp

or java uppaal.UPPAALTranslator . remoteBR_HIT.esp


To generate the non-reduced exp file for OPENKRONOS in the current directory do:

java openkronos.ExpGenerator -e remoteBR.esp > remoteBR.exp

or java openkronos.ExpGenerator -e remoteBR_HIT.esp > remoteBR_HIT.exp


In the remoteBR and sliced directory you will find the reachability properties for UPPAAL and OPENKRONOS.

For UPPAAL: remoteBR.q and remoteBR_HIT.q
For OPENKRONOS: error10.acc and error10_HIT.acc