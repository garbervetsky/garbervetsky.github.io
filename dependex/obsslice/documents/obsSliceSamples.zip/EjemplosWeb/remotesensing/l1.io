Input:{{RQSTARRIVESATS1},{i1}}
Output:{{UPR1}}