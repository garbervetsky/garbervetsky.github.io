Input:{{RQSTARRIVESATS2},{i2}}
Output:{{UPR2}}