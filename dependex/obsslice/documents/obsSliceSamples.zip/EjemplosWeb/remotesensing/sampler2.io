Input:{}
Output:{{SAMPLEV2},{STOREV2}}

