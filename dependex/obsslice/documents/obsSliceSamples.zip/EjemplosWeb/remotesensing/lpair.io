Input:{{V1ARRIVES},{V2ARRIVES},{ip}}
Output:{{UPPAIR}}
