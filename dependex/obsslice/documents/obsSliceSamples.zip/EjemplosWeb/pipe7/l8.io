input: { {i8} , {S8} }
output: { {up8} }