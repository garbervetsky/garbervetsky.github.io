input: { {up7} }
output: { {S8},{i7} }