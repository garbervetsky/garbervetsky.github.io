input: { {S1},{S2},{S3},{S4},{S5},{S6},{S7},{S8},
         {up1} ,{up2} ,{up3} ,{up4} ,{up5} ,{up6},{up7} }
output: {  }