input: { {i7} , {S7} }
output: { {up7} }