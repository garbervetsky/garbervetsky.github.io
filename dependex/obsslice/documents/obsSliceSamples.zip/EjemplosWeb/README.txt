ObsSlice Examples. 

Each example is stored in different folders and contains a 'README' file with running explanations. 

Details:

Fddi10 is an extension of the FDDI token Model ring protocol  where the observer monitors the time
the token takes to return to a given station.

Pipe6 and Pipe7 are pipe-lines of sporadic processes that forward a signal emitted by a quasi periodic source [1] (6 and 7 stages
resp.). The observer captures a scenario violating an end-to-end constraint for signal propagation. 

RemoteBR is a design composed of a central component and two remote sensors. When the central component needs sampled data, it broadcasts a request to the sensors. Each sensor handles requests by reading the last stored value by the sampler and sending it back to the central component. There, the readings are paired for further processing. The observer captures scenarios where a request for collecting a pair of data items is not fully answered in less than a
given amount of time. 

Minepump is a design of a fault-detection mechanism for a distributed mine-drainage controller [8]. A watchdog task periodically checks the availability of a water level sensor device by sending a request and extracting acks that were received and queued during the previous cycle by another sporadic task. When the watchdog finds the queue empty, it registers a fault condition in a shared memory which is periodically read, and forwarded to a remote console, by a proxy task. The observer checks if the failure of high-low water sensor is always informed to the remote operator before a given deadline.

Struct is an adaptation of a well-know working design: the active structural control system  that limits structural vibration due to earthquakes or strong winds. The pulse-control algorithm is mapped into two tasks: the Modeler and the Pulser. The Modeler is a sporadic task
which, once initialized,  serves the messages arriving from the sensor. Then, it updates in a predictive fashion a model stored in a shared protected object Model and starts a new communication with the sensor to be served in the next invocation. The Pulser periodically (110 time units (t.u.)) reads the model, calculates the pulse magnitude and starts a communication with the actuator (which in  turn will expand to counteract external forces). The sampling takes
within 50 and 55 t.u., then the data is prepared within 10 t.u. The actuator applies the pulse for a duration within 25 to 30 t.u., and then data is prepared for communication (10.  t.u. aswell). The Comm component models handshake communication where it takes within 3 and 5 t.u. to perform the communication (message and acknowledgement).








