input: { {up5} }
output: { {S6},{i5} }