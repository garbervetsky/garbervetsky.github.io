input: {}
output: { {S1} }