input: { {i5} , {S5} }
output: { {up5} }