input: { {up6} }
output: { {S7},{i6} }