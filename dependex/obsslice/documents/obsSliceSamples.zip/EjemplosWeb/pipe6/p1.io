input: { {up1} }
output: { {S2},{i1} }