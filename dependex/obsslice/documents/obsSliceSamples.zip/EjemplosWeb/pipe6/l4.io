input: { {i4} , {S4} }
output: { {up4} }