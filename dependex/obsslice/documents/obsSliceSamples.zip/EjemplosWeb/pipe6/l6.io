input: { {i6} , {S6} }
output: { {up6} }