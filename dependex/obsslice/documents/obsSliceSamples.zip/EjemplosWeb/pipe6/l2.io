input: { {i2} , {S2} }
output: { {up2} }