input: { {up4} }
output: { {S5},{i4} }