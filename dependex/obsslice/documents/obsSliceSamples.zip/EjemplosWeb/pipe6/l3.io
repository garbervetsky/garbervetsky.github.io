input: { {i3} , {S3} }
output: { {up3} }