E<> observer6.L14
