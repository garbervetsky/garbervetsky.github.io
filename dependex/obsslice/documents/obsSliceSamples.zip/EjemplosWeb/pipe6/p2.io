input: { {up2} }
output: { {S3},{i2} }