pipe6 Example:

There are 2 network specification files: 

pipe6_f120.esp: network with observer whose property is not satisfied
pipe6_f40.esp: network with observer whose property is not satisfied

To run the tool:

java obsslice -openkronos -uppaal -d sliced pipe6_f120.esp 

or java obsslice -openkronos -uppaal -d sliced pipe6_f40.esp 

wil write the obssliced  files in folder 'sliced' and generate the corresponding OPENKRONOS and UPPAAL files. 


To generate the non-reduced system in UPPAAL in the current directory do:

java uppaal.UPPAALTranslator . pipe6_f120.esp

or java uppaal.UPPAALTranslator . pipe6_f40.esp


To generate the non-reduced exp file for OPENKRONOS in the current directory do:

java openkronos.ExpGenerator -e pipe6_f120.esp > pipe6_f120.exp

or java openkronos.ExpGenerator -e pipe6_f40.esp > pipe6_f40.exp


In the pipe6 and sliced directory you will find the reachability properties for UPPAAL and OPENKRONOS.

For UPPAAL: pipe6.q 
For OPENKRONOS: error6.acc 