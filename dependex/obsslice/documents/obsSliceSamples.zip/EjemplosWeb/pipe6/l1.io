input: { {i1} , {S1} }
output: { {up1} }