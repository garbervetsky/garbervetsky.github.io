input: { {up3} }
output: { {S4},{i3} }