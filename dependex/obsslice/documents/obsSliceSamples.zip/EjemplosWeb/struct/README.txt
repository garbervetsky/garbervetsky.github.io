STRUCT Example:

There are 2 network specification files: 

struct.esp: network with observer whose property is not satisfied
struct_HIT.esp: network with observer whose property is not satisfied

To run the tool:

java obsslice -openkronos -uppaal -d sliced struct.esp 

or java obsslice -openkronos -uppaal -d sliced struct_HIT.esp 

wil write the obssliced  files in folder 'sliced' and generate the corresponding OPENKRONOS and UPPAAL files. 


To generate the non-reduced system in UPPAAL in the current directory do:

java uppaal.UPPAALTranslator . struct.esp

or java uppaal.UPPAALTranslator . struct_HIT.esp


To generate the non-reduced exp file for OPENKRONOS in the current directory do:

java openkronos.ExpGenerator -e struct.esp > struct.exp

or java openkronos.ExpGenerator -e struct_HIT.esp > struct_HIT.exp


In the struct and sliced directory you will find the reachability properties for UPPAAL and OPENKRONOS.

For UPPAAL: struct.q and struct_HIT.q
For OPENKRONOS: error10.acc and error10_HIT.acc