input: { {actuatorReadyforComm},{PulserReadyforComm} }
output: { { PulseReceived } } 