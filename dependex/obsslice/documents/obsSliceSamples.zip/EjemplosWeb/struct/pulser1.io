input: { }
output: { {PulserReadyforComm},{ModelRead} } 