input: { {modelupdated},{modelread},{pulserreadyforcomm},
         {pulsereceived},{pulse},{datareceived} }
output: { } 