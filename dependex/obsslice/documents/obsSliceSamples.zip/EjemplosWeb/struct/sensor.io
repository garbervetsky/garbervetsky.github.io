input: { {datareceived} }
output: { {SensorReadyforComm} } 