input: { { DataReceived }  }
output: { {ModelerReadyforComm},{ModelUpdated} } 