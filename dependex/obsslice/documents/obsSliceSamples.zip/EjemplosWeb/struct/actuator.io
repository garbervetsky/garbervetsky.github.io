input: { {pulsereceived} }
output: { {pulse},{actuatorreadyforcomm } } 