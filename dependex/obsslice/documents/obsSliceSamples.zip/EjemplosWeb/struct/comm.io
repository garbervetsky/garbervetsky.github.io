input: { {ModelerReadyforComm},{sensorReadyforComm} }
output: { { DataReceived } } 