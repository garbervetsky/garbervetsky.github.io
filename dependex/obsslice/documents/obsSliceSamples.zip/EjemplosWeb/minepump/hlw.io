input: {{ackrequest}}
output:{{ack},{fault},{recover}}

