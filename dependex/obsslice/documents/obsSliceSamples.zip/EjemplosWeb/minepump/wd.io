input: {}
output:{{AckQueueExtractedOK,AckQueueExtractedNOK},{ackrequest},{alarmadded}}
