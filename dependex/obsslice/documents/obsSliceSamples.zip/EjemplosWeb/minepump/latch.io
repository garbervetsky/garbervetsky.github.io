input:{{CnetReceived},{DispReady}}
output:{{wakeup}}
