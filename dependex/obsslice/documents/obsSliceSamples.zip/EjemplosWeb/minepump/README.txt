MINEPUMP Example:

There are 2 network specification files: 

mine.esp: network with observer whose property is not satisfied
mine_HIT.esp: network with observer whose property is not satisfied

To run the tool:

java obsslice -openkronos -uppaal -d sliced mine.esp 

or java obsslice -openkronos -uppaal -d sliced mine_HIT.esp 

wil write the obssliced  files in folder 'sliced' and generate the corresponding OPENKRONOS and UPPAAL files. 


To generate the non-reduced system in UPPAAL in the current directory do:

java uppaal.UPPAALTranslator . mine.esp

or java uppaal.UPPAALTranslator . mine_HIT.esp


To generate the non-reduced exp file for OPENKRONOS in the current directory do:

java openkronos.ExpGenerator -e mine.esp > mine.exp

or java openkronos.ExpGenerator -e mine_HIT.esp > mine_HIT.exp


In the mine and sliced directory you will find the reachability properties for UPPAAL and OPENKRONOS.

For UPPAAL: mine.q and mine_HIT.q
For OPENKRONOS: error10.acc and error10_HIT.acc