input: {{recover},{fault},{Cnetsent},{CnetReceived},{DataDisplayed},{wakeup},{pkgget},{alarmadded}}
output: {}
