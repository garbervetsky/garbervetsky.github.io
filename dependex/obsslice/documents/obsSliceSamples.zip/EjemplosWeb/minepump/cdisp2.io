input:{{wakeup}}
output:{{DataDisplayed},{DispReady}}
