input:{{AckQueueWritten},{AckQueueExtractedOK,AckQueueExtractedNOK}}
output:{}
