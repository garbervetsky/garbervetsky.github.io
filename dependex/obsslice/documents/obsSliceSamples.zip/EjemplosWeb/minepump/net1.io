input: {{CnetSent}}
output: {{CnetReceived}}


