input: {{TT9}}
output:{{RT9},{P09, P19}}
