input: {{TT2}}
output:{{RT2},{P02, P12}}

