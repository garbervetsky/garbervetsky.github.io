input: {{TT7}}
output:{{RT7},{P07, P17}}

