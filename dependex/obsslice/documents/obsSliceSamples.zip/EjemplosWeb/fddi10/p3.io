input: {{P03, P13}}
output: {}
