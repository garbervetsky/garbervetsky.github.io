input: {{TT8}}
output:{{RT8},{P08, P18}}

