
input:{ {RT1}, {RT2},{RT3},{RT4},{RT5},{RT6},{RT7},{RT8},{RT9},{RT10} }
output: {{TT1}, {TT2},{TT3},{TT4},{TT5},{TT6},{TT7},{TT8},{TT9},{TT10} }        