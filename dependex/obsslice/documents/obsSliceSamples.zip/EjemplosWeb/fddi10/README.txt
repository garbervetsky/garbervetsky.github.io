FDDI10 Example:

There are 2 network specification files: 

fddi10.esp: network with observer whose property is not satisfied
fddi10_HIT.esp: network with observer whose property is not satisfied

To run the tool:

java obsslice -openkronos -uppaal -d sliced fddi10.esp 

or java obsslice -openkronos -uppaal -d sliced fddi10_HIT.esp 

wil write the obssliced  files in folder 'sliced' and generate the corresponding OPENKRONOS and UPPAAL files. 


To generate the non-reduced system in UPPAAL in the current directory do:

java uppaal.UPPAALTranslator . fddi10.esp

or java uppaal.UPPAALTranslator . fddi10_HIT.esp


To generate the non-reduced exp file for OPENKRONOS in the current directory do:

java openkronos.ExpGenerator -e fddi10.esp > fddi10.exp

or java openkronos.ExpGenerator -e fddi10_HIT.esp > fddi10_HIT.exp


In the fddi10 and sliced directory you will find the reachability properties for UPPAAL and OPENKRONOS.

For UPPAAL: fddi10.q and fddi10_HIT.q
For OPENKRONOS: error10.acc and error10_HIT.acc