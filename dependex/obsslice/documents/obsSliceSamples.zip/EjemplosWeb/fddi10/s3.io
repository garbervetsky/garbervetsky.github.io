input: {{TT3}}
output:{{RT3},{P03, P13}}
