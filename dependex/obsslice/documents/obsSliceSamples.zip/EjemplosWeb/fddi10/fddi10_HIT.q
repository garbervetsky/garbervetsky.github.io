E<>observer10_HIT.L21
