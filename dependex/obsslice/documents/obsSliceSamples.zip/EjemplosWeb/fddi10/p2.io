input: {{P02, P12}}
output: {}
