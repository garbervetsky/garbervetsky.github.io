
input: {{P01, P11}}
output: {}
