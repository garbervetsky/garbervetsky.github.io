input: {{P07, P17}}
output: {}
