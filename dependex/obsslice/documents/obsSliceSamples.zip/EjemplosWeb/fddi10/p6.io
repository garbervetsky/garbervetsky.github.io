input: {{P06, P16}}
output: {}
