input: {{P08, P18}}
output: {}
