input: {{P010, P110}}
output: {}
