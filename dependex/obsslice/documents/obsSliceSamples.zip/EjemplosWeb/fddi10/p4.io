input: {{P04, P14}}
output: {}
