input: {{TT1}}
output:{{RT1},{P01, P11}}
