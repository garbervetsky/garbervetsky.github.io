input: {{TT10}}
output:{{RT10},{P010, P110}}

