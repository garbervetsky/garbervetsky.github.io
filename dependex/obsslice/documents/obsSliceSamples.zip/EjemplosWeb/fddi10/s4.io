input: {{TT4}}
output:{{RT4},{P04, P14}}

