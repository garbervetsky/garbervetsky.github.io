input: {{TT6}}
output:{{RT6},{P06, P16}}

