input: {{P09, P19}}
output: {}
