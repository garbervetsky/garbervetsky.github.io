input: {{TT5}}
output:{{RT5},{P05, P15}}

