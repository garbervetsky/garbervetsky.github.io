input: {{P05, P15}}
output: {}
