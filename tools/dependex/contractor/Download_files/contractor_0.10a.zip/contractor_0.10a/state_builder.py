# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from fsm import *
from formulae import *
from provers import *
from transition_builder import *

# creates the fsm states for the given contract and removes the unsound ones
def build_states(fsm, contract, options):

	# action sets
	action_sets = [[x for (pos,x) in zip(range(len(contract.action_names())), contract.action_names()) if (2**pos) & switches] for switches in range(2**len(contract.action_names()))]

	# create a state for each action set
	state_id = 1
	for action_set in action_sets:
		state = State()
		state.name = state_id
		state_id += 1
	
		# calculate state invariant and fill enabled actions
		for action_name in contract.action_names():
			action = contract.get_action(action_name)
			pre = cvc_close_expression(action.pre, action.parameters)
			state.invariant += " AND "
			if not (action_name in action_set):
				state.invariant += "NOT "
			else:
				state.enabled_actions.append(action)
			state.invariant += "(" + pre + ")"
		fsm.states.append(state)

	# check if each state is sound
	unsound_states = []
	contract_cvc = contract.cvc()
	for state in fsm.states:
		cvc = contract_cvc + cvc_assert(state.invariant) + cvc_check_satisfiability("TRUE")
		if call_prover(cvc, options) != "sat":
			unsound_states.append(state)

	for state in unsound_states:
		fsm.states.remove(state)

# incorporate initial state into FSM and deal with constructors
def build_initial_state(fsm, contract, options):
	# create initial state
	initial_state = State()
	initial_state.name = 0
	initial_state.enabled_actions = contract.constructors

	# deal with constructors
	build_transitions(fsm, [initial_state], contract, options)

	# add initial state
	fsm.states.append(initial_state)	
	fsm.initial_state = initial_state.name
