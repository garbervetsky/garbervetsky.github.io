# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import xml.dom.minidom
import re
from contract import *

# parse an xml contract (it assumes that file exists and it is correct in structure)
def parse_contract(options):
	ret = Contract()
	
	x_doc = xml.dom.minidom.parse(options.file)
	x_system = find_elements(x_doc,"system")[0]

	# fetching attributes
	ret.name = remove_spaces(x_system.getAttribute("name")).capitalize()
	ret.invariant = x_system.getAttribute("invariant")

	# fetching variables
	x_vars = find_elements(x_system,"variable")
	for x_var in x_vars:
		var = parse_variable(x_var)
		ret.variables.append(var)
		
	# fetching constructors
	x_constructors = find_elements(x_system,"constructor")
	for x_constructor in x_constructors:
		constructor = parse_action(x_constructor, ret.var_names())
		ret.constructors.append(constructor)
		
	# fetching actions
	x_actions = find_elements(x_system,"action")
	for x_action in x_actions:
		action = parse_action(x_action, ret.var_names())
		ret.actions.append(action)
		
	return ret
	
# find children with a given name in an xml structure
def find_elements(doc, elementName):
    ret = []
    for e in doc.childNodes:
        if e.nodeType == e.ELEMENT_NODE and e.localName == elementName:
            ret.append(e)
    return ret
    
# parse a variable xml element
def parse_variable(x_var):
	ret = Variable()
	ret.name = remove_spaces(x_var.getAttribute("name"))
	ret.type = x_var.getAttribute("type")
	return ret
	
# parse an action xml element
def parse_action(x_action, var_names):
	ret = Action()
	ret.name = uncapitalize(remove_spaces(x_action.getAttribute("name")))
	ret.pre = x_action.getAttribute("pre")
	ret.post = x_action.getAttribute("post")
	for x_param in find_elements(x_action,"parameter"):
		par = parse_variable(x_param)
		ret.parameters.append(par)
	for var_name in var_names:
		finder = re.compile(r'\b' + var_name + "'")
		if finder.search(ret.post) != None:
			ret.mod_vars.append(var_name)
	return ret
	
# aux: remove spaces from a name
def remove_spaces(string):
	return string.replace(" ","_")

# aux: uncapitalize a string (first character is lower-cased)
def uncapitalize(string):
	return string[0].lower() + string[1:]
