# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import sys
from subprocess import *

def call_prover(contents, options):
	# which prover to use?
	if options.prover == "cvc3":
		command = options.cvc3_path + " -output-lang smtlib"
	else:
		command = options.cvc3_path + " -output-lang smtlib +translate | " + options.yices_path + " -smt"
	
	# call prover
	p = Popen(command, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
	p.stdin.write(contents)
	p.stdin.close()
	out = p.stdout.readline()
	err = p.stderr.readline()

	# check the presence of errors
	if err != "":
		sys.stderr.write("Prover quitted with errors, check the contract syntax. Error was:\n")
		
		while True:
			sys.stderr.write(err)
			err = p.stderr.readline()
			if err == "":
				 break
		sys.exit(-1)

	# verbose unknown results
	if options.verbose and "unknown" in out:
		sys.stderr.write("Warning! 'unknown' response from prover\n")
	
	# strip and return results
	return out.strip()
