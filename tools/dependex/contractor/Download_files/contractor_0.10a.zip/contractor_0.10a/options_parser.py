# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from optparse import OptionParser
from os.path import exists
from utils import which

about_str = "Copyright (C) 2008 G. de Caso, V. Braberman, D. Garbervetsky, S. Uchitel\n{gdecaso, vbraber, diegog, suchitel}@dc.uba.ar\nLaFHIS - Departamento de Computación - FCEyN - Universidad de Buenos Aires\nPabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina\nTel: +54-11-4576-3390 eext. 704\n\nThis program comes with ABSOLUTELY NO WARRANTY; for details check the GNU General Public License in http://www.gnu.org/licenses/gpl-3.0.txt"

# parser options
parser = OptionParser(usage="%prog [options] file", version="%prog 0.10a\n" + about_str)
format_choices="graphviz ltsa"
parser.add_option("-f", "--output-format",
				action="store", type="string", dest="output_format", default="ltsa",
				help="select the format of results to FORMAT [default: %default; options: "+format_choices+"]", metavar="FORMAT")
parser.add_option("--separator",
				action="store", type="string", dest="separator", default="\\n",
				help="(for graphviz output only) use SEP as separator between multiple actions in the same edge [default: %default]", metavar="SEP")
parser.add_option("--print-state-numbers",
				action="store_true", dest="print_state_numbers", default=False,
				help="(for graphviz output only) print state numbers [default: %default]")
parser.add_option("-o", "--output-file",
				action="store", type="string", dest="output_file", default=None,
				help="write results to FILE [default: stdout]", metavar="FILE")
parser.add_option("-v", "--verbose",
				action="store_true", dest="verbose", default=False,
				help="print status messages to stderr [default: %default]")
prover_choices="cvc3 yices"
parser.add_option("-p", "--prover",
				action="store", type="string", dest="prover", default="cvc3",
				help="use prover PROVER [default: %default; options: "+prover_choices+"]", metavar="PROVER")
parser.add_option("--cvc3-path",
				action="store", type="string", dest="cvc3_path", default="cvc3",
				help="set PATH as the location of the CVC3 prover [default: %default]", metavar="PATH")
parser.add_option("--yices-path",
				action="store", type="string", dest="yices_path", default="yices",
				help="set PATH as the location of the Yices prover [default: %default]", metavar="PATH")

# begin parsing and generate errors if necessary
(options, args) = parser.parse_args()
if len(args) != 1:
	parser.error("incorrect number of arguments")
if not(options.output_format in format_choices.split()):
	parser.error("incorrect option of output format, must be one of: " + format_choices)
if not(options.prover in prover_choices.split()):
	parser.error("incorrect option of prover, must be one of: " + prover_choices)
if not(exists(args[0])):
	parser.error("file does not exist: " + args[0])
if which(options.cvc3_path) == None: # cvc3 is needed even when using yices (for translation purpouses)
	parser.error("could not find CVC3 prover at " + options.cvc3_path)
if options.prover == "yices" and which(options.yices_path) == None:
	parser.error("could not find Yices prover at " + options.yices_path)

# save input filename for further use
options.file = args[0]


