# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import re

# surround an expression with a quantifier for each of the variables
def cvc_close_expression(expression, variables, quant="EXISTS"):
	ret = expression
	for v in variables:
		if v.type != "BOOLEAN":
			ret = quant + " (" + v.name + ":" + v.type + "): (" + ret + ")"
		else:
			if quant == "EXISTS":
				op = "OR"
			else:
				op = "AND"
			ret = "(" + ret.replace(v.name,"TRUE") + ") " + op + " (" + ret.replace(v.name,"FALSE") + ")"
	return ret
	
# define the given variable (with the suffix on its name)
def cvc_define_variable(variable, suffix=""):
	return variable.name + suffix + " : " + variable.type + ";\n"

# assert the given expression
def cvc_assert(expression):
	return "ASSERT " + expression + ";\n"

# check satisfiability of the given expression	
def cvc_check_satisfiability(expression):
	return "PUSH;\n\tCHECKSAT " + expression + ";\nPOP;\n"
	
# check universal validity of the given expression
def cvc_check_validity(expression):
	return "PUSH;\n\tQUERY " + expression + ";\nPOP;\n"
	
# prime variables in an expression
def cvc_prime_variables(expression, variable_names):		
	ret = expression
	for variable_name in variable_names:
		replacer = re.compile(r'\b' + variable_name + r'\b')
		ret = replacer.sub(variable_name + "'", ret)
	return ret
	
	
