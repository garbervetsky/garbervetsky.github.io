# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class FSM:
	def __init__(self):
		self.states = []
		self.initial_state = None

	def get_state(self, state_name):
		for state in self.states:
			if state.name == state_name:
				return state

	def __str__(self):
		ret = ""
		for state in self.states:
			ret += str(state)
		ret += "initial state: " + str(self.initial_state) + "\n"
		return ret

class State:
	def __init__(self):
		self.name = ""
		self.invariant = "TRUE"
		self.transitions = []
		self.enabled_actions = []

	def __str__(self):
		ret = "state name: " + str(self.name) + " invariant: " + self.invariant 
		ret += " enabled actions: " 
		for enabled_action in self.enabled_actions:
			ret += str(enabled_action.name) + " "
		ret += "\n"
		for transition in self.transitions:
			ret += "\ttransition with " + str(transition) + "\n"
		return ret
		
class Transition:
	def __init__(self):
		self.action = ""
		self.destination = None
		self.violates_invariant = False
		
	def __str__(self):
		ret = "action: " + self.action + " destination: " + str(self.destination)
		if self.violates_invariant:
			ret += " violates invariant"
		return ret
