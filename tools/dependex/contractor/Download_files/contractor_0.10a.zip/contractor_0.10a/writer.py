# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
from ltsa_writer import *
from graphviz_writer import *

def write_fsm(fsm, contract, options):

	# open file if necessary
	if options.output_file != None:
		save_stdout = sys.stdout
		fsock = open(options.output_file, 'w')  
		sys.stdout = fsock
		
	if options.output_format == "ltsa":
		ltsa_write_fsm(fsm, contract, options)
	if options.output_format == "graphviz":
		graphviz_write_fsm(fsm, contract, options)
		
	# close file if necessary
	if options.output_file != None:
		sys.stdout = save_stdout
		fsock.close()
		
