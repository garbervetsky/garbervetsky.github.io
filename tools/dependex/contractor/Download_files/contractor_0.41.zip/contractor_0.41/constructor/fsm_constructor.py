# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from util.verbose_printer import VerbosePrinter

class FSMConstructor:

	def construct(self):
		
		# setup statistics singleton
		self.setup_statistics()
		
		# perform actual construction
		fsm = self.generate_abstraction()
		
		# canonize FSM if we need to
		if Options.options.canonical_output:
			fsm.canonize()
	
		VerbosePrinter.verbose("FSM:\n----\n" + str(fsm), 3)

		return fsm
		
	def generate_abstraction(self):
		pass
		
	def setup_statistics(self):
		pass

