# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

class FSMConstructorFactory:

	def fsm_constructor(self, input_format):

		# read input
		from input.reader_factory import ReaderFactory
		input = ReaderFactory().reader(Options.options.input_format).read()

		if input_format == "fsm":
			# we don't need to construct, just read the incoming fsm			
			from constructor.virtual.virtual_fsm_constructor import VirtualFSMConstructor
			return VirtualFSMConstructor(input)
			
		elif input_format == "contract" or input_format == "code-with-pre":
			# we need to construct, choose logic and parallelizer kind
			
			# choose logic
			if input_format == "contract":
				from language.cvc.cvc import CVC
				from constructor.parallelized.logic.contract_logic import ContractLogic
				logic = ContractLogic(input, CVC())
			elif input_format == "code-with-pre":
				from language.c.c import C
				from constructor.parallelized.logic.code_with_pre_logic import CodeWithPreLogic
				logic = CodeWithPreLogic(input, C())
				
			# choose algorithm
			if Options.options.construction_algorithm == "exploration":
				from constructor.parallelized.explorer_parallelizer import ExplorerParallelizer
				parallelizer = ExplorerParallelizer(logic)
			elif Options.options.construction_algorithm == "enumeration":
				from constructor.parallelized.enumerator_parallelizer import EnumeratorParallelizer
				parallelizer = EnumeratorParallelizer(logic)
			else:
				parallelizer = None
			
			from constructor.parallelized.parallelized_fsm_constructor import ParallelizedFSMConstructor
			return ParallelizedFSMConstructor(parallelizer)
			
		return None

