# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
from input.options.options import Options

class Parallelizer:
	
	def __init__(self, logic):
		self.logic = logic

		# construct the empty fsm
		self.fsm = logic.create_empty_fsm()

		# prepare handling of CTRL-C event
		import signal
		signal.signal(signal.SIGINT, signal_handler)
		
		# create commands queue
		import Queue
		self.queue = Queue.Queue()
		
	# run algorithm and return the constructed fsm
	def run(self):
		# create thread pool
		self.threads = []
		for _ in range(Options.options.threads):
			from constructor.parallelized.worker.worker import Worker
			t = Worker(self.queue, self.logic)
			t.start()
			self.threads.append(t)
		
		# create statistics display thread
		if Options.options.live_statistics:
			from constructor.parallelized.worker.stats_displayer import StatsDisplayer
			self.stats_displayer = StatsDisplayer()
			self.stats_displayer.start()

		# dispatch a processing round for each of the algorithm rounds
		for round in self.algorithm_rounds():
			round.register_time_stat_item()
			self.queue.put(round.command)
			self.queue.join()
			round.stop_time_stat_item()

		# kill threads
		self.kill_threads()
		if Options.options.live_statistics:
			self.stats_displayer.stop()
		
		return self.fsm
		
	# each parallelizer subclass decides its processing rounds
	def algorithm_rounds(self):
		pass

	# terminate all threads
	def kill_threads(self):
		# send as many kill commands as necessary
		from constructor.parallelized.comm.command import KillCommand
		for _ in self.threads:
			self.queue.put(KillCommand(self))
	
		# wait for threads to terminate
		for t in self.threads:
			t.join(1.0)
		
# CTRL-C handler
def signal_handler(signal, frame):
	sys.exit(0)

