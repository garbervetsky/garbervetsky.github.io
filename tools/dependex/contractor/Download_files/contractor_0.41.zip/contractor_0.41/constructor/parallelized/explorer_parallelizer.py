# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from stats.statistics import Statistics

from constructor.parallelized.parallelizer import Parallelizer
class ExplorerParallelizer(Parallelizer):

	def __init__(self, logic):
		# lock for management of fsm states
		import threading
		self.states_lock = threading.Lock()
	
		# a map(states ids -> states) of known states
		# a set(state ids) of states known to be inconsistent
		# a set(labels) of labels that should not be considered
		from util.monitors import MonitorMap, MonitorSet
		self.states_known = MonitorMap()
		self.states_inconsistent = MonitorSet()
		self.labels_inconsistent = MonitorSet()

		# setup state explorer algorithm statistics
		from stats.statistics_factory import StatisticsFactory
		Statistics.instance.add(StatisticsFactory.explorer_algorithm_stat_items())
		if Options.options.dependencies_preanalysis:
			Statistics.instance.add(StatisticsFactory.dependencies_analysis_explorer_stat_items())
			

		Parallelizer.__init__(self, logic)

	def algorithm_rounds(self):
		from constructor.parallelized.parallelizer_round import ParallelizerRound
		from constructor.parallelized.comm.explorer_commands import PreprocessingExplorerCommand, InitialExplorerCommand
		return [ParallelizerRound("Preprocessing", PreprocessingExplorerCommand(self)),\
				ParallelizerRound("Exploring", InitialExplorerCommand(self))]

	def add_state(self, state_id, state):
		self.fsm.states.append(state)
		self.states_lock.acquire()
		self.states_known.put(state_id, state)
		from constructor.parallelized.comm.explorer_commands import StateExplorerCommand
		self.queue.put(StateExplorerCommand(self, state_id))
		self.states_lock.release()
		Statistics.instance["states"].add()
		
	def add_transition(self, state, transition):
		state.transitions.append(transition)
		Statistics.instance["transitions"].add()
		
