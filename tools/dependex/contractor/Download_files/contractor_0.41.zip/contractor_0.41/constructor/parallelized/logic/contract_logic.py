# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from model.contract.contract import Variable
from model.fsm.contract_fsm import ContractFSM, ContractState, ContractTransition
from stats.statistics import Statistics

from constructor.parallelized.logic.logic import Logic
class ContractLogic(Logic):
	def __init__(self, contract, language):
		self.contract = contract
		self.language = language
		self.contract_description = self.language.contract_description(self.contract)
		from caller.prover.prover_caller_factory import ProverCallerFactory
		self.prover_caller = ProverCallerFactory().prover_caller()

	# Constructs an empty fsm according to logic kind
	def create_empty_fsm(self):
		ret = ContractFSM()
		ret.name = self.contract.name
		ret.labels = [action.name for action in self.contract.actions + self.contract.constructors]
		return ret

	# Constructs initial state
	def create_initial_state(self):
		return ContractState.from_state_number(None, self.contract)

	# Constructs the state whose state id is "state_id"
	def create_state(self, state_id):
		return ContractState.from_state_number(state_id, self.contract)
	
	# Returns True if the given state is consistent, False otherwise
	def is_consistent_state(self, state):
		state_description = self.contract_description + self.language.asert(state.invariant)
		prover_result = self.prover_caller.solve(state_description + self.language.check_satisfiability("TRUE"))
		if prover_result == "unsat":
			return False
		else: 
			# record uncertainty of state consistency
			if prover_result == "unknown":
				state.uncertain = True
			return True

	# Returns True if the given label is consistent and should be considered, False otherwise
	def is_label_valid(self, label):
		return True
	
	# Returns the labels list
	def get_labels(self):
		return [a.name for a in self.contract.actions]

	# Returns the '?', '0' or '1' indicating if second_label is enabled after using label in state
	def get_secondstep_availability(self, state, label, second_label):
		# fetch action and second action
		action = self.contract.get_label(label)
		second_action = self.contract.get_action(second_label)
		description = self.contract_description + self.language.asert(state.invariant)
		description += self.language.action_description(action, self.contract)
		# construct query
		query = self.language.prime_variables(second_action.quantified_pre, action.mod_vars)
		return self.description_implies_query_or_negation(description, query)

	# Returns the '?', '0' or '1' indicating if query is necessarily unsat or if its negation is
	def description_implies_query_or_negation(self, description, query):
		first_query = self.language.check_satisfiability(query)
		result = self.prover_caller.solve(description + first_query)
		# analyze result
		if result == "unsat": 
			return '0'
		else:
			# check if it has to be necessarily turned on (second query)
			second_query = self.language.check_satisfiability(self.language.negate(query))
			result = self.prover_caller.solve(description + second_query)
			# analize second result
			if result == "unsat": 
				return '1'
		return '?'
		
	# Returns the list of '?'s, '0's and '1's indicating which labels are enabled after a given logic description (CVC, etc..)
	def get_availabilities_from_description(self, action, description):
		availabilities = ['?' for _ in self.contract.actions]
		for i in range(len(self.contract.actions)):
			query = self.language.prime_variables(self.contract.actions[i].quantified_pre, action.mod_vars)
			availabilities[i] = self.description_implies_query_or_negation(description, query)
		return availabilities
	
	# Retuns a transition if label can be used to go from state to destination state, None otherwise
	def transitable(self, state, label, destination_state):
		# fetch action
		action = self.contract.get_label(label)
		
		# construct action description
		action_description = self.contract_description + self.language.asert(state.invariant)
		action_description += self.language.action_description(action, self.contract)

		dest_invariant = self.language.prime_variables(destination_state.invariant, action.mod_vars)

		# check if dest_state is reachable
		prover_result = self.prover_caller.solve(action_description + self.language.check_satisfiability(dest_invariant))
	
		if prover_result == "unsat":
			return None
		else:
			# create transition
			transition = ContractTransition()
			transition.label = action.name
			transition.destination = destination_state.name
		
			# create transition guard
			primed_mod_vars = [Variable(var.name + "'", var.type) for var in [self.contract.get_variable(v) for v in action.mod_vars]]
			unprimed_dest_inv = self.language.prime_variables(destination_state.invariant + " AND " + self.contract.invariant, action.mod_vars)
			dest_inv = action.post + " AND " + unprimed_dest_inv
			# TODO eliminated expression closure over system variables on guard (due to exponencial growth on booleans)
			transition.guard = action.pre + " AND " + dest_inv 

			# record uncertainty of transition existence
			if prover_result == "unknown":
				transition.uncertain = True

			# check if system invariant is preserved
			contract_invariant = self.language.prime_variables(self.contract.invariant, action.mod_vars)
			if self.prover_caller.solve(action_description + self.language.check_validity(contract_invariant)) != "unsat":
				transition.violates_invariant = True

			return transition
	
	# Returns True if the given labels have a precondition dependency (according to negated flags)
	def analyze_labels_dependency(self, first_label, second_label, first_negated, second_negated):
		# construct preconditions
		pre1 = self.contract.get_label(first_label).quantified_pre
		if first_negated:
			pre1 = "NOT (" + pre1 + ")"
		pre2 = self.contract.get_label(second_label).quantified_pre
		if second_negated:
			pre2 = "NOT (" + pre2 + ")"
				
		# construct query
		query = self.contract_description + self.language.asert(pre1) + self.language.check_validity(pre2)
		if self.prover_caller.solve(query) == "unsat":
			return True
		else:
			return False
		

		
