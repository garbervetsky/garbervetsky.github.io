# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class Logic:

	# Constructs an empty fsm according to logic kind
	def create_empty_fsm(self):
		pass

	# Constructs initial state
	def create_initial_state(self):
		pass

	# Constructs the state whose state id is "state_id"
	def create_state(self, state_id):
		pass
	
	# Returns True if the given state is consistent, False otherwise
	def is_consistent_state(self, state):
		pass
	
	# Returns True if the given label is consistent and should be considered, False otherwise
	def is_label_valid(self, label):
		pass
	
	# Returns a transition if label can be used to go from state to destination state, None otherwise
	def transitable(self, state, label, destination_state):
		pass
		
	# Returns the labels list
	def get_labels(self):
		pass
	
	# Returns the '?', '0' or '1' indicating if second_label is enabled after using label in state
	def get_secondstep_availability(self, state, label, second_label):
		pass
	
	# Returns True if the given labels have a precondition dependency (according to negated flags)
	def analyze_labels_dependency(self, first_label, second_label, first_negated, second_negated):
		pass
		
	# takes a list of '0's, '?'s, and '1's. returns all the ways of solving '?'s into '0's or '1's
	def complete_uncertainties(self, availabilities):
		for i in range(len(availabilities)):
			if availabilities[i] == '?':
				# add all with this action on
				availabilities_yes = list(availabilities)
				availabilities_yes[i] = '1'
				ret_yes = self.complete_uncertainties(availabilities_yes)
				# add all with this action off
				availabilities_no = list(availabilities)
				availabilities_no[i] = '0'	
				ret_no = self.complete_uncertainties(availabilities_no)
				return ret_yes + ret_no
		return [availabilities]

