# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from model.fsm.code_with_pre_fsm import CodeWithPreFSM, CodeWithPreState, CodeWithPreTransition

from constructor.parallelized.logic.logic import Logic
class CodeWithPreLogic(Logic):
	def __init__(self, code_binding, language):
		self.code_binding = code_binding
		self.language = language
		self.instrumented = self.language.instrument(self.code_binding)
		from caller.blast.blast_caller import BlastCaller
		self.prover_caller = BlastCaller()

	# Constructs an empty fsm according to logic kind
	def create_empty_fsm(self):
		ret = CodeWithPreFSM()
		ret.name = self.code_binding.name
		ret.labels = [function.name for function in self.code_binding.functions + self.code_binding.initializers]
		return ret

	# Constructs initial state
	def create_initial_state(self):
		return CodeWithPreState.from_state_number(None, self.code_binding)

	# Constructs the state whose state id is "state_id"
	def create_state(self, state_id):
		return CodeWithPreState.from_state_number(state_id, self.code_binding)
	
	# Returns True if the given state is consistent, False otherwise
	def is_consistent_state(self, state):
		state_description = self.instrumented + self.language.state_description_function(state, self.code_binding) 
		state_description += self.language.state_consistency_function(state)
		prover_result = self.prover_caller.solve(state_description, "check_" + state.name, self.language.ERROR_LABEL)
		if prover_result == "unreachable":
			return False
		else: 
			# record uncertainty of state consistency
			if prover_result == "unknown":
				state.uncertain = True
			return True
	
	# Returns True if the given label is consistent and should be considered, False otherwise
	def is_label_valid(self, label):
		function = self.code_binding.get_function(label)
		function_description = self.instrumented + self.language.function_consistency_function(function) 
		prover_result = self.prover_caller.solve(function_description, "check_" + function.name, self.language.ERROR_LABEL)
		if prover_result == "unreachable":
			return False
		else: 
			return True
	
	# Returns the labels list
	def get_labels(self):
		return [f.name for f in self.code_binding.functions]

	# Returns the '?', '0' or '1' indicating if second_label is enabled after using label in state
	def get_secondstep_availability(self, state, label, second_label):
		# fetch action and second action
		function = self.code_binding.get_label(label)
		second_function = self.code_binding.get_function(second_label)
		
		# construct query
		description = self.instrumented + self.language.state_description_function(state, self.code_binding) 
		
		first_query = self.language.secondstep_function(state, function, second_function, self.code_binding)
		
		result = self.prover_caller.solve(description + first_query, state.name+"_"+function.name+"_"+second_function.name, self.language.ERROR_LABEL)
		if result == "unreachable":
			return '0'
		else:
			second_query = self.language.secondstep_function(state, function, second_function, self.code_binding, negated=True)
			result = self.prover_caller.solve(description + second_query, state.name+"_"+function.name+"_"+second_function.name, self.language.ERROR_LABEL)
			if result == "unreachable":
				return '1'
			else:
				return '?'
		
	# Retuns a transition if label can be used to go from state to destination state, None otherwise
	def transitable(self, state, label, destination_state):
		# fetch function
		function = self.code_binding.get_label(label)
		
		# construct description
		description = self.instrumented + self.language.state_description_function(state, self.code_binding) 
		description += self.language.state_description_function(destination_state, self.code_binding, with_inv=False, suffix="_reach")
		query = self.language.reachability_function(state, function, destination_state, self.code_binding)
		
		# check if dest_state is reachable
		result = self.prover_caller.solve(description + query, state.name+"_"+label+"_"+destination_state.name, self.language.ERROR_LABEL)
		
		if result == "unreachable":
			return None
		else:
			# create transition
			transition = CodeWithPreTransition()
			transition.label = function.name
			transition.destination = destination_state.name
		
			# record uncertainty of transition existence
			if result == "unknown":
				transition.uncertain = True

			# see if invariant is preserved on reaching state
			query = self.language.reachability_invariant_function(state, function, destination_state, self.code_binding)
			result = self.prover_caller.solve(description + query, state.name+"_"+label+"_"+destination_state.name, self.language.ERROR_LABEL)

			if result != "unreachable":
				transition.violates_invariant = True

			return transition
		
	# Returns True if the given labels have a precondition dependency (according to negated flags)
	def analyze_labels_dependency(self, first_label, second_label, first_negated, second_negated):
		# fetch functions
		function1 = self.code_binding.get_label(first_label)
		function2 = self.code_binding.get_label(second_label)
		
		# construct query and run engine
		query = self.instrumented + self.language.dependency_function(function1, function2, first_negated, second_negated)
		result = self.prover_caller.solve(query, "dep_" + function1.name + "_" + function2.name, self.language.ERROR_LABEL)
		
		return result == "unreachable"
		
			
