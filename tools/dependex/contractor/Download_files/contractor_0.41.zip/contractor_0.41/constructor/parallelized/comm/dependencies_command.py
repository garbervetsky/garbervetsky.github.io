# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from stats.statistics import Statistics
from constructor.parallelized.comm.command import Command
from util.verbose_printer import VerbosePrinter

class DependenciesCommand(Command):
	def execute(self, logic):
		labels = logic.get_labels()
		for i in range(len(labels)):
			if not self.parallelizer.labels_inconsistent.has(labels[i]):
				for j in range(i + 1, len(labels)):
					if not self.parallelizer.labels_inconsistent.has(labels[j]):
						self.parallelizer.queue.put(DependencyAnalysisCommand(self.parallelizer, i, j, negate_first_index=False))
						self.parallelizer.queue.put(DependencyAnalysisCommand(self.parallelizer, i, j, negate_first_index=True))
		self.parallelizer.queue.put(DependenciesTransitiveClosureCommand(self.parallelizer))

class DependencyAnalysisCommand(Command):
	def __init__(self, parallelizer, first_label_index, second_label_index, negate_first_index):
		Command.__init__(self, parallelizer)
		self.first_label_index = first_label_index
		self.second_label_index = second_label_index
		self.negate_first_index = negate_first_index
		
	def execute(self, logic):
		labels = logic.get_labels()
		first_label = labels[self.first_label_index]
		second_label = labels[self.second_label_index]
		VerbosePrinter.verbose("Analizing dependencies of " + first_label + " and " + second_label, 4)
		positive_second_dep = logic.analyze_labels_dependency(first_label, second_label, self.negate_first_index, second_negated=False)
		if positive_second_dep:
			if self.negate_first_index:
				kind = "np"
			else:
				kind = "pp"
			self.parallelizer.dependencies.put(self.first_label_index, kind, self.second_label_index)
		else:
			negative_second_dep = logic.analyze_labels_dependency(first_label, second_label, self.negate_first_index, second_negated=True)
			if negative_second_dep:
				if self.negate_first_index:
					kind = "nn"
				else:
					kind = "pn"
				self.parallelizer.dependencies.put(self.first_label_index, kind, self.second_label_index)

class DependenciesTransitiveClosureCommand(Command):
	def execute(self, logic):
		self.parallelizer.dependencies.transitive_closure()
		dep_counts = [len(self.parallelizer.dependencies.get(i, "pp")) \
#						len(self.parallelizer.dependencies.get(i, "pn")) +\
#						len(self.parallelizer.dependencies.get(i, "np")) \ # TODO decide sorting criterion
						 for i in range(len(logic.get_labels()))] #len(self.parallelizer.dependencies.get(i, "nn"))
		#sorted_deps = range(len(logic.get_labels()))
		#sorted_deps.sort(lambda i, j: dep_counts[j] - dep_counts[i])
		#self.parallelizer.sorted_deps = sorted_deps
		#print dep_counts
		#print sorted_deps  # TODO ver que hacer con el tema de sorting (si el algoritmo está en superparalelo no es posible, o hyper dificil!)
		Statistics.instance["dependencies"].add("pp", sum([len(self.parallelizer.dependencies.get(i, "pp")) for i in range(len(logic.get_labels()))]))
		Statistics.instance["dependencies"].add("pn", sum([len(self.parallelizer.dependencies.get(i, "pn")) for i in range(len(logic.get_labels()))]))
		Statistics.instance["dependencies"].add("np", sum([len(self.parallelizer.dependencies.get(i, "np")) for i in range(len(logic.get_labels()))]))
		Statistics.instance["dependencies"].add("nn", sum([len(self.parallelizer.dependencies.get(i, "nn")) for i in range(len(logic.get_labels()))]))
		VerbosePrinter.verbose("Dependencies transitive closure (fixed-point) is:\n" + str(self.parallelizer.dependencies) , 4)
		
