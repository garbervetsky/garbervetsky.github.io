# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import copy

class DependenciesNode:
	def __init__(self):
		self.pp = []
		self.pn = []
		self.np = []
		self.nn = []
	
	def __str__(self):
		return str(self.pp) + " " + str(self.pn) + " " + str(self.np) + " " + str(self.nn)

class Dependencies:
	def __init__(self, n):
		self.map = {}
		for i in range(n):
			self.map[i] = DependenciesNode()
			
	def put(self, i, kind, j):
		if kind == "pp":
			self.map[i].pp.append(j)
			self.map[j].nn.append(i)
		if kind == "pn":
			self.map[i].pn.append(j)
			self.map[j].pn.append(i)
		if kind == "np":
			self.map[i].np.append(j)
			self.map[j].np.append(i)
		if kind == "nn":
			self.map[i].nn.append(j)
			self.map[j].pp.append(i)
	
	def get(self, i, kind):
		if kind == "pp":
			return self.map[i].pp
		if kind == "pn":
			return self.map[i].pn
		if kind == "np":
			return self.map[i].np
		if kind == "nn":
			return self.map[i].nn
	
	def __str__(self):
		ret = ""
		for i,n in self.map.iteritems():
			ret += str(i) + ": " + str(n) + "\n"
		return ret

	def patterns(self, state=None, start=0):
		if state == None:
			state = ["?"] * len(self.map)
		
		if start == len(state):
			return [state]
		
		if state[start] == "?":
			state1 = copy.copy(state)
			state1[start] = "1"
			n = self.map[start]
			for j in n.pp:
				if state1[j] == "0":
					raise Exception("Something went really wrong... inconsistent dependencies found!")
				state1[j] = "1"
			for j in n.pn:
				if state1[j] == "1":
					raise Exception("Something went really wrong... inconsistent dependencies found!")
				state1[j] = "0"
			states_from_one = self.patterns(state1, start+1)
			
			state0 = copy.copy(state)
			state0[start] = "0"
			n = self.map[start]
			for j in n.np:
				if state0[j] == "0":
					raise Exception("Something went really wrong... inconsistent dependencies found!")
				state0[j] = "1"
			for j in n.nn:
				if state0[j] == "1":
					raise Exception("Something went really wrong... inconsistent dependencies found!")
				state0[j] = "0"
			states_from_zero = self.patterns(state0, start+1)
			
			return states_from_one + states_from_zero
			
		else:
			return self.patterns(state, start+1)
		
	def transitive_closure(self):
		changes = True
		while changes:
			changes = False
			for i, n1 in self.map.iteritems():
				for j in n1.pp:
					n2 = self.map[j]
					for k in n2.pp:
						if k == i:
							continue
						if not k in n1.pp:
							self.put(i,"pp",k)
							changes = True
					for k in n2.pn:
						if k == i:
							continue
						if not k in n1.pn:
							self.put(i,"pn",k)
							changes = True
				for j in n1.pn:
					n2 = self.map[j]
					for k in n2.np:
						if k == i:
							continue
						if not k in n1.pp:
							self.put(i,"pp",k)
							changes = True
					for k in n2.nn:
						if k == i:
							continue
						if not k in n1.pn:
							self.put(i,"pn",k)
							changes = True
				for j in n1.np:
					n2 = self.map[j]
					for k in n2.pp:
						if k == i:
							continue
						if not k in n1.np:
							self.put(i,"np",k)
							changes = True
					for k in n2.pn:
						if k == i:
							continue
						if not k in n1.nn:
							self.put(i,"nn",k)
							changes = True
							
							
