# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from constructor.parallelized.comm.command import Command
from constructor.parallelized.comm.label_command import LabelCommand
from input.options.options import Options
from util.verbose_printer import VerbosePrinter
from stats.statistics import Statistics

class PreprocessingEnumeratorCommand(Command):
	def execute(self, logic):
		VerbosePrinter.verbose("Starting preprocessing for enumeration algorithm", 4)
		
		# calculate labels consistency
		for label in logic.get_labels():
			self.parallelizer.queue.put(LabelCommand(self.parallelizer, label))
		
		# optional dependencies analysis step
		from constructor.parallelized.deps.dependencies import Dependencies
		self.parallelizer.dependencies = Dependencies(len(logic.get_labels()))
		if Options.options.dependencies_preanalysis:
			from constructor.parallelized.comm.dependencies_command import DependenciesCommand
			self.parallelizer.queue.put(DependenciesCommand(self.parallelizer))
			
class StatesEnumeratorCommand(Command):
	def execute(self, logic):
		VerbosePrinter.verbose("Starting states enumeration", 4)

		# initial state
		initial_state = logic.create_initial_state()
		self.parallelizer.fsm.states.append(initial_state)
		Statistics.instance["states"].add()
		self.parallelizer.fsm.initial_state = initial_state.name
		
		# construct patterns that satisfy dependencies		
		patterns = self.parallelizer.dependencies.patterns()
		
		# create a state for each pattern
		for pattern in patterns:
			pattern_id = 0
			for i in range(len(pattern)):
				if pattern[i] == "1":
					pattern_id += 1 << i
			state = logic.create_state(pattern_id)
		
			self.parallelizer.queue.put(StateConsistencyEnumeratorCommand(self.parallelizer, state))
	
class StateConsistencyEnumeratorCommand(Command):
	def __init__(self, parallelizer, state):
 		Command.__init__(self, parallelizer)
 		self.state = state

 	def execute(self, logic):
		VerbosePrinter.verbose("Checking consistency of state " + str(self.state.name), 4)
		if logic.is_consistent_state(self.state):
			self.parallelizer.fsm.states.append(self.state)
			Statistics.instance["states"].add()
		else:
			# record that we found an inconsistent state
			Statistics.instance["enumerated states"].add("inconsistent")

class TransitionsEnumeratorCommand(Command):
 	def execute(self, logic):
		VerbosePrinter.verbose("Starting transitions analysis", 4)

		# record the amount of consistent enumerated states (does not include initial state)
		Statistics.instance["enumerated states"].add("consistent", len(self.parallelizer.fsm.states) - 1)
		
		# create a transition analyzer command for each legal combination
		for s1 in self.parallelizer.fsm.states:
			for label in s1.enabled_labels:
				# do not consider inconsistent labels
				if not self.parallelizer.labels_inconsistent.has(label): 
					for s2 in self.parallelizer.fsm.states:
						# do not consider initial state as possible destination
						if not s2.is_initial():
							self.parallelizer.queue.put(TransitionEnumeratorCommand(self.parallelizer, s1, label, s2))

class TransitionEnumeratorCommand(Command):
	def __init__(self, parallelizer, s1, label, s2):
 		Command.__init__(self, parallelizer)
 		self.s1 = s1
 		self.label = label
 		self.s2 = s2

 	def execute(self, logic):
		VerbosePrinter.verbose("Checking transition from " + str(self.s1.name) + " using " + str(self.label) + " reaching " + str(self.s2.name), 4)
		transition = logic.transitable(self.s1, self.label, self.s2)
		if transition != None:
			self.s1.transitions.append(transition)
			Statistics.instance["transitions"].add()

class ReachableStatesEnumeratorCommand(Command):
	def execute(self, logic):
		VerbosePrinter.verbose("Eliminating unreachable states from abstraction", 4)
		
		# reset state and transitions statistics
		Statistics.instance["states"].reset()
		Statistics.instance["transitions"].reset()
		
		# prepare exploration algorithm
		reachable_states = []
		work_list = [self.parallelizer.fsm.get_state(self.parallelizer.fsm.initial_state)]

		while len(work_list) > 0:
			state = work_list.pop()
			reachable_states.append(state)
			Statistics.instance["states"].add()
			Statistics.instance["transitions"].add(len(state.transitions))
			for transition in state.transitions:
				destination = self.parallelizer.fsm.get_state(transition.destination)
				if not destination in reachable_states and not destination in work_list:
					work_list.append(destination)
			
		self.parallelizer.fsm.states = reachable_states

