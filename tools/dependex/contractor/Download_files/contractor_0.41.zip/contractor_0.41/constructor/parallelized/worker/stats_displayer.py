# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import time
			
from input.options.options import Options
from stats.statistics import Statistics
from util.console import get_terminal_width

import threading
class StatsDisplayer(threading.Thread):
	
	bars = ["|", "/", "-", "\\"]
	interval = 0.1
			
	def __init__(self):
		threading.Thread.__init__(self)
		self.daemon = True
	
	def run(self):
		self.running = True
		last_queries = 0
		bar_index = 0
		
		while self.running:
			queries_total = Statistics.instance["prover certainty"].total()
			queries_this_round = queries_total - last_queries
			last_queries = queries_total
					
			display = ""
			display += StatsDisplayer.bars[bar_index]
			bar_index = (bar_index + 1) % len(StatsDisplayer.bars)
			display += " " + Statistics.instance["total time"].dhms_string() 
			display += "     States: " + str(Statistics.instance["states"].val) + "     Transitions: " + str(Statistics.instance["transitions"].val) 
			display += "     Speed: %d queries/second" % (queries_this_round / StatsDisplayer.interval)
			
			width = get_terminal_width()
			display_spaces = width - len(display) - 1

			sys.stderr.write(display + " " * display_spaces + "\r")
			sys.stderr.flush()
			time.sleep(StatsDisplayer.interval)
	
	def stop(self):
		self.running = False
		sys.stderr.write(" " * (get_terminal_width()-1) + "\r")
		sys.stderr.flush()
		
