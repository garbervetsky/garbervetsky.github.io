# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from stats.statistics import Statistics

from constructor.parallelized.parallelizer import Parallelizer
class EnumeratorParallelizer(Parallelizer):

	def __init__(self, logic):
		# a set(labels) of labels that should not be considered
		from util.monitors import MonitorSet
		self.labels_inconsistent = MonitorSet()

		# setup state explorer algorithm statistics
		from stats.statistics_factory import StatisticsFactory
		Statistics.instance.add(StatisticsFactory.enumerator_algorithm_stat_items())

		Parallelizer.__init__(self, logic)

	def algorithm_rounds(self):
		from constructor.parallelized.parallelizer_round import ParallelizerRound
		from constructor.parallelized.comm.enumerator_commands import PreprocessingEnumeratorCommand, StatesEnumeratorCommand,\
																	TransitionsEnumeratorCommand, ReachableStatesEnumeratorCommand
		return [ParallelizerRound("Preprocessing", PreprocessingEnumeratorCommand(self)),\
				ParallelizerRound("States enumeration", StatesEnumeratorCommand(self)),\
				ParallelizerRound("Transitions finding", TransitionsEnumeratorCommand(self)),\
				ParallelizerRound("Restriction to reachable part", ReachableStatesEnumeratorCommand(self))]

