# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import threading
from constructor.parallelized.comm.command import Command
from constructor.parallelized.comm.label_command import LabelCommand
from input.options.options import Options
from util.verbose_printer import VerbosePrinter
from stats.statistics import Statistics

class InitialExplorerCommand(Command):
	def execute(self, logic):
		VerbosePrinter.verbose("Starting exploration algorithm", 4)
		initial_state = logic.create_initial_state()
		self.parallelizer.fsm.initial_state = initial_state.name
		self.parallelizer.add_state(None, initial_state)

class PreprocessingExplorerCommand(Command):
	def execute(self, logic):
		VerbosePrinter.verbose("Starting preprocessing for exploration algorithm", 4)
		
		# calculate labels consistency
		for label in logic.get_labels():
			self.parallelizer.queue.put(LabelCommand(self.parallelizer, label))
		
		# optional dependencies analysis step
		from constructor.parallelized.deps.dependencies import Dependencies
		self.parallelizer.dependencies = Dependencies(len(logic.get_labels()))
		if Options.options.dependencies_preanalysis:
			from constructor.parallelized.comm.dependencies_command import DependenciesCommand
			self.parallelizer.queue.put(DependenciesCommand(self.parallelizer))

#class StateExplorerCommand(ExplorerCommand):
#	def __init__(self, explorer, state_id):
#		ExplorerCommand.__init__(self, explorer)
#		self.state_id = state_id
#	
#	def execute(self, logic):
#		VerbosePrinter.verbose("Constructing state S" + str(self.state_id), 4)
#		state = self.explorer.states_known.get(self.state_id)
#		for enabled_label in state.enabled_labels:
#			self.explorer.queue.put(SecondStepExplorerCommand(self.explorer, self.state_id, enabled_label))

#class SecondStepExplorerCommand(ExplorerCommand):
#	def __init__(self, explorer, state_id, label):
#		ExplorerCommand.__init__(self, explorer)
#		self.state_id = state_id
#		self.label = label
#		
#	def execute(self, logic):
#		VerbosePrinter.verbose("Analyzing second step availability from S" + str(self.state_id) + " using label " + self.label, 4)
#		state = self.explorer.states_known.get(self.state_id)
#		
#		# we start with an "everything is possible" array
#		availabilities = ["?"] * len(logic.get_labels())
#		
#		for i in range(len(availabilities)):
#			# i = self.explorer.sorted_deps[index] #TODO ver si vale la pena esta optimización de sorting
#			if availabilities[i] == "?":
#				second_label = logic.get_labels()[i]
#				second_step = logic.get_secondstep_availability(state, self.label, second_label)
#				availabilities[i] = second_step
#				if second_step == "1":
#					Statistics.instance.secondstep_true_inc()
#					for j in self.explorer.dependencies.get(i, "pp"):
#						if availabilities[j] == "?":
#							Statistics.instance.engine_dependencies_pp_inc()
#							availabilities[j] = "1"
#					for j in self.explorer.dependencies.get(i, "pn"):
#						if availabilities[j] == "?":
#							Statistics.instance.engine_dependencies_pn_inc()
#							availabilities[j] = "0"
#				elif second_step == "0":
#					Statistics.instance.secondstep_false_inc()
#					for j in self.explorer.dependencies.get(i, "np"):
#						if availabilities[j] == "?":
#							Statistics.instance.engine_dependencies_np_inc()
#							availabilities[j] = "1"
#					for j in self.explorer.dependencies.get(i, "nn"):
#						if availabilities[j] == "?":
#							Statistics.instance.engine_dependencies_nn_inc()
#							availabilities[j] = "0"
#				else:
#					Statistics.instance.secondstep_unknown_inc()
#				
#		VerbosePrinter.verbose("Availabilities from S" + str(self.state_id) + " using label " + self.label + " are " + str(availabilities), 4)
#		
#		# explore all possible patterns allowed by availabilities
#		for pattern in logic.complete_uncertainties(availabilities):
#			possible_destination_id = 0
#			for i in range(len(pattern)):
#				if pattern[i] == '1':
#					possible_destination_id += 1 << i
#			self.explorer.queue.put(TransitionExplorerCommand(self.explorer, self.state_id, self.label, possible_destination_id))

# XXX versión super paralela
class StateExplorerCommand(Command):
	def __init__(self, parallelizer, state_id):
 		Command.__init__(self, parallelizer)
 		self.state_id = state_id
 	
 	def execute(self, logic):
		VerbosePrinter.verbose("Constructing state S" + str(self.state_id), 4)
		state = self.parallelizer.states_known.get(self.state_id)
		for enabled_label in state.enabled_labels:
			working = ['no'] * len(logic.get_labels())
			availabilities = ['?'] * len(logic.get_labels())
			availabilities_done = [] # use a list because it is passed by-ref and it is thread-safe
			lock = threading.Lock()
			for second_label_index in range(len(logic.get_labels())):
				self.parallelizer.queue.put(SecondStepExplorerCommand(self.parallelizer, self.state_id, enabled_label, second_label_index, working, availabilities, availabilities_done, lock))
			
# XXX versión super paralela
class SecondStepExplorerCommand(Command):
	def __init__(self, parallelizer, state_id, label, second_label_index, working, availabilities, availabilities_done, lock):
		Command.__init__(self, parallelizer)
		self.state_id = state_id
		self.label = label
		self.second_label_index = second_label_index
		self.working = working
		self.availabilities = availabilities
		self.availabilities_done = availabilities_done
		self.lock = lock
		
		
	def execute(self, logic):
		# fetch second label
		second_label = logic.get_labels()[self.second_label_index]

		# dependencies analysis may have already solved this particular second_label_index
		if self.availabilities[self.second_label_index] != "?":
			VerbosePrinter.verbose("Luckily skipped second step availability from S" + str(self.state_id) + " using label " + self.label + " and " + second_label + " as second label", 4)
			#
			# XXX
			# Esto no anda demasiado bien porque para cuando cada thread llega a este punto, todavía está todo en "?"
			# Necesito algo que permita cancelar otros threads por parte del thread que descubre las dependencias
			# XXX
			#
		else:
			VerbosePrinter.verbose("Analyzing second step availability from S" + str(self.state_id) + " using label " + self.label + " and " + second_label + " as second label", 4)
			state = self.parallelizer.states_known.get(self.state_id)

			# mark that i'm going to work
			#self.working[self.second_label_index] = 'yes'

			# spawn mini thread with this task 
#			mt = MiniThread(logic, state, self.label, second_label)
#			mt.start()
			
			# see if we need to stop this minithread
#			alive = mt.is_alive()
#			while self.working[self.second_label_index] == 'yes' and alive:
#				mt.join(1)
#				alive = mt.is_alive()

			# kill the minithread or get result if it finished, 
#			if alive:
				
#			else:
#				second_step = mt.result
				

			# mark that i'm not working anymore
			#self.working[self.second_label_index] = 'no'
			
			

			# TODO this was before the minithread idea: second_step = logic.get_secondstep_availability(state, self.label, second_label)


			# if we were terminated because someone already got the answer, then we don't update availabilities
			#if not alive:
			second_step = logic.get_secondstep_availability(state, self.label, second_label)
			self.availabilities[self.second_label_index] = second_step
		
			Statistics.instance["secondstep"].add(second_step)
			if second_step == "1":
				for j in self.parallelizer.dependencies.get(self.second_label_index, "pp"):
					if self.availabilities[j] == "?":
						Statistics.instance["dependency hits"].add("pp")
						self.availabilities[j] = "1"
						self.working[j] = 'stop'
				for j in self.parallelizer.dependencies.get(self.second_label_index, "pn"):
					if self.availabilities[j] == "?":
						Statistics.instance["dependency hits"].add("pn")
						self.availabilities[j] = "0"
						self.working[j] = 'stop'
			elif second_step == "0":
				for j in self.parallelizer.dependencies.get(self.second_label_index, "np"):
					if self.availabilities[j] == "?":
						Statistics.instance["dependency hits"].add("np")
						self.availabilities[j] = "1"
						self.working[j] = 'stop'
				for j in self.parallelizer.dependencies.get(self.second_label_index, "nn"):
					if self.availabilities[j] == "?":
						Statistics.instance["dependency hits"].add("nn")
						self.availabilities[j] = "0"
						self.working[j] = 'stop'
				
			
		
		# mark that there is one more worker ready for this second_label, and see if i'm the last one
		self.lock.acquire()
		self.availabilities_done.append(self.second_label_index)
		if len(self.availabilities_done) < len(self.availabilities):
			self.lock.release()
			return

		VerbosePrinter.verbose("Availabilities from S" + str(self.state_id) + " using label " + self.label + " are " + str(self.availabilities), 4)
		
		# explore all possible patterns allowed by availabilities
		for pattern in logic.complete_uncertainties(self.availabilities):
			possible_destination_id = 0
			for i in range(len(pattern)):
				if pattern[i] == '1':
					possible_destination_id += 1 << i
			self.parallelizer.queue.put(TransitionExplorerCommand(self.parallelizer, self.state_id, self.label, possible_destination_id))
				
class TransitionExplorerCommand(Command):
	def __init__(self, parallelizer, state_id, label, destination_id):
		Command.__init__(self, parallelizer)
		self.state_id = state_id
		self.label = label
		self.destination_id = destination_id

	def execute(self, logic):
		VerbosePrinter.verbose("Trying to create transition from S" + str(self.state_id) + " using label " + self.label + " reaching S" + str(self.destination_id), 4)
		# is it an inconsistent label?
		if self.parallelizer.labels_inconsistent.has(self.label):
			return
		# visited destination already? 
		if self.parallelizer.states_known.has(self.destination_id):
			# get the state from the states_known map
			destination_state = self.parallelizer.states_known.get(self.destination_id)
			new_state = False
			Statistics.instance["state cache"].add("visited")
		elif self.parallelizer.states_inconsistent.has(self.destination_id):
			# the state is known to be inconsistent, don't even bother
			Statistics.instance["state cache"].add("inconsistent")
			return
		else:
			# create state
			Statistics.instance["state cache"].add("new")
			destination_state = logic.create_state(self.destination_id)
			# check new state consistency
			if not logic.is_consistent_state(destination_state):
				# record its inconsistency
				self.parallelizer.states_inconsistent.add(self.destination_id)
				return
			else: 
				new_state = True
		
		# fetch origin state
		state = self.parallelizer.states_known.get(self.state_id)
		transition = logic.transitable(state, self.label, destination_state)
		if transition != None:
			VerbosePrinter.verbose("Created transition from S" + str(self.state_id) + " using label " + self.label + " reaching S" + str(self.destination_id), 4)
			self.parallelizer.add_transition(state, transition)
			
			# add new state to the queue if it wasn't added during our visit
			if new_state and not self.parallelizer.states_known.has(self.destination_id):
		
				# add new state to the FSM
				self.parallelizer.add_state(self.destination_id, destination_state)

