# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

class Cropper:

	def crop(self, contract):
		actions = []
	
		# check if action forcing into crop is requested
		if Options.options.force_in_crop != None:
			action_names = Options.options.force_in_crop.strip().split(",")
			for action_name in action_names:
				action = contract.get_action(action_name)
				if action == None:
					raise Exception("Forcing of action " + action_name + " (does not exist in contract).")
				else:
					actions.append(action)
					contract.actions.remove(action)

		# check if random cropping needs to be performed on the actions set
		if Options.options.random_crop != None:
			if Options.options.random_crop > len(contract.actions):
				raise Exception("Random cropping argument can't be bigger than the amount of actions in the contract.")
			import random
			actions += random.sample(contract.actions, Options.options.random_crop)
		
		# use cropped actions if necessary
		if Options.options.force_in_crop != None or Options.options.random_crop != None:
			contract.actions = actions
		
		# check if crop needs to be loaded
		if Options.options.crop_load != None:
			crop_file = open(Options.options.crop_load, 'r')
			action_names = crop_file.readline().strip().split(",")
			crop_file.close()
			actions_crop = []
			for action_name in action_names:
				actions_crop.append(contract.get_action(action_name))
			contract.actions = actions_crop
		
		# check if crop needs to be saved
		if Options.options.crop_save != None:
			try:
				crop_file = open(Options.options.crop_save, 'w')  
				for i in range(len(contract.actions)):
					crop_file.write(contract.actions[i].name)
					if i < len(contract.actions) - 1:
						crop_file.write(",")
				crop_file.write("\n")
				crop_file.close()
			except Exception as exc:
				raise Exception("Error while saving crop file. " + str(exc))
			
