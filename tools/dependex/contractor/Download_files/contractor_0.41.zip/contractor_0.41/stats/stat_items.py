# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
import threading

class StatItem:
	def __init__(self, name):
		self.name = name

class CountStatItem(StatItem):
	def __init__(self, name):
		StatItem.__init__(self, name)
		self.lock = threading.Lock()
		self.val = 0
	
	def reset(self):
		self.lock.acquire()
		self.val = 0
		self.lock.release()
	
	def add(self, amount=1):
		self.lock.acquire()
		self.val += amount
		self.lock.release()
	
	def __str__(self):
		return self.name + ": " + str(self.val) + "\n"

class MultiCountStatItem(StatItem):
	def __init__(self, name, categories):
		StatItem.__init__(self, name)
		self.categories = categories
		self.values = {}
		for category in self.categories:
			self.values[category] = 0
		self.lock = threading.Lock()
		
	def add(self, category, amount=1):
		self.lock.acquire()
		self.values[category] += amount
		self.lock.release()

	def __getitem__(self, category):
		return self.values[category]

	def total(self):
		return sum(self.values.itervalues())

	def __str__(self):
		ret = ""
		total = self.total()
		for category in self.categories:
			value = self.values[category]
			ret += self.name + " " + category + ": %d" % value
			if total > 0:
				ret += " (%.2f%%)" % (float(value) / total * 100)
			ret += "\n"
		return ret
	
class TimeStatItem(StatItem):	
	def __str__(self):
		return self.name + " took " + self.dhms_string() + "\n"
			
	# returns the time amount in seconds (implemented by subclasses)
	def time_amount(self):
		pass
			
	# returns tuple (number of days, hours, minutes and seconds)
	def dhms(self):
		temp = float(self.time_amount()) / (60*60*24)
		d = int(temp)
		temp = (temp - d) * 24
		h = int(temp)
		temp = (temp - h) * 60
		m = int(temp)
		temp = (temp - m) * 60
		sec = temp
		return d,h,m,sec
	
	# returns a nice string with number of days, hours, minutes and seconds
	def dhms_string(self):
		d, h, m, s = self.dhms()
		return plural_time_part(d, "day") + plural_time_part(h, "hour") + \
				plural_time_part(m, "minute") + "%.2f seconds" % s
		
class TimeIntervalStatItem(TimeStatItem):
	def __init__(self, name):
		TimeStatItem.__init__(self, name)
		self.time = None
		self.initial_time = time.time()
	
	def stop(self):
		self.time = time.time() - self.initial_time
	
	def time_amount(self):
		if self.time != None:
			return self.time
		else:
			return time.time() - self.initial_time
		
class TimeAdderStatItem(TimeStatItem):
	def __init__(self, name):
		TimeStatItem.__init__(self, name)
		self.time = 0
		self.lock = threading.Lock()
	
	def add(self, time):
		self.lock.acquire()
		self.time += time
		self.lock.release()
	
	def time_amount(self):
		return self.time
		
# AUX: 1 noun, 2 nouns, ... (if i = 0, it is not even displayed)
def plural_time_part(i, noun):
	if i == 0:
		return ""
	elif i != 1:
		noun += "s"
	return str(i) + " " + noun + ", "
