# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class Statistics:
	def __init__(self):
		self.item_ids = []
		self.items = {}
		
	# registers a list of (id, item) tuples
	def add(self, id_items):
		for id, item in id_items:
			self[id] = item
		
	def __contains__(self, id):
		return id in self.item_ids
	
	def __setitem__(self, id, item):
		if not id in self:
			self.item_ids.append(id)
			self.items[id] = item
	
	def __getitem__(self, id):
		return self.items[id]
	
	def __str__(self):
		return "\n".join([str(self.items[id]) for id in self.item_ids])

# setup a basic instance
Statistics.instance = Statistics()

# add prover stat items (always required)
from stats.statistics_factory import StatisticsFactory
Statistics.instance.add(StatisticsFactory.prover_stat_items())
	

