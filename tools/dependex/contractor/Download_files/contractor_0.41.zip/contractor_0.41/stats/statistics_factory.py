# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from stats.stat_items import CountStatItem, MultiCountStatItem, TimeIntervalStatItem, TimeAdderStatItem

class StatisticsFactory:

	@staticmethod
	def fsm_stat_items():
		ret = []
		ret.append(("states", CountStatItem("States")))
		ret.append(("transitions", CountStatItem("Transitions")))
		return ret
		
	@staticmethod
	def prover_stat_items():
		ret = []
		ret.append(("prover time", TimeAdderStatItem("Prover")))
		ret.append(("prover certainty", MultiCountStatItem("Prover certainty", ["certain", "uncertain"])))
		return ret
		
	@staticmethod
	def parallelized_stat_items():
		ret = []
		ret.append(("total time", TimeIntervalStatItem("Execution")))
		return ret
		
	@staticmethod
	def explorer_algorithm_stat_items():
		ret = []
		ret.append(("state cache", MultiCountStatItem("State cache", ["visited", "inconsistent", "new"])))
		ret.append(("secondstep", MultiCountStatItem("Secondstep", ["0", "1", "?"])))
		return ret

	@staticmethod
	def enumerator_algorithm_stat_items():
		ret = []
		ret.append(("enumerated states", MultiCountStatItem("Enumerated states", ["consistent", "inconsistent"])))
		return ret

	@staticmethod
	def dependencies_analysis_stat_items():
		ret = []
		ret.append(("dependencies", MultiCountStatItem("Dependencies of kind", ["pp", "pn", "np", "nn"])))
		return ret
		
	@staticmethod
	def dependencies_analysis_explorer_stat_items():
		ret = []
		ret.append(("dependency hits", MultiCountStatItem("Dependency hits of kind", ["pp", "pn", "np", "nn"])))
		return ret

	# TODO crear time interval items para cada etapa de un algoritmo (reificar etapas)
	
