# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

def get_terminal_width():
    def ioctl_GWINSZ(fd):
        try:
            import fcntl, termios, struct, os
            cr = struct.unpack('hh', fcntl.ioctl(fd, termios.TIOCGWINSZ, '1234'))
        except:
            return None
        return cr
    cr = ioctl_GWINSZ(0) or ioctl_GWINSZ(1) or ioctl_GWINSZ(2)
    if not cr:
        try:
            fd = os.open(os.ctermid(), os.O_RDONLY)
            cr = ioctl_GWINSZ(fd)
            os.close(fd)
        except:
            pass
    if not cr:
        try:
            cr = (env['LINES'], env['COLUMNS'])
        except:
            cr = (25, 80)
    return int(cr[1])

