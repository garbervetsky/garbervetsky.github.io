# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class CVC:

	# surround an expression with a quantifier for each of the variables
	def close_expression(self, expression, variables, quant="EXISTS"):
		ret = expression
		for v in variables:
			if v.type != "BOOLEAN":
				m = self.identifier_matcher(v.name)
				if m.search(ret) != None:
					ret = quant + " (" + v.name + ":" + v.type + "): (" + ret + ")"
			else:
				if quant == "EXISTS":
					op = "OR"
				else:
					op = "AND"
				finder = self.identifier_matcher(v.name)
				ret = "(" + finder.sub("TRUE", ret) + ") " + op + " (" + finder.sub("FALSE", ret) + ")"
		return ret

	# define an enumerate variable type
	def define_enumerate(self, enum):
		return "DATATYPE " + str(enum) + " END;\n"
		
	# define the given variable (with the suffix on its name)
	def define_variable(self, variable, suffix=""):
		# use INT to encode NAT
		if variable.type == "NAT":
			var_type = "INT"
		else:
			var_type = variable.type
		ret = variable.name + suffix + " : " + var_type + ";\n"
		# add bounds assertion for NAT variables
		if variable.type == "NAT":
			ret += self.asert(variable.name + suffix + " >= 0")
		return ret

	# assert the given expression
	def asert(self, expression):
		return "ASSERT " + expression + ";\n"

	# produces an equality using the appropiate symbol depending on the type
	def equality(self, v1, v2, type):
		if type == "BOOLEAN":
			return v1 + " <=> " + v2
		else:
			return v1 + " = " + v2

	# get a countermodel for a previous (satisfiable) query
	def countermodel(self):
		return "COUNTERMODEL;\n"

	# get the negation of an expression
	def negate(self, exp):
		return "NOT(" + exp + ")"

	# check satisfiability of the given expression	
	def check_satisfiability(self, expression = "TRUE", pushpop = True):
		ret = ""
		if pushpop:
			ret += "PUSH;\n\t"
		ret += "CHECKSAT " + expression + ";\n"
		if pushpop:
			ret += "POP;\n"
		return ret
	
	# check universal validity of the given expression
	def check_validity(self, expression, pushpop = True):
		ret = ""
		if pushpop:
			ret += "PUSH;\n\t"
		ret += "QUERY " + expression + ";\n"
		if pushpop:
			ret += "POP;\n"
		return ret
	
	# prime variables in an expression
	def prime_variables(self, expression, variable_names):		
		ret = expression
		for variable_name in variable_names:
			replacer = self.identifier_matcher(variable_name)
			ret = replacer.sub(variable_name + "'", ret)
		return ret

	# returns the set of variables names such that they appear primed on the expression
	def get_primed_variables(self, expression, candidate_variable_names):
		ret = []
		for var_name in candidate_variable_names:
			finder = self.identifier_matcher(var_name + "'")
			if finder.search(expression) != None:
				ret.append(var_name)
		return ret

	# adds suffix to variables in expression
	def set_suffix(self, expression, variables, suffix):
		ret = expression
		for variable_name in [variable.name for variable in variables]:
			replacer = self.identifier_matcher(variable_name)
			if variable_name[-1] == "'": # Want subindex before "'"
				variable_name = variable_name[:-1]
				ret = replacer.sub(variable_name + str(suffix) + "'", ret)
			else:
				ret = replacer.sub(variable_name + str(suffix), ret)
		return ret	

	#generate equalities of primed variables
	def link_stages(self, variables, modified_variable_names, number):
		ret = ""
		for variable in variables:
			if variable.name in modified_variable_names:
				suffix = "'"
			else:
				suffix = ""
			v1 = variable.name + str(number) + suffix
			v2 = variable.name + str(number+1)
			ret += self.asert(self.equality(v1, v2, variable.type))
		return ret

	# cvc description of a contract
	def contract_description(self, contract, define_enums=True):
		ret = ""
		if define_enums:
			for enum in contract.enums:
				ret += self.define_enumerate(enum)
		for variable in contract.variables:
			ret += self.define_variable(variable)
		ret += self.asert(contract.invariant)
		return ret

	# cvc description of an action in a given contract
	def action_description(self, action, contract):
		ret = ""
		for parameter in action.parameters:
			ret += self.define_variable(parameter)
		ret += self.asert(action.pre)
		for var_name in action.mod_vars:
			ret += self.define_variable(contract.get_variable(var_name), "'")
		ret += self.asert(action.post)
		return ret

	# cvc description of a variable valuation
	def valuation_description(self, valuation):
		ret = ""
		if not valuation.is_initial():
			for variable, value in valuation.values.iteritems():
				ret += self.define_variable(variable)
				ret += self.asert(self.equality(variable.name, value, variable.type))
		return ret

	# regular expression that matches a whole identifier
	def identifier_matcher(self, identifier):
		chars = "[,.\[\] \t\n;()\-\+\*/%=<>\\\\]"
		import re
		return re.compile("((?<=" + chars + ")|\A)" + identifier + "(?=" + chars + "|$)")
	
