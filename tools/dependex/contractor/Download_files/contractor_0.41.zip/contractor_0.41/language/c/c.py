# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os

class C:

	ERROR_LABEL = "ERROR"

	def instrument(self, code_binding):
		# read original program
		ret = ""
		if not os.path.exists(code_binding.file):
			raise Exception("Can't find " + code_binding.file)
		program = open(code_binding.file, "r")
		for line in program:
			ret += line
		program.close()

		# add invariant function
		ret += self.invariant_function(code_binding) + "\n"
	
		# add initializer preconditions
		for initializer in code_binding.initializers:
			ret += self.function_precondition(initializer)
			ret += self.function_params_precondition(initializer)

		# add function preconditions
		for function in code_binding.functions:
			ret += self.function_precondition(function)
			ret += self.function_params_precondition(function)

		return ret
	
	def invariant_function(self, code_binding):
		ret = "// " + code_binding.name + " invariant\n"
		ret += "int inv() {\n"
		ret += "\t" + code_binding.inv + "\n"
		ret += "}\n"
		return ret
	
	def function_precondition(self, function):	
		ret = "// " + function.name + " precondition\n"
		ret += "int pre_" + function.name + "() {\n"
		ret += "\t" + function.pre + "\n"
		ret += "}\n\n"
		return ret

	def function_params_precondition(self, function):	
		ret = "// " + function.name + " params precondition\n"
		ret += "int params_pre_" + function.name + "(" + self.function_parameters(function.parameters) + ") {\n"
		ret += "\t" + function.params_pre + "\n"
		ret += "}\n\n"
		return ret
		
	def function_parameters(self, parameters):
		return ", ".join([str(p) for p in parameters])
		
	def state_description_function(self, state, code_binding, suffix="", with_inv=True):
		ret = "// " + state.name + " description\n"
		ret += "int " + state.name + suffix + "() {\n"
		if state.is_initial():
			ret += "\treturn 1;\n"
		else:
			ret += "\treturn " 
			if with_inv:
				ret += "inv()"
			else:
				ret += "1"
			for function in code_binding.functions:
				function_pre = " && "
				if function.name not in state.enabled_labels:
					function_pre += "!"
				function_pre += "pre_" + function.name + "()"
				ret += function_pre
			ret += ";\n"
		ret += "}\n"
		return ret
	
	def state_consistency_function(self, state):
		ret = "void check_" + state.name + "() {\n"
		ret += "\tif (" + state.name + "())\n"
		ret += "\t\t" + C.ERROR_LABEL + ": goto " + C.ERROR_LABEL + ";\n"
		ret += "}\n"
		return ret

	def function_consistency_function(self, function):
		ret = "void check_" + function.name + "(" + self.function_parameters(function.parameters) + ") {\n"
		ret += "\tif (params_pre_" + function.name + "(" + ", ".join([p.name for p in function.parameters]) + "))\n"
		ret += "\t\t" + C.ERROR_LABEL + ": goto " + C.ERROR_LABEL + ";\n"
		ret += "}\n"
		return ret
		
	def reachability_function(self, state, function, destination_state, code_binding):
		ret = "void " + state.name + "_" + function.name + "_" + destination_state.name
		ret += "(" + self.function_parameters(function.parameters) + ") {\n"
		ret += "\tif (!" + state.name + "())\n"
		ret += "\t\treturn;\n"
		ret += "\tif (!params_pre_" + function.name + "(" + ", ".join([p.name for p in function.parameters]) + "))\n"
		ret += "\t\treturn;\n"
		ret += "\t" + function.name + "(" + ", ".join([p.name for p in function.parameters]) + ");\n"
		ret += "\tif (" + destination_state.name + "_reach())\n"
		ret += "\t\t" + C.ERROR_LABEL + ": goto " + C.ERROR_LABEL + ";\n"
		ret += "}\n"
		return ret
	
	def reachability_invariant_function(self, state, function, destination_state, code_binding):
		ret = "void " + state.name + "_" + function.name + "_" + destination_state.name
		ret += "(" + self.function_parameters(function.parameters) + ") {\n"
		ret += "\tif (!" + state.name + "())\n"
		ret += "\t\treturn;\n"
		ret += "\tif (!params_pre_" + function.name + "(" + ", ".join([p.name for p in function.parameters]) + "))\n"
		ret += "\t\treturn;\n"
		ret += "\t" + function.name + "(" + ", ".join([p.name for p in function.parameters]) + ");\n"
		ret += "\tif (!" + destination_state.name + "_reach())\n"
		ret += "\t\treturn;\n"
		ret += "\tif (!inv())\n"
		ret += "\t\t" + C.ERROR_LABEL + ": goto " + C.ERROR_LABEL + ";\n"
		ret += "}\n"
		return ret
		
	def secondstep_function(self, state, function, second_function, code_binding, negated=False):
		ret = "void " + state.name + "_" + function.name + "_" + second_function.name
		ret += "(" + self.function_parameters(function.parameters) + ") {\n"
		ret += "\tif (!" + state.name + "())\n"
		ret += "\t\treturn;\n"
		ret += "\tif (!params_pre_" + function.name + "(" + ", ".join([p.name for p in function.parameters]) + "))\n"
		ret += "\t\treturn;\n"
		ret += "\t" + function.name + "(" + ", ".join([p.name for p in function.parameters]) + ");\n"
		ret += "\tif ("
		if negated:
			ret += "!"
		ret += "pre_" + second_function.name + "())\n"
		ret += "\t\t" + C.ERROR_LABEL + ": goto " + C.ERROR_LABEL + ";\n"
		ret += "}\n"
		return ret
		
	def dependency_function(self, function, second_function, negated_first, negated_second):
		if negated_first:
			nf_string = ""
		else:
			nf_string = "!"
		if negated_second:
			ns_string = ""
		else:
			ns_string = "!"
		ret = "void dep_" + function.name + "_" + second_function.name + "() {\n"
		ret += "\tif (" + nf_string + "pre_" + function.name + "())\n"
		ret += "\t\treturn;\n"
		ret += "\tif (" + ns_string + "pre_" + second_function.name + "())\n"
		ret += "\t\t" + C.ERROR_LABEL + ": goto " + C.ERROR_LABEL + ";\n"
		ret += "}\n"
		return ret
	
		
