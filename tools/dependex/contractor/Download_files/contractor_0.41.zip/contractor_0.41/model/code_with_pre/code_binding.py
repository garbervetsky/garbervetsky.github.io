# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class CodeBinding:
	def __init__(self):
		self.name = ""
		self.file = ""
		self.inv = ""
		self.functions = []
		self.initializers = []
		
	def __str__(self):
		ret = "CodeBinding " + str(self.name) + " (" + str(self.file) + "):"
		ret += "\n  * inv: " + str(self.inv)
		for initializer in self.initializers:
			ret += "\n  * initializer " + str(initializer)
		for function in self.functions:
			ret += "\n  * function " + str(function)
		return ret
		
	def get_label(self, label):
		ret = self.get_initializer(label)
		if ret == None:
			ret = self.get_function(label)
		return ret
		
	def get_initializer(self, initializer_name):
		for initializer in self.initializers:
			if initializer.name == initializer_name:
				return initializer
		return None

	def get_function(self, function_name):
		for function in self.functions:
			if function.name == function_name:
				return function
		return None
		
	def qualified_function_parameters(self, suffix = ""):
		ret = []
		for function in self.functions:
			for parameter in function.parameters:
				ret.append(Variable(function.name + "_" + parameter.name + suffix, parameter.type))
		return ret
	
class Function:
	def __init__(self):
		self.name = ""
		self.pre = "return 1;"
		self.params_pre = "return 1;"
		self.parameters = []
		
	def __str__(self):
		ret = "function: " + str(self.name)
		for parameter in self.parameters:
			ret += "\n\tparameter: " + str(parameter)
		ret += "\n\tpre: " + str(self.pre)
		ret += "\n\tparams pre: " + str(self.params_pre)
		return ret
		
class Variable:
	def __init__(self, name="", type=""):
		self.name = name
		self.type = type
	
	def __str__(self):
		return self.type + " " + self.name


