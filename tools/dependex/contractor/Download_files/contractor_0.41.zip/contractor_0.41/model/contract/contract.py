# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class Contract:
	def __init__(self):
		self.name = ""
		self.variables = []
		self.invariant = "TRUE"
		self.constructors = []
		self.actions = []
		self.enums = []

	def var_names(self):
		ret = []
		for variable in self.variables:
			ret.append(variable.name)
		return ret
	
	def get_variable(self, variable_name):
		for variable in self.variables:
			if variable.name == variable_name:
				return variable
	
	def get_label(self, label):
		ret = self.get_constructor(label)
		if ret == None:
			ret = self.get_action(label)
		return ret
	
	def action_names(self):
		ret = []
		for action in self.actions:
			ret.append(action.name)
		return ret

	def get_action(self, action_name):
		for action in self.actions:
			if action.name == action_name:
				return action

	def constructor_names(self):
		ret = []
		for constructor in self.constructors:
			ret.append(constructor.name)
		return ret
	
	def get_constructor(self, const_name):
		for constructor in self.constructors:
			if constructor.name == const_name:
				return constructor
	
	# converts a list of enabled actions to a state name
	def get_state_number(self, action_names):
		# first check if there is a constructor involved
		for constructor_name in self.constructor_names():
			if constructor_name in action_names:
				return "init"
		# there is no constructor
		state_number = long(0)
		for i, action_name in enumerate(self.action_names()):
			if action_name in action_names:
				state_number += 1 << i
		return state_number	

	def __str__(self):
		ret = "name: " + self.name + "\n"
		for variable in self.variables:
			ret += "variable: " + str(variable) + "\n"
		ret += "invariant: " + self.invariant + "\n"
		for enum in self.enums:
			ret += "enum: " + str(enum) + "\n"
		for constructor in self.constructors:
			ret += "constructor: " + str(constructor) + "\n"
		for action in self.actions:
			ret += "action: " + str(action) + "\n"
		return ret

class Variable:
	def __init__(self, name, typee):
		self.name = name
		self.type = typee

	def __str__(self):
		return self.name + ":" + self.type
		
class Enum:
	def __init__(self):
		self.name = ""
		self.values = []
	
	def __str__(self):
		return self.name + " = " + " | ".join(self.values)
		
class Action:
	def __init__(self):
		self.name = ""
		self.pre = "TRUE"
		self.post = "TRUE"
		self.parameters = []
		self.mod_vars = []
		self.quantified_pre = "TRUE"
	
	def par_names(self):
		ret = []
		for parameter in self.parameters:
			ret.append(parameter.name)
		return ret
	
	def __str__(self):
		ret = self.name + "( "
		for parameter in self.parameters:
			ret += str(parameter) + " "
		ret += ")\n\tpre: " + self.pre + "\n\tpost: " + self.post + "\n\tmod_vars: "
		for mod_var in self.mod_vars:
			ret += mod_var + " "
		return ret

