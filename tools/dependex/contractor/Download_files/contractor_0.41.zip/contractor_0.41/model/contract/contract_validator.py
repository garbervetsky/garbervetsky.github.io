# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class ContractValidator:

	def validate(self, contract):
		ret = []
		# check repeated names
		repeated_action_name = duplicate_name(contract.actions + contract.constructors)
		if repeated_action_name != None:
			ret.append("There are two actions with the same name: " + repeated_action_name)
		repeated_var_name = duplicate_name(contract.variables)
		if repeated_var_name != None:
			ret.append("There are two variables with the same name: " + repeated_var_name)
		for a in contract.actions + contract.constructors:
			repeated_par_name = duplicate_name(a.parameters)
			if repeated_par_name != None:
				ret.append("There are two parameters with the same name in action " + a.name + ": " + repeated_par_name)
			for p in a.parameters:
				for v in contract.variables:
					if p.name == v.name:
						ret.append("There is a parameter with the same name than a variable in action " + a.name + ": " + p.name)
		# check contract CVC
		from language.cvc.cvc import CVC
		language = CVC()
		from caller.prover.prover_caller_factory import ProverCallerFactory
		caller = ProverCallerFactory().prover_caller()
		query = language.contract_description(contract)
		contract_syntax = caller.check_syntax(query)
		if contract_syntax:
			ret.append("There are errors in the contract CVC description. " + contract_syntax)
		else:
			for action in contract.actions + contract.constructors:
				action_syntax = caller.check_syntax(query + language.action_description(action, contract))
				if action_syntax:
					ret.append("There are errors in the " + action.name + " action CVC description. " + action_syntax)
		return ret			

# AUX for validation
def duplicate_name(elems):
	for i in range(len(elems)):
		for j in range(i, len(elems)):
			if elems[i] != elems[j] and elems[i].name == elems[j].name:
				return elems[i].name
	return None
	
