# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class FSMValidator:
	def validate(self, fsm):
		ret = []
		# check if there are any enabled labels that don't move the machine in any outgoing transition.
		for state in fsm.states:
			for enabled_label in state.enabled_labels:
				if enabled_label not in [transition.label for transition in state.transitions]:
					ret.append("Action " + enabled_label + " is enabled in state " + state.name  + " but it has no outgoing transitions.")
		# check if there is any label that is not enabled on any state.
		for label in fsm.labels:
			for state in fsm.states:
				if label in state.enabled_labels:
					break
			else:
				ret.append("Action " + label + " is not enabled on any state.")
		return ret
	
