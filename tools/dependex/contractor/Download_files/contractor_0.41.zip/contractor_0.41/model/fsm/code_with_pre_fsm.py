# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from model.fsm.fsm import FSM, State, Transition

class CodeWithPreFSM(FSM):
	pass

class CodeWithPreState(State):
	# create a state from its state number (use None to create initial state)
	@staticmethod
	def from_state_number(state_number, code_binding):
		ret = CodeWithPreState()
		if state_number == None:
			ret.name = State.INIT_NAME
			ret.enabled_labels = [init.name for init in code_binding.initializers]
		else:
			ret.name = "S" + str(state_number)
			ret.enabled_labels = []
			n = state_number
			for function in code_binding.functions:
				if n & 1 != 0:
					ret.enabled_labels.append(function.name)
				n = n >> 1
		return ret
	
class CodeWithPreTransition(Transition):
	pass
