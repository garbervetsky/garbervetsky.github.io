# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class FSM:
	def __init__(self):
		self.name = ""
		self.states = []
		self.labels = []
		self.initial_state = ""

	def __str__(self):
		ret = "FSM " + self.name + " with labels: "
		for label in self.labels:
			ret += str(label) + " "
		ret += "\n"
		for state in self.states:
			ret += str(state)
		ret += "initial state: " + str(self.initial_state) + "\n"
		return ret
		
	def canonize(self):
		self.states.sort()
		for state in self.states:
			state.transitions.sort()
		
	def get_state(self, state_name):
		for state in self.states:
			if state.name == state_name:
				return state
		
class State:
	INIT_NAME = "Sinit"

	def __init__(self):
		self.name = ""
		self.transitions = []
		self.enabled_labels = []
		self.uncertain = False

	def __str__(self):
		ret = "state name: " + str(self.name)
		ret += " enabled labels: " 
		for enabled_label in self.enabled_labels:
			ret += str(enabled_label) + " "
		ret += "\n"
		for transition in self.transitions:
			ret += "\ttransition with " + str(transition) + "\n"
		if self.uncertain:
			ret += "--uncertain--"
		return ret
		
	def is_initial(self):
		return self.name == State.INIT_NAME
	
	def __cmp__(self, state):
		if state == None:
			return -1 
		elif self.name == State.INIT_NAME and state.name == State.INIT_NAME:
			return 0
		elif self.name == State.INIT_NAME:
			return -1
		elif state.name == State.INIT_NAME:
			return 1
		else:
			return cmp(self.name, state.name)

class Transition:
	def __init__(self):
		self.label = ""
		self.destination = None
		self.uncertain = False
		self.violates_invariant = False
				
	def __str__(self):
		ret = "label: " + str(self.label) + " destination: " + str(self.destination)
		if self.uncertain:
			ret += " --uncertain--"
		if self.violates_invariant:
			ret += " --violates invariant--"
		return ret

	def __cmp__(self, transition):
		if transition == None: 
			return -1
		if self.label == transition.label:
			return cmp(self.destination, transition.destination)
		else:
			return cmp(self.label, transition.label)
	
