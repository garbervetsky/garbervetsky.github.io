# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from model.fsm.fsm import FSM, State, Transition

class ContractFSM(FSM):
	pass

class ContractState(State):
	def __init__(self):
		State.__init__(self)
		self.invariant = "TRUE"

	# create a state from its state number (use None to create initial state)
	@staticmethod
	def from_state_number(state_number, contract):
		ret = ContractState()
		if state_number == None:
			ret.name = State.INIT_NAME
			ret.enabled_labels = [constr.name for constr in contract.constructors]
		else:
			ret.name = "S" + str(state_number)
			ret.enabled_labels = []
			n = state_number
			for action in contract.actions:
				ret.invariant += " AND "
				if n & 1 == 0:
					ret.invariant += "NOT "
				else:
					ret.enabled_labels.append(action.name)
				ret.invariant += "(" + action.quantified_pre + ")"
				n = n >> 1
		return ret

	def __str__(self):
		ret = State.__str__(self)
		ret += "\ninvariant: " + self.invariant
		return ret
	
class ContractTransition(Transition):
	def __init__(self):
		Transition.__init__(self)
		self.guard = ""
		
	def __str__(self):
		ret = Transition.__str__(self)
		ret += "\nguard: " + self.guard
		return ret

