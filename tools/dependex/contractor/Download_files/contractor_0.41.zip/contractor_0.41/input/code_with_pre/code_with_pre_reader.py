# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from model.code_with_pre.code_binding import CodeBinding, Function, Variable
from util.xml import find_elements

from input.reader import Reader
class CodeWithPreReader(Reader):

	def perform_read(self):
		# open file
		import xml.dom.minidom
		x_doc = xml.dom.minidom.parse(self.source)

		# parse binding
		try:
			x_binding = find_elements(x_doc,"code-binding")[0]
		except Exception as exc: 
			raise Exception("Not a valid code binding file.")
		ret = CodeBinding()
		ret.name = remove_spaces(x_binding.getAttribute("name"))
		ret.file = x_binding.getAttribute("file")
		ret.inv = x_binding.getAttribute("inv")

		# parse functions
		for x_initializer in find_elements(x_binding,"initializer"):
			ret.initializers.append(self.parse_function(x_initializer))
	
		# parse functions
		for x_function in find_elements(x_binding,"function"):
			ret.functions.append(self.parse_function(x_function))
		
		return ret
	
	def parse_function(self, x_function):
		function = Function()
		function.name = x_function.getAttribute("name")
		pre = x_function.getAttribute("pre")
		if pre != "":
			function.pre = pre
		params_pre = x_function.getAttribute("params_pre")
		if params_pre != "":
			function.params_pre = params_pre
		for x_parameter in find_elements(x_function,"parameter"):
			parameter = Variable()
			parameter.name = x_parameter.getAttribute("name")
			parameter.type = x_parameter.getAttribute("type")
			function.parameters.append(parameter)
		return function
	
# aux: remove spaces from a name
def remove_spaces(string):
	return string.replace(" ","_")

# aux: uncapitalize a string (first character is lower-cased)
def uncapitalize(string):
	return string[0].lower() + string[1:]
