# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

def parse_options():
	about_str = "Copyright (C) 2009\nhttp://lafhis.dc.uba.ar/contractor\nG. de Caso, A. Tcach, V. Braberman, D. Garbervetsky, S. Uchitel\n{gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar\nLaFHIS - Departamento de Computación - FCEyN - Universidad de Buenos Aires\nPabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina\nTel: +54-11-4576-3390 eext. 704\n\nThis program comes with ABSOLUTELY NO WARRANTY; for details check the GNU\nGeneral Public License in http://www.gnu.org/licenses/gpl-3.0.txt"

	# parser options
	import optparse
	parser = optparse.OptionParser(usage="%prog [options] file", version="%prog 0.41\n" + about_str)

	parser.add_option("-v", "--verbose",
					action="store", type="int", dest="verbose", default=1,
					help="verbosity level: 0 is quiet, 1 prints important warnings only, 2 or higher is more verbose [default: %default]", metavar="LEVEL")

	algorithm_group = optparse.OptionGroup(parser, "Algorithmic options", "These options control the algorithm optimizations.")
	algorithm_group.add_option("-t", "--threads",
					action="store", type="int", dest="threads", default=1,
					help="sets the number of worker threads to N [default: %default]", metavar="N")
	algorithm_group.add_option("-B", "--braberman",
					action="store_true", dest="dependencies_preanalysis", default=False,
					help="use fantastic Braberman filtering optimization [default: %default]")
	construction_choices="enumeration exploration"
	algorithm_group.add_option("-c", "--construction-algorithm",
					action="store", type="string", dest="construction_algorithm", default="exploration",
					help="select the construction algorithm [default: %default; options: "+construction_choices+"]", metavar="ALGORITHM")
	parser.add_option_group(algorithm_group)

	stats_group = optparse.OptionGroup(parser, "Statistics options", "These options control how the statistics are displayed.")
	stats_group.add_option("-s", "--statistics",
					action="store_true", dest="statistics", default=False,
					help="print statistics after result is obtained (time, optimization hits, ...) [default: %default]")
	stats_group.add_option("--live-statistics",
					action="store_true", dest="live_statistics", default=False,
					help="displays live statistics while obtaining result [default: %default]")
	parser.add_option_group(stats_group)
	
	input_group = optparse.OptionGroup(parser, "Input options", "These options control what type of input is to be expected.")
	input_choices="contract code-with-pre fsm"
	input_group.add_option("-i", "--input-format",
					action="store", type="string", dest="input_format", default="contract",
					help="set the format of input to FORMAT [default: %default; options: "+input_choices+"]", metavar="FORMAT")
	parser.add_option_group(input_group)
			
	output_group = optparse.OptionGroup(parser, "Output options", "These options control how and where the output is produced.")
	output_group.add_option("-f", "--output-file",
					action="store", type="string", dest="output_file", default=None,
					help="write results to FILE [default: stdout]", metavar="FILE")
	format_choices="fsm graphviz ltsa png pdf att"
	output_group.add_option("-o", "--output-format",
					action="store", type="string", dest="output_format", default="fsm",
					help="set the format of results to FORMAT [default: %default; options: "+format_choices+"]", metavar="FORMAT")
	output_group.add_option("--canonical-output",
					action="store_true", dest="canonical_output", default=False,
					help="print output in a canonical way (useful in conjunction with DIFF tools) [default: %default]")
	output_group.add_option("--print-details",
					action="store_true", dest="print_details", default=False,
					help="add extra details to the output (such as invariants, guards, ...) [default: %default]")
	output_group.add_option("--print-information",
					action="store_true", dest="print_information", default=False,
					help="add statistics and other metainformation into the output [default: %default]")
	output_group.add_option("--gv-separator",
					action="store", type="string", dest="gv_separator", default="\\n",
					help="(for graphviz, png and pdf output) use SEP as separator between multiple actions in the same edge [default: %default]", metavar="SEP")
	output_group.add_option("--att-label-file",
					action="store", type="string", dest="att_label_file", default=None,
					help="(for att output) stores FSM labels in FILE", metavar="FILE")
	output_group.add_option("--att-accepting-states",
					action="store", type="string", dest="att_accepting_states", default=None,
					help="(for att output) sets Si,Sj,... as the only accepting states [default: all states are accepting states]", metavar="Si,Sj,..")
	parser.add_option_group(output_group)

	prover_group = optparse.OptionGroup(parser, "Prover options", "These options control which prover is used.")
	prover_choices="cvc3 yices"
	prover_group.add_option("-p", "--prover",
					action="store", type="string", dest="prover", default="cvc3",
					help="use prover PROVER [default: %default; options: "+prover_choices+"]", metavar="PROVER")
	parser.add_option_group(prover_group)

	paths_group = optparse.OptionGroup(parser, "Tool paths", "These options control where to find the tools necessary tu fulfill different parts of the functionality.")
	paths_group.add_option("--cvc3-path",
					action="store", type="string", dest="cvc3_path", default="cvc3",
					help="set PATH as the location of the CVC3 prover [default: %default]", metavar="PATH")
	paths_group.add_option("--yices-path",
					action="store", type="string", dest="yices_path", default="yices",
					help="set PATH as the location of the Yices prover [default: %default]", metavar="PATH")
	paths_group.add_option("--dot-path",
					action="store", type="string", dest="dot_path", default="dot",
					help="set PATH as the location of the (graphviz) dot tool [default: %default]", metavar="PATH")
	paths_group.add_option("--blast-path",
					action="store", type="string", dest="blast_path", default="pblast.opt",
					help="set PATH as the location of the BLAST tool [default: %default]", metavar="PATH")
	parser.add_option_group(paths_group)

	# begin parsing and generate errors if necessary
	(options, args) = parser.parse_args()
	if len(args) != 1:
		parser.error("incorrect number of arguments, expecting a single input file")
	import os.path
	if args[0] != "-" and not os.path.exists(args[0]):
		parser.error("file does not exist: " + args[0])
	if options.verbose < 0:
		parser.error("verbosity level must be a non-negative integer")
		
	# algorithmic validation
	if options.threads <= 0:
		parser.error("threads must be a positive integer")
	if not options.construction_algorithm in construction_choices.split():
		parser.error("incorrect option of construction algorithm, must be one of: " + construction_choices)
	
	# input format validation
	if not options.input_format in input_choices.split():
		parser.error("incorrect option of input format, must be one of: " + input_choices)

	# output format validation
	if not options.output_format in format_choices.split():
		parser.error("incorrect option of output format, must be one of: " + format_choices)
	if options.output_format == "att" and options.att_label_file == None:
		parser.error("label file must be specified when using att format")
	if options.output_format == "att" and options.att_accepting_states != None:
		states = options.att_accepting_states.split(",")
		import re
		matcher = re.compile("\A([0-9]+|init)\Z")
		for state in states:
			if len(state) == 0 or state[0] != "S" or matcher.match(state[1:]) == None:
				parser.error("accepting states list must be well formed")
		options.att_accepting_states = states

	# prover validation
	if not options.prover in prover_choices.split():
		parser.error("incorrect option of prover, must be one of: " + prover_choices)

	# path validation
	from util.files import which
	if (options.output_format == "pdf" or options.output_format == "png") and which(options.dot_path) == None:
		parser.error("could not find dot tool at " + options.dot_path)
	if options.input_format == "contract" and which(options.cvc3_path) == None:
		parser.error("could not find CVC3 prover at " + options.cvc3_path)
	if options.input_format == "contract" and options.prover == "yices" and which(options.yices_path) == None:
		parser.error("could not find Yices prover at " + options.yices_path)
	if options.input_format == "c" and which(options.blast_path) == None:
		parser.error("could not find BLAST tool at " + options.blast_path)

	# save input filename for further use
	options.file = args[0]

	# save options in a wrapper class
	Options.options = options
	
