# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

def parse_options():
	about_str = "Copyright (C) 2009\nhttp://lafhis.dc.uba.ar/contractor\nG. de Caso, A. Tcach, V. Braberman, D. Garbervetsky, S. Uchitel\n{gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar\nLaFHIS - Departamento de Computación - FCEyN - Universidad de Buenos Aires\nPabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina\nTel: +54-11-4576-3390 eext. 704\n\nThis program comes with ABSOLUTELY NO WARRANTY; for details check the GNU\nGeneral Public License in http://www.gnu.org/licenses/gpl-3.0.txt"

	# parser options
	import optparse
	parser = optparse.OptionParser(usage="%prog [options] file", version="%prog 0.41\n" + about_str)

	parser.add_option("-v", "--verbose",
					action="store", type="int", dest="verbose", default=1,
					help="verbosity level: 0 is quiet, 1 prints important warnings only, 2 or higher is more verbose [default: %default]", metavar="LEVEL")

	cropping_group = optparse.OptionGroup(parser, "Cropping options", "These options allow the use of a subset of actions only.")
	cropping_group.add_option("--random-crop",
					action="store", type="int", dest="random_crop", default=None,
					help="restrict analysis to a (random) actions subset of size N", metavar="N")
	cropping_group.add_option("--force-in-crop",
					action="store", type="string", dest="force_in_crop", default=None,
					help="comma separated list of actions to include in crop regardless of randomization (these actions are not deducted from the size of the random crop)", metavar="ACTION1,ACTION2,...")
	cropping_group.add_option("--crop-save",
					action="store", type="string", dest="crop_save", default=None,
					help="saves comma separated list of used action names to FILE", metavar="FILE")
	cropping_group.add_option("--crop-load",
					action="store", type="string", dest="crop_load", default=None,
					help="loads comma separated list of action names to use from FILE", metavar="FILE")
	parser.add_option_group(cropping_group)

	output_group = optparse.OptionGroup(parser, "Output options", "These options control how and where the output is produced.")
	output_group.add_option("-f", "--output-file",
					action="store", type="string", dest="output_file", default=None,
					help="write results to FILE [default: stdout]", metavar="FILE")
	parser.add_option_group(output_group)

	# begin parsing and generate errors if necessary
	(options, args) = parser.parse_args()
	if len(args) != 1:
		parser.error("incorrect number of arguments, expecting a single input file")
	import os.path
	if args[0] != "-" and not os.path.exists(args[0]):
		parser.error("file does not exist: " + args[0])
	if options.verbose < 0:
		parser.error("verbosity level must be a non-negative integer")

	# cropping validation
	if options.random_crop != None and options.random_crop < 0:
		parser.error("random cropping needs a non-negative integer as an argument")
	if options.random_crop != None and options.crop_load != None:
		parser.error("can't use both random cropping and crop loading")
	if options.random_crop == None and options.crop_load == None:
		parser.error("you must choose between random cropping or crop loading")

	# save input filename for further use
	options.file = args[0]

	# save options in a wrapper class
	Options.options = options
	
