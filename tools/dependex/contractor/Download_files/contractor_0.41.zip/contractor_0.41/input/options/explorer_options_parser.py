# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from util.files import which

def parse_options():
	about_str = "Copyright (C) 2009\nG. de Caso, A. Tcach, V. Braberman, D. Garbervetsky, S. Uchitel\n{gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar\nLaFHIS - Departamento de Computación - FCEyN - Universidad de Buenos Aires\nPabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina\nTel: +54-11-4576-3390 eext. 704\n\nThis program comes with ABSOLUTELY NO WARRANTY; for details check the GNU\nGeneral Public License in http://www.gnu.org/licenses/gpl-3.0.txt"

	# parser options
	import optparse
	parser = optparse.OptionParser(usage="%prog [options] file", version="%prog 0.41\n" + about_str)

	mode_choices="concrete symbolic"
	parser.add_option("-v", "--verbose",
					action="store", type="int", dest="verbose", default=1,
					help="verbosity level: 0 is quiet, 1 prints important warnings only, 2 or higher is more verbose [default: %default]", metavar="LEVEL")
	parser.add_option("-m", "--mode",
					action="store", dest="mode", default="concrete",
					help="choose exploration mode [default: %default; options: "+mode_choices+"]")
	parser.add_option("-s", "--statistics",
					action="store_true", dest="statistics", default=False,
					help="print statistics (time, optimization hits, ...) [default: %default]")
			
	concrete_explorator_group = optparse.OptionGroup(parser, "Concrete exploration options", "These options control the concrete contract exploration, which uses a set of initial values.")
	concrete_explorator_group.add_option("--valuation",
					action="store", type="string", dest="valuation", default=None,
					help="comma separated list of variable values (do not supply this argument to use initial state) [default: (initial state)]", metavar="VALUE1,VALUE2,...")
	concrete_explorator_group.add_option("--action",
					action="store", type="string", dest="action", default=None,
					help="advance simulation using ACTION with given PARAMS. If no action is provided, then the list of available actions and the current state is printed. [default: (no action)]", metavar="ACTION[PARAMS]")
	concrete_explorator_group.add_option("--check-pre",
					action="store_true", dest="check_pre", default=False,
					help="do not try to advance, just check the precondition validity [default: %default]")
	concrete_explorator_group.add_option("--rule-out",
					action="store", type="string", dest="rule_out", default=None,
					help="force the reaching state not to be any of S1/S2/... where each Si is VALUE1,VALUE2,... [default: (no restriction)]", metavar="S1/S2/...")
	concrete_explorator_group.add_option("--restriction",
					action="store", type="string", dest="restriction", default="TRUE",
					help="force the reaching state to satisfy RESTRICTION [default: %default]", metavar="RESTRICTION")
	parser.add_option_group(concrete_explorator_group)

	symbolic_explorator_group = optparse.OptionGroup(parser, "Symbolic exploration options", "These options control the symbolic contract exploration, which concretises a path.")
	symbolic_explorator_group.add_option("--path",
					action="store", type="string", dest="path", default=None,
					help="return a concrete exploration that follows the given PATH, which must be given as STATE[restr]->ACTION[restr]->STATE[restr]->...->STATE[restr]. State restrictions may reference contract variables. Action restrictions may reference contract variables, parameters and primed contract variables (if they are modified by the action). All these restrictions are optional.", metavar="PATH")
	parser.add_option_group(symbolic_explorator_group)

	prover_group = optparse.OptionGroup(parser, "Prover options", "These options control which prover is used and where it is located.")
	prover_choices="cvc3 yices"
	prover_group.add_option("-p", "--prover",
					action="store", type="string", dest="prover", default="cvc3",
					help="use prover PROVER [default: %default; options: "+prover_choices+"]", metavar="PROVER")
	parser.add_option_group(prover_group)

	paths_group = optparse.OptionGroup(parser, "Tool paths", "These options control where to find the tools necessary tu fulfill different parts of the functionality.")
	paths_group.add_option("--cvc3-path",
					action="store", type="string", dest="cvc3_path", default="cvc3",
					help="set PATH as the location of the CVC3 prover [default: %default]", metavar="PATH")
	paths_group.add_option("--yices-path",
					action="store", type="string", dest="yices_path", default="yices",
					help="set PATH as the location of the Yices prover [default: %default]", metavar="PATH")
	parser.add_option_group(paths_group)

	# begin parsing and generate errors if necessary
	(options, args) = parser.parse_args()
	if len(args) != 1:
		parser.error("incorrect number of arguments, expecting a single input file")
	import os.path
	if args[0] != "-" and not os.path.exists(args[0]):
		parser.error("file does not exist: " + args[0])
	if options.verbose < 0:
		parser.error("verbosity level must be a non-negative integer")
	if not options.mode in mode_choices.split():
		parser.error("incorrect exploration mode, must be one of: " + mode_choices)

	# prover validation
	if not options.prover in prover_choices.split():
		parser.error("incorrect option of prover, must be one of: " + prover_choices)

	# exploration validation
	if options.mode == "symbolic" and options.path == None:
		parser.error("symbolic exploration requires a path to be provided")

	# path validation
	if which(options.cvc3_path) == None:
		parser.error("could not find CVC3 prover at " + options.cvc3_path)
	if options.prover == "yices" and which(options.yices_path) == None:
		parser.error("could not find Yices prover at " + options.yices_path)

	# save input filename for further use
	options.file = args[0]

	# save options in a wrapper class
	Options.options = options
