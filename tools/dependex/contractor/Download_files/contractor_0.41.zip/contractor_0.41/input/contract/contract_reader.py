# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from util.xml import find_elements
from model.contract.contract import Contract, Action, Variable, Enum

from input.reader import Reader
class ContractReader(Reader):

	def perform_read(self):
		ret = Contract()

		# open file
		import xml.dom.minidom
		x_doc = xml.dom.minidom.parse(self.source)
		try:
			x_contract = find_elements(x_doc, "contract")[0]
		except Exception as exc: 
			raise Exception("Not a valid contract file.")
	
		# TODO parse language here
		from language.cvc.cvc import CVC
		self.language = CVC()
	
		# fetching attributes
		ret.name = remove_spaces(x_contract.getAttribute("name")).capitalize()
		ret.invariant = x_contract.getAttribute("invariant")

		# fetching enums
		x_enums = find_elements(x_contract,"enum")
		for x_enum in x_enums:
			enum = self.parse_enum(x_enum)
			ret.enums.append(enum)

		# fetching variables
		x_vars = find_elements(x_contract,"variable")
		for x_var in x_vars:
			var = self.parse_variable(x_var)
			ret.variables.append(var)
		
		# fetching constructors
		x_constructors = find_elements(x_contract,"constructor")
		for x_constructor in x_constructors:
			constructor = self.parse_action(x_constructor, ret.var_names(), True)
			ret.constructors.append(constructor)
		
		# fetching actions
		x_actions = find_elements(x_contract,"action")
		for x_action in x_actions:
			action = self.parse_action(x_action, ret.var_names())
			ret.actions.append(action)
	
		# validate parsed contract
		from model.contract.contract_validator import ContractValidator
		issues = ContractValidator().validate(ret)
		if len(issues) > 0:
			raise Exception("There are errors in the contract:\n" + "\n".join(["- " + issue for issue in issues]))
	
		return ret

	# parse a variable xml element
	def parse_variable(self, x_var):
		name = remove_spaces(x_var.getAttribute("name"))
		typee = x_var.getAttribute("type")
		return Variable(name, typee)

	# parse a variable xml element
	def parse_enum(self, x_enum):
		ret = Enum()
		ret.name = remove_spaces(x_enum.getAttribute("name"))
		x_values = find_elements(x_enum,"value")
		for x_value in x_values:
			value_name = remove_spaces(x_value.getAttribute("name"))
			ret.values.append(value_name)
		return ret
	
	# parse an action xml element
	def parse_action(self, x_action, var_names, constructor = False):
		ret = Action()
		ret.name = remove_spaces(x_action.getAttribute("name"))
		ret.pre = x_action.getAttribute("pre")
		ret.post = x_action.getAttribute("post")
		for x_param in find_elements(x_action,"parameter"):
			par = self.parse_variable(x_param)
			ret.parameters.append(par)
		ret.quantified_pre = self.language.close_expression(ret.pre, ret.parameters)

		# constructors modify all the variables
		if constructor:
			ret.mod_vars = var_names
		else:
			ret.mod_vars = self.language.get_primed_variables(ret.post, var_names)
		return ret
	
# aux: remove spaces from a name
def remove_spaces(string):
	return string.replace(" ","_")

