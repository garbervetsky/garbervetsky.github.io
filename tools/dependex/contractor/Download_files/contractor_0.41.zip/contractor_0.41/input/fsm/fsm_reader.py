# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from model.fsm.fsm import FSM, State, Transition
from util.xml import find_elements

from input.reader import Reader
class FSMReader(Reader):

	# Constructs the necessary concrete FSM parser and delegates
	def perform_read(self):
		import xml.dom.minidom
		x_doc = xml.dom.minidom.parse(Options.options.file)
		x_abstraction = find_elements(x_doc, "abstraction")[0]

		# fetch which type of input was used to construct this FSM
		input_format = x_abstraction.getAttribute("input_format")

		# write input format to options
		Options.options.input_format = input_format

		# create an appropiate details parser
		from input.fsm.fsm_parser_factory import FSMParserFactory
		parser = FSMParserFactory().parser(input_format)
	
		# delegate to actual parser
		fsm = parser.parse_fsm(x_abstraction)
	
		return fsm
		
# Generic FSM parser
class FSMParser:
	
	def construct_empty_fsm(self):
		return FSM()

	def construct_empty_state(self):
		return State()

	def construct_empty_transition(self):
		return Transition()

	def parse_fsm(self, x_abstraction):
		ret = self.construct_empty_fsm()

		# fetching labels
		x_labels = find_elements(x_abstraction,"label")
		for x_label in x_labels:
			ret.labels.append(x_label.getAttribute("name"))

		# fetching attributes
		ret.name = x_abstraction.getAttribute("name")
		ret.initial_state = x_abstraction.getAttribute("initial_state")

		# fetching states
		x_states = find_elements(x_abstraction,"state")
		for x_state in x_states:
			state = self.parse_state(x_state)
			ret.states.append(state)
	
		return ret

	def parse_state(self, x_state):
		ret = self.construct_empty_state()

		# fetching attributes
		ret.name = x_state.getAttribute("name")
		if x_state.getAttribute("uncertain") == "true":
			ret.uncertain = True

		# fetching enabled actions
		for x_enabled_label in find_elements(x_state,"enabled_label"):
			name = x_enabled_label.getAttribute("name")
			ret.enabled_labels.append(name)
	
		# fetching transitions
		x_transitions = find_elements(x_state,"transition")
		for x_transition in x_transitions:
			transition = self.parse_transition(x_transition)
			ret.transitions.append(transition)

		return ret

	# parse a transition
	def parse_transition(self, x_transition):	
		ret = self.construct_empty_transition()

		# fetching attributes
		ret.label = x_transition.getAttribute("label")
		ret.destination = x_transition.getAttribute("destination")
		if x_transition.getAttribute("uncertain") == "true":
			ret.uncertain = True

		return ret

