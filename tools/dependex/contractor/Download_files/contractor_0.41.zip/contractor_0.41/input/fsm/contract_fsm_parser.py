# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from util.xml import find_elements
from model.fsm.contract_fsm import ContractFSM, ContractState, ContractTransition

from input.fsm.fsm_reader import FSMParser
class ContractFSMParser(FSMParser):
	
	def construct_empty_fsm(self):
		return ContractFSM()

	def construct_empty_state(self):
		return ContractState()

	def construct_empty_transition(self):
		return ContractTransition()

	def parse_state(self, x_state):
		ret = FSMParser.parse_state(self, x_state)
		ret.invariant = x_state.getAttribute("invariant")
		return ret

	def parse_transition(self, x_transition):	
		ret = FSMParser.parse_transition(self, x_transition)
		ret.guard = x_transition.getAttribute("guard")
		if x_transition.getAttribute("violates_invariant") == "true":
			ret.violates_invariant = True
		return ret

