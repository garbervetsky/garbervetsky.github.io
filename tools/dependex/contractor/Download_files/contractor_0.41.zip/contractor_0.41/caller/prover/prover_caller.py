# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from util.verbose_printer import VerbosePrinter

from caller.command_caller import CommandCaller
class ProverCaller(CommandCaller):

	def call_prover(self, query, type="sat"):
		command = self.command(type)
		
		out_data, err_data, execution_time, err_code = self.call(command, query)
	
		# record prover time
		from stats.statistics import Statistics
		Statistics.instance["prover time"].add(execution_time)
		
		# check the presence of errors
		if err_data != "":
			err = "Prover quitted with errors, check the contract syntax. Error was:\n"
			err += query + "\n" + err_data
			raise Exception(err)
	
		return out_data.strip()
	
	def check_syntax(self, query):
		try:
			self.call_prover(query)
		except Exception as exc:
			return str(exc)
		return None
	
	def solve(self, query):
		out_data = self.call_prover(query)
	
		# parse output
		from stats.statistics import Statistics
		if "unknown" in out_data:
			Statistics.instance["prover certainty"].add("uncertain")
			VerbosePrinter.verbose("Warning! 'unknown' response from prover.", 1)
			VerbosePrinter.verbose("For input:\n" + query, 2)
		elif "sat" in out_data:  # also holds for "unsat" in out_data
			Statistics.instance["prover certainty"].add("certain")
		else:
			raise Exception("Prover response is not recognized: " + out_data) 
			
		return out_data
		
	def get_model(self, query, language, variables):
		# check that it is satisfiable
		out_data = self.solve(query)
		if not out_data == "sat":
			return None
		# now perform actual model generation
		query += language.countermodel()
		out_data = self.call_prover(query, type="model")
		return self.parse_valuation(out_data, language, variables)
		
		
