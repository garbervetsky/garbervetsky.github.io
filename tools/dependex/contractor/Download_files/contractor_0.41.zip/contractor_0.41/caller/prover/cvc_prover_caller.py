# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

from caller.prover.prover_caller import ProverCaller
class CVCProverCaller(ProverCaller):

	def command(self, type="sat"):
		return Options.options.cvc3_path + " -output-lang smtlib"
	
	# parse a valuation from a prover response
	def parse_valuation(self, response, language, variables):
		values = {}
		for variable in variables:
			finder = language.identifier_matcher(variable.name)
			for line in response.split("\n"):
				place = finder.search(line)
				if place != None:
					if variable.type == "BOOLEAN":
						if line.find("(not " + variable.name + ")") != -1:
							values[variable.name] = "FALSE"
						else:
							values[variable.name] = "TRUE"
					else:
						line = line.replace("  :assumption (= " + variable.name + " ","")
						line = line[:-1]
						# the new CVC3 smt output uses '~' instead of '-'
						if line.startswith("(~"):
							line = line.replace("(~","(-")
						values[variable.name] = line
		return values
		
