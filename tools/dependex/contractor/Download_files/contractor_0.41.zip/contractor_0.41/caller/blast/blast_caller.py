# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import tempfile
from input.options.options import Options
from util.verbose_printer import VerbosePrinter

from caller.command_caller import CommandCaller
class BlastCaller(CommandCaller):

	def solve(self, program, main, label, extraargs=""):
		# write program in a tempfile
		program_file = tempfile.NamedTemporaryFile()
		program_file.write(program)
		program_file.seek(0)
	
		# construct blast command
		command = Options.options.blast_path + " " + extraargs + " " + program_file.name + " " # TODO extra options for provers
		command += "-main " + main + " -L " + label
			
		out_data, err_data, execution_time, err_code = self.call(command, "")
	
		# close program file
		program_file.close()
	
		# record prover time
		from stats.statistics import Statistics
		Statistics.instance["prover time"].add(execution_time)
		
		# check the presence of errors
		if err_code == 0 or err_code == 2:
			# parse output
			from stats.statistics import Statistics
			if ":-(" in out_data:
				Statistics.instance["prover certainty"].add("certain")
				return "reachable"
			elif ":-)" in out_data:
				Statistics.instance["prover certainty"].add("certain")
				return "unreachable"
			elif "Exception raised" in err_data:
				VerbosePrinter.verbose("Warning! 'unknown' response from Blast.", 1)
				VerbosePrinter.verbose("For input:\n" + program, 2)
				
				# retry with extra args TODO eliminate 
				if extraargs == "":
					VerbosePrinter.verbose("Retrying with extra args.", 1)
					return self.solve(program, main, label, "-craig 2 -predH 7")
				else:
					Statistics.instance["prover certainty"].add("uncertain")
					VerbosePrinter.verbose("Definite unknown.", 1)
				
				return "unknown" 
			else:
				VerbosePrinter.verbose("Blast input:\n" + program, 2)
				raise Exception("Blast response is not recognized: " + out_data) 
		else:
			err = "Blast quitted with errors, check the program syntax. Error was:\n"
			err += command + "\n" + program + "\n" + out_data + "\n" + err_data
			raise Exception(err)
	
	
