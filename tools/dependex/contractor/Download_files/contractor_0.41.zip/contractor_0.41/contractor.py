#! /usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
	
# parse command line arguments
from input.options.contractor_options_parser import parse_options
from input.options.options import Options
parse_options()

# construct fsm
try:
	from constructor.fsm_constructor_factory import FSMConstructorFactory
	constructor = FSMConstructorFactory().fsm_constructor(Options.options.input_format)
	fsm = constructor.construct()
except (Exception, KeyboardInterrupt) as exc:
	sys.exit(str(exc))

# validate resulting fsm
from model.fsm.fsm_validator import FSMValidator
for issue in FSMValidator().validate(fsm):
	print >> sys.stderr, issue

# write fsm
try:
	from output.writer_factory import WriterFactory
	writer = WriterFactory().writer(Options.options.output_format, Options.options.input_format)
	writer.write(fsm)
except (Exception, KeyboardInterrupt) as exc:
	sys.exit(str(exc))

# print statistics
if Options.options.statistics:
	from stats.statistics import Statistics
	print >> sys.stderr, str(Statistics.instance), 
		
