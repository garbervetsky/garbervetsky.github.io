# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options
from model.contract.contract import Variable
from model.fsm.fsm import State

from explorer.explorer import Explorer
class SymbolicExplorer(Explorer):

	# initialise explorer and parse input valuation
	def __init__(self, contract, language):
		Explorer.__init__(self, contract, language)
		from explorer.symbolic.path import Path
		self.path = Path.from_string(Options.options.path)
		
	# try to perform requested action according to given parameters
	def explore(self):
		# validate path first
		from explorer.symbolic.path_validator import PathValidator
		PathValidator(self.path, self.contract, self.language).validate()
		# construct query
		query, variables = self.construct_query()
		# perform query
		values = self.perform_query(query, variables)
		# print results
		self.print_values(values)
		
	# constructs the prover query
	def construct_query(self):
		query = ""
		variables = [] 
		origin_path_state = self.path.initial_state
		for i, transition in enumerate(self.path.transitions):
			if origin_path_state.name == State.INIT_NAME:
				origin_state_number = None
			else:
				origin_state_number = int(origin_path_state.name[1:])
			action = self.contract.get_label(transition.path_action.name)
			from model.fsm.contract_fsm import ContractState
			origin_state = ContractState.from_state_number(origin_state_number, self.contract)
			destination_state = ContractState.from_state_number(int(transition.path_state.name[1:]), self.contract)
			if action.name not in origin_state.enabled_labels:
				raise Exception("action " + action.name + " is not enabled in state " + origin_state.name)
			# construct this step of the query
			query_part, variables_i = self.transition_description(origin_state, action, destination_state, i, transition)
			variables += variables_i
			query += query_part
			origin_path_state = transition.path_state
		# we add the last variables in order to get it from the response
		for variable in self.contract.variables:
			variables.append(Variable(variable.name + str(len(self.path.transitions)), variable.type))	
		return query, variables
	
	def perform_query(self, query, variables):
		# satisfiability query
		query += self.language.check_satisfiability(pushpop=False)
		from caller.prover.prover_caller_factory import ProverCallerFactory
		return ProverCallerFactory().prover_caller().get_model(query, self.language, variables)
		
	def transition_description(self, origin, action, destination, order, transition):
		variables = list(self.contract.variables)
		modified_variable_names = []
		query = ""
		# basic state description
		if order == 0:
			query += self.language.contract_description(self.contract, define_enums=False)
			query += self.language.asert(origin.invariant)
		# define every parameter of the action
		for parameter in action.parameters:
			query += self.language.define_variable(parameter)
			variables.append(parameter)
		# add action restriction
		query += self.language.asert(transition.path_action.restriction)
		# parameters must comply with precondition
		query += self.language.asert(action.pre)
		# defined modified variables
		for mod_var in action.mod_vars:
			modified_variable = Variable(mod_var + "'", self.contract.get_variable(mod_var).type)
			modified_variable_names.append(mod_var)
			variables.append(modified_variable)
			query += self.language.define_variable(modified_variable)
		# define postcondition
		query += self.language.asert(action.post)
		# add state restriction (need to prime them since they predicate over reaching variables)
		query += self.language.asert(self.language.prime_variables(transition.path_state.restriction, modified_variable_names))		
		# We add suffix for every item
		query = self.language.set_suffix(query, variables, order)
		# We add the next state (with the contract and state invariants)
		query_dest = self.language.contract_description(self.contract)
		query_dest += self.language.asert(destination.invariant)
		query += self.language.set_suffix(query_dest, self.contract.variables, order + 1)
		# We link stages
		query += self.language.link_stages(self.contract.variables, modified_variable_names, order)
		# We add suffix to every non-primed variable and parameter in variables
		variables_ret = []
		for variable in variables:
			if variable.name[-1] != "'":
				variables_ret.append(Variable(variable.name + str(order), variable.type))
		return query, variables_ret
		
	def print_values(self, values):
		# check if a valuation was returned or not
		if values == None:
			print "Path transition is not possible."
		else:
			# we generate the output for all the transitions
			origin_path_state = self.path.initial_state
			for i, transition in enumerate(self.path.transitions):
				if origin_path_state.name == State.INIT_NAME:
					print "-- State " + State.INIT_NAME
					print
					action = self.contract.get_constructor(transition.path_action.name)
				else:
					print "-- State " + origin_path_state.name 
					for variable in self.contract.variables:
						print "  " + variable.name + " = " + values[variable.name + str(i)]
					print
					action = self.contract.get_action(transition.path_action.name)
				# now we print the transitions
				print "-- Action " + str(action.name)
				if len(action.parameters) > 0:
					for parameter in action.parameters:
						print "  " + parameter.name + " = " + values[parameter.name + str(i)]
				print		
				origin_path_state =  transition.path_state
				
			# now we must print last state
			print "-- State " + origin_path_state.name 
			for variable in self.contract.variables:
				print "  " + variable.name + " = " + values[variable.name + str(len(self.path.transitions))]
			print
