# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#	Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#	{gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#	LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#	Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#	Tel: +54-11-4576-3390 eext. 704
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

# A state in a symbolic path
class PathState:
	def __init__(self, name, restriction):
		self.name = name
		self.restriction = restriction 

	def __str__(self):
		return self.name + "[" + self.restriction + "]"
			
# An action in a symbolic path
class PathAction:
	def __init__(self, action_name, restriction):
		self.name = action_name
		self.restriction = restriction
		
	def __str__(self):
		return self.name + "[" + self.restriction + "]" 
		
# A transition in a symbolic path (Action, State)
class PathTransition:
	def __init__(self, path_action, path_state):
		self.path_action = path_action
		self.path_state = path_state
		
	def __str__(self):
		return "Transition:\n\taction: "+ str(self.path_action) + "\n\tstate: "+ str(self.path_state)
	
# A symbolic exploration path. It has an initial state and a list of transitions
class Path:
	# Separator for the input strings
	SEPARATOR = "->"
	
	def __init__(self, initial_state):
		self.initial_state = initial_state
		self.transitions = []
	
  	# returns states to be visited in order
  	def get_states(self):
  		ret = []
  		ret.append(self.initial_state.name)
  	 	for transition in self.transitions:
  	 		ret.append(transition.path_state.name)
  	 	return ret

  	# returns states to be visited in order
  	def get_actions(self):
  		ret = []
  	 	for transition in self.transitions:
  	 		ret.append(transition.path_action.name)
  	 	return ret

	def __str__(self):
		ret = "Initial state: " + str(self.initial_state)
		for transition in self.transitions:
			ret += "\n" + str(transition)
		return ret
  	 
  	#reads and creates a Path from string
  	@staticmethod
  	def from_string(path_str):
  		# Strings read are in the form of of the grammar: S->A->S
  		# S = State_Name | State_name[restrictions]
  		# A = Action_name | Action_name[restrictions]
  		path_array = path_str.split(Path.SEPARATOR)
  
		# Minimun length is 3 and it must be odd
  		if len(path_array) < 3 or (len(path_array) - 1) % 2 != 0:
  			raise Exception("path " + path_str + " is not well formed")
  		
  		name, rest = Path.parse_atom(path_array[0])
  		path_array = path_array[1:]
  		path = Path(PathState(name, rest))
  		for i, elem in enumerate(path_array):
  			if i % 2 == 0:
  				action, restriction = Path.parse_atom(elem)
  			else:
  			 	state, state_rest = Path.parse_atom(elem)
  			  	path.transitions.append(PathTransition(PathAction(action, restriction), PathState(state, state_rest)))
  			
  		return path

	# parse parameters/restrictions and names of actions and states
	@staticmethod
	def parse_atom(atom):
		# validation
		if atom.count("[") != atom.count("]") or atom.count("[") > 1 or atom.find("[") > atom.find("]"):
			raise Exception("malformed path element: " + atom)
			
		data = atom.split("[")
		name = data[0]
		if len(data) > 1:
			data = data[1].split("]")
			restriction = data[0]
			if restriction == "":
				raise Exception("empty restriction in path element: " + atom)
		else:
			restriction = "TRUE"
		return name, restriction


