# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#	Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#	{gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#	LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#	Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#	Tel: +54-11-4576-3390 eext. 704
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

from model.fsm.fsm import State
from model.fsm.contract_fsm import ContractState

# Provides functionality to validate symbolic paths
class PathValidator:
	def __init__(self, path, contract, language):
		self.path = path
		self.contract = contract
		self.language = language
		from caller.prover.prover_caller_factory import ProverCallerFactory
		self.prover_caller = ProverCallerFactory().prover_caller()

	def validate(self):
		self.validate_actions() 
		self.validate_states()
	
	def validate_actions(self):
		for action_name in self.path.get_actions():
			if self.contract.get_label(action_name) == None:
				raise Exception("action " + action_name + " must be a constructor name or an action name")
	
	def validate_states(self):
		for i, state_name in enumerate(self.path.get_states()):
			self.validate_state_name(state_name, i)
			self.validate_state_consistency(state_name)

	def validate_state_name(self, state_name, index):
		if state_name == "" or state_name[0] != "S":
			raise Exception("state name has to start with 'S'")
		try:
			state_name = int(state_name[1:])
		except:
			if state_name != State.INIT_NAME:
				raise Exception("state name must be " + State.INIT_NAME + " or S<number>")	
			elif index > 0:
				raise Exception(State.INIT_NAME + " may only appear as the first state")
			else:
				return
		if state_name < 0:
			raise Exception("state " + str(state_name) + " name must be non negative")
		if state_name >= 2**len(self.contract.actions):
			raise Exception("state " + str(state_name) + " name must be less than 2**|actions|")

	def validate_state_consistency(self, state_name):
		if state_name != State.INIT_NAME:
			state = ContractState.from_state_number(eval(state_name[1:]), self.contract)
			query = self.language.contract_description(self.contract) + self.language.asert(state.invariant)
			prover_result = self.prover_caller.solve(query + self.language.check_satisfiability())
			if prover_result == "unsat":
				raise Exception("state " + state_name + " is not consistent")
			if prover_result == "unknown":
				raise Exception("state " + state_name + " may not be consistent")

