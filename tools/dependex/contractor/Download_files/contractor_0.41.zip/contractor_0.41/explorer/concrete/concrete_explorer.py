# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from explorer.concrete.valuation import Valuation
from input.options.options import Options

from explorer.explorer import Explorer
class ConcreteExplorer(Explorer):

	# initialise explorer and parse input valuation
	def __init__(self, contract, language):
		Explorer.__init__(self, contract, language)
		self.valuation = Valuation.from_variable_list(Options.options.valuation, self.contract, self.language)
		
	# parse parameters and action name
	def parse_action(self, action):
		if action.count("[") != action.count("]") or action.count("[") > 1 or action.find("[") > action.find("]"):
			raise Exception("Action and parameters syntax is wrong in " + action)
		data = action.split("[")
		action = data[0]
		if len(data) > 1:
			data = data[1].split("]")
			action_parameters = data[0].split(",")
		else:
			action_parameters = ""
		return action, action_parameters

	# try to perform requested action according to given parameters
	def explore(self):
		# check that invariant is satisfied
		if not self.valuation.satisfies_invariant(self.contract):
			raise Exception("valuation does not satisfy contract invariant")

		if Options.options.action == None:
			# user requested info about the current state
			new_avail_actions = self.valuation.get_available_actions(self.contract)
			print "Available actions: " + " ".join(new_avail_actions)
			print "State name: S"+ str(self.contract.get_state_number(new_avail_actions))
			return
		else:
			# user requested a particular action. we parse it, fetch it and validate it
			action_name, action_parameters = self.parse_action(Options.options.action)
			if self.valuation.is_initial():
				action = self.contract.get_constructor(action_name)
				if action == None :
					raise Exception(action_name + " is not one of the contract constructors")
			else:
				action = self.contract.get_action(action_name)
				if action == None :
					raise Exception(action_name + " is not one of the contract actions")
		
			# we validate action parameters
			if len(action_parameters) != len(action.parameters):
				raise Exception(action_name + " action needs " + str(len(action.parameters)) + " parameters")
			for i, ap in enumerate(action_parameters):
				if ap == None or ap == "":
					raise Exception("parameter " + str(i+1) + " of action " + action_name + " is empty")
			if not action_name in self.valuation.get_available_actions(self.contract):
				raise Exception("action " + action_name + " not allowed from given valuation")

			# see if parameters satisfy action precondition
			satisfies_pre = self.valuation.check_satisfies_precondition(action, action_parameters)
			if Options.options.check_pre:
				if satisfies_pre:
					print "Precondition is satisfied"
				else:
					print "Precondition is NOT satisfied"
				return
			else:
				if not satisfies_pre:
					raise Exception("action parameters do not comply with precondition of " + action.name)	
			
			# get possible valuations and return them
			new_valuations = self.valuation.explore_action(self.contract, action, action_parameters)
			if len(new_valuations) == 0:
				print "There are no valuations that satisfy the restrictions"
			else:	
				for new_valuation in new_valuations:
					print "Valuation:"
					for variable in self.contract.variables:
						print "\t" + variable.name + " = " + new_valuation[variable]
					new_avail_actions = new_valuation.get_available_actions(self.contract)
					print "Available actions: " + " ".join(new_avail_actions)
					print "State name: S"+ str(self.contract.get_state_number(new_avail_actions))
					print
					
