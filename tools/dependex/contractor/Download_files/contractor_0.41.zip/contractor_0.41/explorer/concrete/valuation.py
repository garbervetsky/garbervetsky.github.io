# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from constructor.parallelized.logic.contract_logic import ContractLogic
from input.options.options import Options
from model.contract.contract import Variable
from model.fsm.contract_fsm import ContractState

# valuation: dictionary of variables (name + type) and values
class Valuation:

	# from a separated list of values, it returns a Valuation object. 
	@staticmethod
	def from_variable_list(variable_list, contract, language):
		ret = Valuation(language)
		if variable_list != None:
			parsed = variable_list.split(",")
			if len(parsed) != len(contract.variables):
				raise Exception("valuation should have as many values as variables in the contract")
			for i, value in enumerate(parsed):
				ret[contract.variables[i]] = value
		return ret
	
	def __init__(self, language):
		self.values = {}
		self.language = language
		from caller.prover.prover_caller_factory import ProverCallerFactory
		self.prover_caller = ProverCallerFactory().prover_caller()
	
	def __str__(self):
		if self.is_initial():
			return "initial_valuation\n"
		else:
			ret = ""
			for variable, value in self.values.iteritems():
				ret += str(variable) + " " + value + "\n"
			return ret
	
	def __setitem__(self, variable, value):
		self.values[variable] = value
		
	def __getitem__(self, variable):
		return self.values[variable]
		
	# returns True iff this is the initial valuation (constructed from Sinit)
	def is_initial(self):
		return len(self.values) == 0
	
	# primes all the variables in variable_names and retains values
	def prime_variables(self, variable_names):
		new_values = {}
		for variable, value in self.values.iteritems():
			if variable.name in variable_names:
				new_values[Variable(variable.name + "'", variable.type)] = value
			else:
				new_values[variable] = value
		self.values = new_values
	
	# checks that an action pre is satisfied by the valuation
	def check_satisfies_precondition(self, action, action_parameters):
		query = self.language.valuation_description(self)
		for i, parameter in enumerate(action.parameters):
			query += self.language.define_variable(action.parameters[i]) 
			query += self.language.asert(self.language.equality(action.parameters[i].name, action_parameters[i], action.parameters[i].type))
		return self.prover_caller.solve(query + self.language.check_validity(action.pre)) == "unsat"
			
		
	# checks that a valuation satisfies the contract invariant
	def satisfies_invariant(self, contract):
		if self.is_initial():
			return True
		else:
			query = self.language.valuation_description(self)
			query += self.language.check_validity(contract.invariant)
			return self.prover_caller.solve(query) == "unsat"
				
	# return available actions from this valuation
	def get_available_actions(self, contract):
		actions = []
		
		# on the first state we can only choose a constructor
		if self.is_initial():
			return contract.constructor_names()
		else:
			query = self.language.valuation_description(self)
			for action in contract.actions:
				if self.prover_caller.solve(query + self.language.check_validity(action.quantified_pre)) == "unsat":
					actions.append(action.name)
			return actions
			
	# Explores execution of action, with its parameters from this valuation
	def explore_action(self, contract, action, action_parameters):
		ret = []				
		query = self.language.valuation_description(self)
		
		# define primed variables
		primed_variables = [ Variable(v + "'", contract.get_variable(v).type) for v in action.mod_vars ]
		for pv in primed_variables:
			query += self.language.define_variable(pv)
		
		# first we prepare the variables of the action
		for i, parameter in enumerate(action.parameters):
			query += self.language.define_variable(action.parameters[i]) 
			query += self.language.asert(self.language.equality(action.parameters[i].name, action_parameters[i], action.parameters[i].type))

		# we assert the effect of the action
		query += self.language.asert(action.post) 
		
		# we add the exploration restriction
		query += self.language.asert(Options.options.restriction)
	
		# parse ruled-out valuations
		if Options.options.rule_out != None:
			for ruled_out_part in Options.options.rule_out.split("/"):
				ruled_out_valuation = Valuation.from_variable_list(ruled_out_part, contract, self.language)
				ruled_out_valuation.prime_variables(action.mod_vars)
				ruling_out = "TRUE"
				for variable, value in ruled_out_valuation.values.iteritems():
					ruling_out += " AND " + self.language.equality(variable.name, value, variable.type)
				query += self.language.asert("NOT(" + ruling_out + ")")
									
		# we want to deambiguate non-determinism. so we need the set of states that can be reached from here
		contract_logic = ContractLogic(contract, self.language)
		availabilities = contract_logic.get_availabilities_from_description(action, query)
		for pattern in contract_logic.complete_uncertainties(availabilities):
			
			# create state from pattern
			pattern_long = 0
			for i in range(len(contract.actions)):
				if pattern[i] == '1':
					pattern_long += 1 << i
			candidate_destination_state = ContractState.from_state_number(pattern_long, contract)
			
			# destination in candidate invariant
			dest_invariant = self.language.prime_variables(candidate_destination_state.invariant, action.mod_vars)
			
			# see if we can reach it
			this_query = query + self.language.asert(dest_invariant) + self.language.check_satisfiability(pushpop=False)
			new_values = self.prover_caller.get_model(this_query, self.language, primed_variables)
		
			if new_values != None:
				# we construct a new valuation using the new primed variables
				new_valuation = Valuation(self.language)
				for variable in contract.variables:
					if variable.name + "'" in new_values:
						new_valuation[variable] = new_values[variable.name + "'"]
					else:
						new_valuation[variable] = self.values[variable]
				ret.append(new_valuation)
		return ret
		
