#! /usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2008  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys

# parse command line arguments
from input.options.explorer_options_parser import parse_options
from input.options.options import Options
parse_options()

# setup statistics
from stats.statistics import Statistics

# parse contract
try:
	from input.contract.contract_reader import ContractReader
	contract = ContractReader().read()
except (Exception, KeyboardInterrupt) as exc:
	sys.exit(str(exc))

# logic language is fixed (as of now)
from language.cvc.cvc import CVC
language = CVC()

try:
	# choose between concrete and symbolic exploration
	if Options.options.mode == "concrete":
		from explorer.concrete.concrete_explorer import ConcreteExplorer
		explorer = ConcreteExplorer(contract, language)
	else:
		from explorer.symbolic.symbolic_explorer import SymbolicExplorer
		explorer = SymbolicExplorer(contract, language)
	# perform actual exploration
	explorer.explore()
except (Exception, KeyboardInterrupt) as exc:
	print >> sys.stderr, "Can't perform exploration:", str(exc)
	
# print statistics
if Options.options.statistics:
	print >> sys.stderr, str(Statistics.instance),

