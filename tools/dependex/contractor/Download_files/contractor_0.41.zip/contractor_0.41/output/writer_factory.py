# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class WriterFactory:

	def writer(self, output_format, input_format):
		if output_format == "att":
			from output.att.att_writer import ATTWriter
			return ATTWriter()
		elif output_format == "fsm":
			if input_format == "contract":
				from output.fsm.contract_fsm_writer import ContractFSMWriter
				return ContractFSMWriter()
			else:
				from output.fsm.fsm_writer import FSMWriter
				return FSMWriter()
		elif output_format == "graphviz":
			from output.graphviz.graphviz_writer import GraphvizWriter
			return GraphvizWriter()
		elif output_format == "pdf" or output_format == "png":
			from output.graphviz.image_writer import ImageWriter
			return ImageWriter()
		elif output_format == "ltsa":
			if input_format == "contract":
				from output.ltsa.contract_ltsa_writer import ContractLTSAWriter
				return ContractLTSAWriter()
			else:
				from output.ltsa.ltsa_writer import LTSAWriter
				return LTSAWriter()
			
		return None
		

