# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

from output.writer import Writer
class ContractWriter(Writer):

	def print_contents(self, contract):
		# Create the minidom document
		import xml.dom.minidom
		self.x_doc = xml.dom.minidom.Document()
		
		# Create the <abstraction> base element
		x_contract = self.x_doc.createElement("contract")
		x_contract.setAttribute("name", contract.name)
		x_contract.setAttribute("invariant", contract.invariant)
		self.x_doc.appendChild(x_contract)

		# create enums
		for enum in contract.enums:
			x_enum = self.xml_enum(enum)
			x_contract.appendChild(x_enum)
			
		# create variables
		for variable in contract.variables:
			x_variable = self.xml_variable(variable)
			x_contract.appendChild(x_variable)

		# create constructors
		for constructor in contract.constructors:
			x_constructor = self.xml_action(constructor, "constructor")
			x_contract.appendChild(x_constructor)

		# create actions
		for action in contract.actions:
			x_action = self.xml_action(action)
			x_contract.appendChild(x_action)

		# Print our newly created XML
		print self.x_doc.toprettyxml(indent="  ")

	def xml_enum(self, enum):
		ret = self.x_doc.createElement("enum")
		ret.setAttribute("name", enum.name)
		for value in enum.values:
			x_value = self.x_doc.createElement("value")
			x_value.setAttribute("name", value)
			ret.appendChild(x_value)
		return ret
		
	def xml_variable(self, variable, name="variable"):
		ret = self.x_doc.createElement(name)
		ret.setAttribute("name", variable.name)
		ret.setAttribute("type", variable.type)
		return ret

	def xml_action(self, action, name="action"):
		ret = self.x_doc.createElement(name)
		ret.setAttribute("name", action.name)
		ret.setAttribute("pre", action.pre)
		ret.setAttribute("post", action.post)
		for parameter in action.parameters:
			x_parameter = self.xml_variable(parameter, "parameter")
			ret.appendChild(x_parameter)
		return ret

	
