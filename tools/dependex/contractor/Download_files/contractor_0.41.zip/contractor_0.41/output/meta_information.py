# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class MetaInformation:

	# return a list of extra attributes that could be printed together with the output
	@staticmethod
	def info_attributes(fsm):
		from input.options.options import Options
		from stats.statistics import Statistics
		from util.strings import plural
		ret = []
		
		# add model name
		ret.append(("Name", fsm.name + " (" + Options.options.file + ")"))
		
		# add which input kind was used
		ret.append(("Input type", Options.options.input_format))
		
		# add input number of labels
		ret.append(("Input size", plural(len(fsm.labels), "label")))
		
		# add author (and machine)
		import getpass
		import socket
		ret.append(("Author", getpass.getuser() + " @ " + socket.gethostname()))
		
		# add creation date and time
		import time
		ret.append(("Generated", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
		
		# add total running time (and number of threads)
		ret.append(("Run", plural(Options.options.threads, "thread") + " for " + Statistics.instance["total time"].dhms_string()))
		
		# add engine certainty ratio
		prover_certainty = Statistics.instance["prover certainty"]
		ret.append(("Engine certainty", "%.2f %%" % (float(100) * prover_certainty["certain"] / prover_certainty.total())))

		# add model size		
		ret.append(("Abstraction size", plural(Statistics.instance["states"].val, "state") + ", " + plural(Statistics.instance["transitions"].val, "transition")))

		# add number of invariant violations
		inv_violations = 0
		for state in fsm.states:
			for transition in state.transitions:
				if transition.violates_invariant:
					inv_violations += 1
		ret.append(("Invariant violations", plural(inv_violations, "violation")))
		return ret

