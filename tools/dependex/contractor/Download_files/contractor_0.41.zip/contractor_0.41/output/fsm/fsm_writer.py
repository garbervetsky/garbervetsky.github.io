# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

from output.writer import Writer
class FSMWriter(Writer):

	def print_contents(self, fsm):
		# Create the minidom document
		import xml.dom.minidom
		self.x_doc = xml.dom.minidom.Document()
		
		# Create the <abstraction> base element
		x_abs = self.x_doc.createElement("abstraction")
		x_abs.setAttribute("name", fsm.name)
		x_abs.setAttribute("initial_state", fsm.initial_state)
		x_abs.setAttribute("input_format", Options.options.input_format)
		self.x_doc.appendChild(x_abs)

		# Create the optional <information> element
		if Options.options.print_information:
			x_info = self.x_doc.createElement("information")
			from output.meta_information import MetaInformation
			for (attribute, value) in MetaInformation.info_attributes(fsm):
				x_info.setAttribute(str(attribute).replace(" ","_"), str(value))
			x_abs.appendChild(x_info)

		# create labels
		for label in fsm.labels:
			x_label = self.x_doc.createElement("label")
			x_label.setAttribute("name", label)
			x_abs.appendChild(x_label)

		# create states
		for state in fsm.states:
			x_state = self.xml_state(state)
			x_abs.appendChild(x_state)

		# Print our newly created XML
		print self.x_doc.toprettyxml(indent="  ")

	def xml_state(self, state):
		ret = self.x_doc.createElement("state")
		ret.setAttribute("name", state.name)
		if state.uncertain:
			ret.setAttribute("uncertain", "true")
		for enabled_label in state.enabled_labels:
			x_enabled_label = self.x_doc.createElement("enabled_label")
			x_enabled_label.setAttribute("name", enabled_label)
			ret.appendChild(x_enabled_label)
		for transition in state.transitions:
			x_trans = self.xml_transition(transition)
			ret.appendChild(x_trans)
		return ret
		
	def xml_transition(self, transition):
		ret = self.x_doc.createElement("transition")
		ret.setAttribute("label", transition.label)
		ret.setAttribute("destination", transition.destination)
		if transition.uncertain:
			ret.setAttribute("uncertain", "true")
		if transition.violates_invariant:
			ret.setAttribute("violates_invariant", "true")
		return ret
	
