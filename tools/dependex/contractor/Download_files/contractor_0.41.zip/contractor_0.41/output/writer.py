# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
from input.options.options import Options

class Writer:

	def write(self, object):

		# open file if necessary
		if Options.options.output_file != None:
			try:
				fsock = open(Options.options.output_file, 'w')  
			except IOError as exc:
				raise Exception("Error while opening " + Options.options.output_file + " for writing. " + str(exc))
			else:
				save_stdout = sys.stdout
				sys.stdout = fsock
	
		try:	
			self.print_contents(object)
		except IOError as exc:
			raise Exception("Error while producing output. " + str(exc))
		
		# close file if necessary
		if Options.options.output_file != None:
			try: 
				fsock.close()
			except IOError as exc:
				raise Exception("Error while closing " + Options.options.output_file + ". " + str(exc))
			else:
				sys.stdout = save_stdout
	
	# must be overriden by specific classes
	def print_contents(self, object):
		pass
		
