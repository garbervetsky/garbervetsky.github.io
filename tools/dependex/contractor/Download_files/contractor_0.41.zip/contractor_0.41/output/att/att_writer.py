# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

from output.writer import Writer
class ATTWriter(Writer):

	def print_contents(self, fsm):	
	
		# mapping of action (or constructor) to integer
		label_number = {}
		for i, label in enumerate(fsm.labels):
			label_number[label] = i + 1

		# first of all write label file
		import sys
		save_stdout = sys.stdout
		fsock = open(Options.options.att_label_file, 'w')  
		sys.stdout = fsock
	
		for action_name, number in label_number.iteritems():
			print action_name, number
		
		sys.stdout = save_stdout	
		fsock.close()

		# print the FSM in att format
		for state in fsm.states:
			for transition in state.transitions:
				print self.state_number(fsm, state.name), self.state_number(fsm, transition.destination), label_number[transition.label]
			
		# print accepting states
		for state in fsm.states:
			if Options.options.att_accepting_states == None or state.name in Options.options.att_accepting_states:
				print self.state_number(fsm, state.name)
				
	def state_number(self, fsm, state_name):
		from model.fsm.fsm import State
		if state_name == State.INIT_NAME:
			return 2**len(fsm.labels)
		else:
			return state_name[1:]
			
