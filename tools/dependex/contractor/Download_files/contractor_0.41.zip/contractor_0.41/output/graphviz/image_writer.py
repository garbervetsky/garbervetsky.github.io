# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from input.options.options import Options

from output.writer import Writer
class ImageWriter(Writer):

	def print_contents(self, fsm):
		# create temp file in which we write graphviz content
		import sys
		import tempfile
		temp_file = tempfile.TemporaryFile()
		save_stdout = sys.stdout
		sys.stdout = temp_file
	
		# delegate to proper graphviz writer
		from output.writer_factory import WriterFactory
		WriterFactory().writer("graphviz", Options.options.input_format).print_contents(fsm)

		# fetch graphviz code from temp_file
		temp_file.seek(0)
		graphviz = ""
		for line in temp_file:
			graphviz += line

		# recover stdout
		sys.stdout = save_stdout

		# call dot
		from caller.dot.dot_caller import DotCaller
		print DotCaller().draw(graphviz)
	
