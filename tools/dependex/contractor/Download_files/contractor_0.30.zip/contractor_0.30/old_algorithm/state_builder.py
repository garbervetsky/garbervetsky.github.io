# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from caller.call_prover import call_prover

from logic.formulae import cvc_assert, cvc_check_satisfiability

from model.fsm import State

from old_algorithm.transition_builder import build_transitions

from reader.options_parser import Options

from stats.statistics import Statistics

# creates the fsm states for the given contract and removes the unsound ones
def build_states(fsm, contract):

	# action sets
	action_sets = [[x for (pos,x) in zip(range(len(contract.action_names())), contract.action_names()) if (2**pos) & switches] for switches in range(2**len(contract.action_names()))]

	# create a state for each action set
	for action_set in action_sets:
		state = State()
		state.name = long(0)
	
		# calculate state invariant and fill enabled actions
		for i in range(len(contract.actions)):
			action = contract.actions[i]
			state.invariant += " AND "
			if not (action.name in action_set):
				state.invariant += "NOT "
			else:
				state.enabled_actions.append(action)
				state.name += 1 << i
			state.invariant += "(" + action.quantified_pre + ")"
		# S in state name
		state.name = "S" + str(state.name)
		# add state to FSM
		fsm.states.append(state)

	# check if each state is sound
	unsound_states = []
	contract_cvc = contract.cvc()
	for state in fsm.states:
		cvc = contract_cvc + cvc_assert(state.invariant) + cvc_check_satisfiability("TRUE")
		prover_result = call_prover(cvc)
		if prover_result == "unsat":
			unsound_states.append(state)
			Statistics.inconsistent_states_inc()
		if prover_result == "unknown":
			state.uncertain = True

	for state in unsound_states:
		fsm.states.remove(state)

# incorporate initial state into FSM and deal with constructors
def build_initial_state(fsm, contract):
	# create initial state
	initial_state = State()
	initial_state.name = State.INIT_NAME
	initial_state.enabled_actions = contract.constructors

	# deal with constructors
	build_transitions(fsm, [initial_state], contract)

	# add initial state
	fsm.states.append(initial_state)	
	fsm.initial_state = initial_state.name
