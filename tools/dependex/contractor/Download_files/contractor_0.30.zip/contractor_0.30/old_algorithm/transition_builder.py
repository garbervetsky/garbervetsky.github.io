# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from caller.call_prover import call_prover

from logic.formulae import cvc_assert, cvc_define_variable, cvc_prime_variables, cvc_check_satisfiability, cvc_close_expression , cvc_check_validity

from model.contract import Variable
from model.fsm import Transition

from reader.options_parser import Options

# analyze the set of movements (either actions or constructors) from the given states
# in order to create transitions in the FSM 
def build_transitions(fsm, states, contract):
	
	# basic cvc description (system variables, ...)
	contract_cvc = contract.cvc()

	# analyze each given state
	for state in states:
		# assert state invariant
		state_cvc = contract_cvc + cvc_assert(state.invariant)
		
		# analyze each enabled movement from each state
		for action in state.enabled_actions:
			action_cvc = state_cvc
			
			# define each parameter
			for parameter in action.parameters:
				action_cvc += cvc_define_variable(parameter)
			
			# assert action precondition
			action_cvc += cvc_assert(action.pre)
			
			# define modified variables
			for var_name in action.mod_vars:
				action_cvc += cvc_define_variable(contract.get_variable(var_name),"'")
			
			# assert action postcondition
			action_cvc += cvc_assert(action.post)
			
			# check each state to see if it could be reached
			for dest_state in fsm.states:
				
				# prime modified variables in destination invariant
				dest_invariant = cvc_prime_variables(dest_state.invariant, action.mod_vars)
				
				# check if dest_state is reachable
				prover_result = call_prover(action_cvc + cvc_check_satisfiability(dest_invariant))
				if prover_result != "unsat": 

					# create transition
					transition = Transition()
					transition.action = action.name
					transition.destination = dest_state.name
					
					# create transition guard
					primed_mod_vars = [Variable(var.name + "'", var.type) for var in [contract.get_variable(v) for v in action.mod_vars]]
					unprimed_dest_inv = cvc_prime_variables(dest_state.invariant + " AND " + contract.invariant, action.mod_vars)
					dest_inv = cvc_close_expression(action.post + " AND " + unprimed_dest_inv, primed_mod_vars)
					transition.guard = cvc_close_expression(action.pre + " AND " + dest_inv, action.parameters)
					
					# mark uncertainty of transition existence
					if prover_result == "unknown":
						transition.uncertain = True
					
					# check if system invariant is preserved
					contract_invariant = cvc_prime_variables(contract.invariant, action.mod_vars)
					if call_prover(action_cvc + cvc_check_validity(contract_invariant)) != "unsat":
						transition.violates_invariant = True
				
					# add transition to FSM
					state.transitions.append(transition)
				
