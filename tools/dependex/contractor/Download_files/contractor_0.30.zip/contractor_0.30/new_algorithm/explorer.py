# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import threading
import sys
import Queue

from caller.call_prover import call_prover

from logic.formulae import cvc_assert, cvc_define_variable, cvc_prime_variables, cvc_check_satisfiability, cvc_close_expression, cvc_check_validity

from model.contract import Variable
from model.fsm import State, Transition

from reader.options_parser import Options

from stats.statistics import Statistics

from util.monitors import MonitorMap, MonitorSet

def explore(fsm, contract):

	# create initial state
	initial_state = State.from_state_number(None, contract)
	initial_state.name = State.INIT_NAME
	fsm.initial_state = initial_state.name
	fsm.states.append(initial_state)
	Statistics.states_add(1)

	# create queue
	queue = Queue.Queue()
	queue.put(("S", (None, initial_state)))
	
	# lock for management of fsm states
	states_lock = threading.Lock()
	
	# a map(states ids -> states) of known states
	states_known = MonitorMap()
	states_known.put(None, initial_state)

	# a set(state ids) of states known to be inconsistent
	states_inconsistent = MonitorSet() 
	
	# basic cvc description (system variables, ...)
	contract_cvc = contract.cvc()

	# thread pool
	threads = []

	# create working threads
	for i in range(Options.options.threads):
		t = WorkerThread(queue, initial_state, states_known, states_inconsistent, \
						 contract_cvc, states_lock, contract, fsm)
		t.setDaemon(True)
		t.start()
		threads.append(t)
		
	# wait until processing is done
	queue.join()
	
	# "kill" all threads
	for _ in range(len(threads)):
		queue.put(("K", None))
	
	# wait for threads to "die"
	for t in threads:
		t.join(1.0)
	
	
# class that implements a worker thread that retrieves and explores a state from the work queue
class WorkerThread(threading.Thread):
	def __init__ (self, queue, initial_state, states_known, states_inconsistent, \
					 	contract_cvc, states_lock, contract, fsm):
		threading.Thread.__init__(self)
		self.queue = queue
		self.initial_state = initial_state
		self.states_known = states_known
		self.states_inconsistent = states_inconsistent 
		self.contract_cvc = contract_cvc
		self.states_lock = states_lock
		self.contract = contract
		self.fsm = fsm

	def run(self):
		while True:
			(task_type, task_data) = self.queue.get()
			# exit condition
			if task_type == "K":
				sys.exit()
			
			# state task
			elif task_type == "S":
				current_bitset, current_state = task_data
				
				# assert state invariant
				state_cvc = self.contract_cvc + cvc_assert(current_state.invariant)

				# go through each of the enabled actions on the current state
				for enabled_action in current_state.enabled_actions:
					action_cvc = state_cvc

					# define each parameter
					for parameter in enabled_action.parameters:
						action_cvc += cvc_define_variable(parameter)
			
					# assert action precondition (needed because of parameters)
					action_cvc += cvc_assert(enabled_action.pre)

					# define modified variables
					for var_name in enabled_action.mod_vars:
						action_cvc += cvc_define_variable(self.contract.get_variable(var_name),"'")
				
					# assert action postcondition
					action_cvc += cvc_assert(enabled_action.post)
			
					# get availabilities vector for the second step actions
					availabilities = get_availabilities(enabled_action, action_cvc, self.contract)

					# explore possible destination states using restrictions in availabilities
					possible_patterns = complete_uncertainties(availabilities)
			
					for possible_pattern in possible_patterns:
						self.queue.put(("T", (current_state, enabled_action, action_cvc, possible_pattern)))
			
			# transition task
			elif task_type == "T":
				current_state, enabled_action, action_cvc, possible_pattern = task_data
				
				# check if it has already been visited
				pattern_long = 0
				for i in range(len(self.contract.actions)):
					if possible_pattern[i] == '1':
						pattern_long += 1 << i
			
				# visited already? 
				if self.states_known.has(pattern_long):
					# get the state from the states_known map
					possible_state = self.states_known.get(pattern_long)
					new_state = False
					Statistics.states_visited_hit_inc()
				elif self.states_inconsistent.has(pattern_long):
					# the state is known to be inconsistent, don't even bother
					Statistics.states_inconsistent_hit_inc()
					self.queue.task_done()
					continue
				else:
					# create state
					Statistics.states_new_inc()
					possible_state = State.from_state_number(pattern_long, self.contract)
					
					# check new state consistency
					possible_state_cvc = self.contract_cvc + cvc_assert(possible_state.invariant)
					prover_result = call_prover(possible_state_cvc + cvc_check_satisfiability("TRUE"))
					if prover_result == "unsat":
						# record its inconsistency
						self.states_inconsistent.add(pattern_long)
						# it is not consistent, try the next possible pattern
						self.queue.task_done()
						continue
					else: 
						new_state = True
					
						# record uncertainty of state consistency
						if prover_result == "unknown":
							possible_state.uncertain = True
			
				# if we are here it's because either we had a preexistent state or we have a new consistent state
			
				# prime modified variables in destination invariant
				dest_invariant = cvc_prime_variables(possible_state.invariant, enabled_action.mod_vars)
				
			
				# check if dest_state is reachable
				prover_result = call_prover(action_cvc + cvc_check_satisfiability(dest_invariant))
				
				if prover_result != "unsat":
			
					# create transition
					Statistics.transitions_add(1)
					transition = Transition()
					transition.action = enabled_action.name
					transition.destination = possible_state.name
					
					# create transition guard
					primed_mod_vars = [Variable(var.name + "'", var.type) for var in [self.contract.get_variable(v) for v in enabled_action.mod_vars]]
					unprimed_dest_inv = cvc_prime_variables(possible_state.invariant + " AND " + self.contract.invariant, enabled_action.mod_vars)
					dest_inv = cvc_close_expression(enabled_action.post + " AND " + unprimed_dest_inv, primed_mod_vars)
					transition.guard = cvc_close_expression(enabled_action.pre + " AND " + dest_inv, enabled_action.parameters)
		
					# record uncertainty of transition existence
					if prover_result == "unknown":
						transition.uncertain = True
			
					# check if system invariant is preserved
					contract_invariant = cvc_prime_variables(self.contract.invariant, enabled_action.mod_vars)
					if call_prover(action_cvc + cvc_check_validity(contract_invariant)) != "unsat":
						transition.violates_invariant = True
		
					# add transition to current state
					current_state.transitions.append(transition)
				
					# add new state to the queue if it wasn't added during our visit
					if new_state and not self.states_known.has(pattern_long):
					
						# add new state to the FSM
						Statistics.states_add(1)
						self.fsm.states.append(possible_state)
						
						# add state to queue and visited set (initial state, which uses key 'None' was already added at startup)
						self.states_lock.acquire()
						self.states_known.put(pattern_long, possible_state)
						self.queue.put(("S", (pattern_long, possible_state)))
						self.states_lock.release()

			# to prevent incorrect usage
			else:
				sys.stderr.write("Incorrect task type in multithreading: " + task_type + "\n")

			# report to the queue that current task has been processed
			self.queue.task_done()

# returns a list of size len(contract.actions) where element i is a '0' is action[i] is certainly not available after applying enabled_action from current state; '1' if it is certainly available; '?' if it is uncertain.
def get_availabilities(enabled_action, action_cvc, contract):

	# after_actions availability vector
	availabilities = ['?' for i in range(len(contract.actions))]
	
	# after_actions preconditions 
	after_action_preconditions = []

	# store queries	
	if Options.options.cvc3_group_multiple_queries:
		query = action_cvc
	else:
		queries = []
	
	# populate queries 
	for i in range(len(contract.actions)):
		after_action_preconditions.append(cvc_prime_variables(contract.actions[i].quantified_pre, enabled_action.mod_vars))
		current_query = cvc_check_satisfiability(after_action_preconditions[i])
		
		if Options.options.cvc3_group_multiple_queries:
			query += current_query
		else:
			queries.append(action_cvc + current_query)
	
	# solve and flush first queries
	if Options.options.cvc3_group_multiple_queries:
		results = call_prover(query, len(contract.actions))
		query = action_cvc
	else:
		results = []
		for i in range(len(queries)):
			results.append(call_prover(queries[i]))
		queries = []
	
	# create a list of action indexes that require a new response from prover
	answers_to = []
	
	# analize first results
	for i in range(len(results)):
		# check if it has to be necessarily turned off
		if results[i] == "unsat": 
			availabilities[i] = '0'
			Statistics.secondstep_false_inc()
		else:
			# check if it has to be necessarily turned on
			current_query = cvc_check_satisfiability("NOT (" + after_action_preconditions[i] + ")")
			if Options.options.cvc3_group_multiple_queries:
				query += current_query
			else:
				queries.append(action_cvc + current_query)
			answers_to.append(i)
			
	# solve second queries (if any)
	if len(answers_to) > 0:
		if Options.options.cvc3_group_multiple_queries:
			results = call_prover(query, len(answers_to))
		else:
			results = []
			for i in range(len(queries)):
				results.append(call_prover(queries[i]))
			
		# analize second results
		for i in range(len(answers_to)):			
			if results[i] == "unsat": 
				availabilities[answers_to[i]] = '1'
				Statistics.secondstep_true_inc()
			else:
				Statistics.secondstep_unknown_inc()

	return availabilities
	
# takes a list of '0's, '?'s, and '1's. returns all the ways of solving '?'s into '0's or '1's
def complete_uncertainties(availabilities):
	for i in range(len(availabilities)):
		if availabilities[i] == '?':
			
			# add all with this action on
			availabilities_yes = list(availabilities)
			availabilities_yes[i] = '1'
			ret_yes = complete_uncertainties(availabilities_yes)
		
			# add all with this action off
			availabilities_no = list(availabilities)
			availabilities_no[i] = '0'	
			ret_no = complete_uncertainties(availabilities_no)
			
			return ret_yes + ret_no
			
	return [availabilities]
	


					
