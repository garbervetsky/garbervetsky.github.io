# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import xml.dom.minidom
import re
import random
import sys

from logic.formulae import cvc_close_expression, cvc_get_primed_variables

from model.contract import Contract, Action, Variable, Enum
from model.fsm import FSM, State, Transition

def parse_contractor(file, options = None):
	x_doc = xml.dom.minidom.parse(file)
	x_contractors = find_elements(x_doc,"contractor")
	
	# there is a "contractor" element englobing a "contract" and an "abstraction"
	if len(x_contractors) > 0:
		x_contract = find_elements(x_contractors[0], "contract")[0]
		x_abstraction = find_elements(x_contractors[0], "abstraction")[0]
		
		contract = parse_contract(x_contract)
		return contract, parse_abstraction(x_abstraction, contract)
	
	# there is only a "contract" element
	else:
		x_contract = find_elements(x_doc, "contract")[0]
		return parse_contract(x_contract, options), None

# parse an xml contract (it assumes that file exists and it is correct in structure)
def parse_contract(x_contract, options = None):
	ret = Contract()
	
	# fetching attributes
	ret.name = remove_spaces(x_contract.getAttribute("name")).capitalize()
	ret.invariant = x_contract.getAttribute("invariant")

	# fetching enums
	x_enums = find_elements(x_contract,"enum")
	for x_enum in x_enums:
		enum = parse_enum(x_enum)
		ret.enums.append(enum)

	# fetching variables
	x_vars = find_elements(x_contract,"variable")
	for x_var in x_vars:
		var = parse_variable(x_var)
		ret.variables.append(var)
		
	# fetching constructors
	x_constructors = find_elements(x_contract,"constructor")
	for x_constructor in x_constructors:
		constructor = parse_action(x_constructor, ret.var_names(), True)
		
		ret.constructors.append(constructor)
		
	# fetching actions
	x_actions = find_elements(x_contract,"action")
	for x_action in x_actions:
		action = parse_action(x_action, ret.var_names())
		ret.actions.append(action)
	
	# actions cropping
	if options != None:
		cropping(ret, options)
		
	return ret
	
# parse a variable xml element
def parse_variable(x_var):
	name = remove_spaces(x_var.getAttribute("name"))
	typee = x_var.getAttribute("type")
	return Variable(name, typee)

# parse a variable xml element
def parse_enum(x_enum):
	ret = Enum()
	ret.name = remove_spaces(x_enum.getAttribute("name"))
	x_values = find_elements(x_enum,"value")
	for x_value in x_values:
		value_name = remove_spaces(x_value.getAttribute("name"))
		ret.values.append(value_name)
	return ret
	
# parse an action xml element
def parse_action(x_action, var_names, constructor = False):
	ret = Action()
	ret.name = uncapitalize(remove_spaces(x_action.getAttribute("name")))
	ret.pre = x_action.getAttribute("pre")
	ret.post = x_action.getAttribute("post")
	for x_param in find_elements(x_action,"parameter"):
		par = parse_variable(x_param)
		ret.parameters.append(par)
	ret.quantified_pre = cvc_close_expression(ret.pre, ret.parameters)

	# constructors modify all the variables
	if constructor:
		ret.mod_vars = var_names
	else:
		ret.mod_vars = cvc_get_primed_variables(ret.post, var_names)
	return ret

# cropping
def cropping(contract, options):
	actions = []
	
	# check if action forcing into crop is requested
	if options.force_in_crop != None:
		action_names = options.force_in_crop.strip().split(",")
		for action_name in action_names:
			action = contract.get_action(action_name)
			if action == None:
				sys.exit("Forcing of action " + action_name + " (does not exist in contract).")
			else:
				actions.append(action)
				contract.actions.remove(action)

	# check if random cropping needs to be performed on the actions set
	if options.random_crop != None:
		if options.random_crop > len(contract.actions):
			sys.exit("Random cropping argument can't be bigger than the amount of actions in the contract.")
		actions += random.sample(contract.actions, options.random_crop)
		
	# use cropped actions if necessary
	if options.force_in_crop != None or options.random_crop != None:
		contract.actions = actions
		
	# check if crop needs to be loaded
	if options.crop_load != None:
		crop_file = open(options.crop_load, 'r')
		action_names = crop_file.readline().strip().split(",")
		crop_file.close()
		actions_crop = []
		for action_name in action_names:
			actions_crop.append(contract.get_action(action_name))
		contract.actions = actions_crop
		
	# check if crop needs to be saved
	if options.crop_save != None:
		crop_file = open(options.crop_save, 'w')  
		for i in range(len(contract.actions)):
			crop_file.write(contract.actions[i].name)
			if i < len(contract.actions) - 1:
				crop_file.write(",")
		crop_file.write("\n")
		crop_file.close()
	
# parse an abstraction (FSM)
def parse_abstraction(x_abstraction, contract):
	ret = FSM()
	
	# fetching attributes
	ret.initial_state = x_abstraction.getAttribute("initial_state")
	
	# fetching states
	x_states = find_elements(x_abstraction,"state")
	for x_state in x_states:
		state = parse_state(x_state, contract)
		ret.states.append(state)
		
	return ret
	
# parse a state
def parse_state(x_state, contract):
	ret = State()
	
	# fetching attributes
	ret.name = x_state.getAttribute("name")
	ret.invariant = x_state.getAttribute("invariant")
	if x_state.getAttribute("uncertain") == "true":
		ret.uncertain = True
		
	# fetching enabled actions
	for x_enabled_action in find_elements(x_state,"enabled_action"):
		name = x_enabled_action.getAttribute("name")
		action = contract.get_action(name)
		if action == None: # it was a constructor, not an action
			action = contract.get_constructor(name)
		ret.enabled_actions.append(action)
		
	# fetching transitions
	x_transitions = find_elements(x_state,"transition")
	for x_transition in x_transitions:
		transition = parse_transition(x_transition)
		ret.transitions.append(transition)
	
	return ret
	
# parse a transition
def parse_transition(x_transition):	
	ret = Transition()

	# fetching attributes
	ret.action = x_transition.getAttribute("action")
	ret.destination = x_transition.getAttribute("destination")
	ret.guard = x_transition.getAttribute("guard")
	if x_transition.getAttribute("violates_invariant") == "true":
		ret.violates_invariant = True
	if x_transition.getAttribute("uncertain") == "true":
		ret.uncertain = True

	return ret

# aux: find children with a given name in an xml structure
def find_elements(doc, elementName):
    ret = []
    for e in doc.childNodes:
        if e.nodeType == e.ELEMENT_NODE and e.localName == elementName:
            ret.append(e)
    return ret

# aux: remove spaces from a name
def remove_spaces(string):
	return string.replace(" ","_")

# aux: uncapitalize a string (first character is lower-cased)
def uncapitalize(string):
	return string[0].lower() + string[1:]
