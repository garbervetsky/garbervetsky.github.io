# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import optparse
import os.path
import re

from model.fsm import State

from util.utils import which

class Options:
	options = None

def parse_options():
	about_str = "Copyright (C) 2009\nG. de Caso, A. Tcach, V. Braberman, D. Garbervetsky, S. Uchitel\n{gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar\nLaFHIS - Departamento de Computación - FCEyN - Universidad de Buenos Aires\nPabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina\nTel: +54-11-4576-3390 eext. 704\n\nThis program comes with ABSOLUTELY NO WARRANTY; for details check the GNU\nGeneral Public License in http://www.gnu.org/licenses/gpl-3.0.txt"

	# parser options
	parser = optparse.OptionParser(usage="%prog [options] file", version="%prog 0.30\n" + about_str)

	parser.add_option("-v", "--verbose",
					action="store_true", dest="verbose", default=False,
					help="print status messages to stderr [default: %default]")
	parser.add_option("--old-algorithm",
					action="store_true", dest="old_algorithm", default=False,
					help="use the slower static algorithm, which checks every state (not recommended) [default: %default]")
	parser.add_option("-s", "--statistics",
					action="store_true", dest="statistics", default=False,
					help="print statistics (time, optimization hits, ...) [default: %default]")
	parser.add_option("-t", "--threads",
					action="store", type="int", dest="threads", default=1,
					help="sets the number of worker threads to N [default: %default]", metavar="N")
			
	output_group = optparse.OptionGroup(parser, "Output options", "These options control how and where the output is produced.")
	output_group.add_option("-o", "--output-file",
					action="store", type="string", dest="output_file", default=None,
					help="write results to FILE [default: stdout]", metavar="FILE")
	format_choices="contractor graphviz ltsa png pdf att"
	output_group.add_option("-f", "--output-format",
					action="store", type="string", dest="output_format", default="contractor",
					help="select the format of results to FORMAT [default: %default; options: "+format_choices+"]", metavar="FORMAT")
	output_group.add_option("--canonical-output",
					action="store_true", dest="canonical_output", default=False,
					help="print output in a canonical way (useful to compare output against other versions of this tool) [default: %default]")
	output_group.add_option("--ltsa-print-invariants",
					action="store_true", dest="ltsa_print_invariants", default=False,
					help="(for ltsa output) print state invariants [default: %default]")
	output_group.add_option("--gv-separator",
					action="store", type="string", dest="gv_separator", default="\\n",
					help="(for graphviz, png and pdf output) use SEP as separator between multiple actions in the same edge [default: %default]", metavar="SEP")
	output_group.add_option("--gv-print-state-numbers",
					action="store_true", dest="gv_print_state_numbers", default=False,
					help="(for graphviz, png and pdf output) print state numbers [default: %default]")
	output_group.add_option("--att-label-file",
					action="store", type="string", dest="att_label_file", default=None,
					help="(for att output) stores FSM labels in FILE", metavar="FILE")
	output_group.add_option("--att-accepting-states",
					action="store", type="string", dest="att_accepting_states", default=None,
					help="(for att output) sets Si,Sj,... as the only accepting states [default: all states are accepting states]", metavar="Si,Sj,..")
	output_group.add_option("--dot-path",
					action="store", type="string", dest="dot_path", default="dot",
					help="set PATH as the location of the (graphviz) dot tool [default: %default]", metavar="PATH")
	parser.add_option_group(output_group)

	prover_group = optparse.OptionGroup(parser, "Prover options", "These options control which prover is used and where it is located.")
	prover_choices="cvc3 yices"
	prover_group.add_option("-p", "--prover",
					action="store", type="string", dest="prover", default="cvc3",
					help="use prover PROVER [default: %default; options: "+prover_choices+"]", metavar="PROVER")
	prover_group.add_option("--cvc3-group-multiple-queries",
					action="store_true", dest="cvc3_group_multiple_queries", default=False,
					help="(for cvc3 prover) group many queries in one multi-query whenever possible.")
	prover_group.add_option("--cvc3-path",
					action="store", type="string", dest="cvc3_path", default="cvc3",
					help="set PATH as the location of the CVC3 prover [default: %default]", metavar="PATH")
	prover_group.add_option("--yices-path",
					action="store", type="string", dest="yices_path", default="yices",
					help="set PATH as the location of the Yices prover [default: %default]", metavar="PATH")
	parser.add_option_group(prover_group)

	cropping_group = optparse.OptionGroup(parser, "Cropping options", "These options allow the use of a subset of actions only.")
	cropping_group.add_option("--random-crop",
					action="store", type="int", dest="random_crop", default=None,
					help="restrict analysis to a (random) actions subset of size N", metavar="N")
	cropping_group.add_option("--force-in-crop",
					action="store", type="string", dest="force_in_crop", default=None,
					help="comma separated list of actions to include in crop regardless of randomization (these actions are not deducted from the size of the random crop)", metavar="ACTION1,ACTION2,...")
	cropping_group.add_option("--crop-save",
					action="store", type="string", dest="crop_save", default=None,
					help="saves comma separated list of used action names to FILE", metavar="FILE")
	cropping_group.add_option("--crop-load",
					action="store", type="string", dest="crop_load", default=None,
					help="loads comma separated list of action names to use from FILE", metavar="FILE")
	parser.add_option_group(cropping_group)

	queries_group = optparse.OptionGroup(parser, "Query contract options", "These options allow you to query certain aspects of the contract")
	queries_group.add_option("--query-transition-model",
					action="store", type="string", dest="query_transition_model", default=None,
					help="Returns a valuation of initial and post variables that allow you to go from Si to Sj using ACTION", metavar="Si,ACTION,Sj")
	queries_group.add_option("--query-restriction",
					action="store", type="string", dest="query_restriction", default="TRUE",
					help="Forces the valuation to satisfy RESTRICTION [default: %default]", metavar="RESTRICTION")
	parser.add_option_group(queries_group)
	
	explorator_group = optparse.OptionGroup(parser, "Explorator options", "These options control the exploration to be produced.")
	explorator_choices="query execute check_pre path_check path_produce"
	explorator_group.add_option("--explorator-mode",
					action="store", type="string", dest="explorator_mode", default="query",
					help="Set explorator mode [default: %default; options "+explorator_choices+"]")
	explorator_group.add_option("--explorator-state",
					action="store", type="string", dest="explorator_state", default=None,
					help="Comma separated list of variables' values (use " + State.INIT_NAME + " for initial state)", metavar="VALUE1,VALUE2,...")
	explorator_group.add_option("--explorator-execute",
					action="store", type="string", dest="explorator_action", default=None,
					help="Set simulator to execute desired action")
	explorator_group.add_option("--explorator-rule-out",
					action="store", type="string", dest="explorator_rule_out", default=None,
					help="Force the resulting state not to be any of S1/S2/... where each Si is VALUE1,VALUE2,... [default: %default]", metavar="S1/S2/...")
	explorator_group.add_option("--explorator-restriction",
					action="store", type="string", dest="explorator_restriction", default="TRUE",
					help="Force the resulting state to satisfy RESTRICTION [default: %default]", metavar="RESTRICTION")
	explorator_group.add_option("--exploration_path",
					action="store", type="string", dest="exploration_path", default=None,
					help="The complete path to be explored, state restrictions and action parameters are optional. Eg.  \n \t (S0_name, S0_restrictions), (A1_name, A1_params, S1_name, S1_restrictions), ..., (A1_name, A1_params, S1_name, S1_restrictions)")
	parser.add_option_group(explorator_group)


	# begin parsing and generate errors if necessary
	(options, args) = parser.parse_args()
	if len(args) != 1:
		parser.error("incorrect number of arguments, expecting XML contract (or contractor) file")
	if not os.path.exists(args[0]):
		parser.error("file does not exist: " + args[0])
	if options.threads <= 0:
		parser.error("threads must be a positive integer")

	# format validation
	if not options.output_format in format_choices.split():
		parser.error("incorrect option of output format, must be one of: " + format_choices)
	if (options.output_format == "pdf" or options.output_format == "png") and which(options.dot_path) == None:
		parser.error("could not find dot tool at " + options.dot_path)
	if options.output_format == "att" and options.att_label_file == None:
		parser.error("label file must be specified when using att format")
	if options.output_format == "att" and options.att_accepting_states != None:
		states = options.att_accepting_states.split(",")
		matcher = re.compile("\A([0-9]+|init)\Z")
		for state in states:
			if len(state) == 0 or state[0] != "S" or matcher.match(state[1:]) == None:
				parser.error("accepting states list must be well formed")
		options.att_accepting_states = states

	# prover validation
	if not options.prover in prover_choices.split():
		parser.error("incorrect option of prover, must be one of: " + prover_choices)
	if options.cvc3_group_multiple_queries and options.prover != "cvc3":
		parser.error("grouping of multiple queries can only be used with the cvc3 prover")
	if which(options.cvc3_path) == None: # cvc3 is needed even when using yices (for translation purpouses)
		parser.error("could not find CVC3 prover at " + options.cvc3_path)
	if options.prover == "yices" and which(options.yices_path) == None:
		parser.error("could not find Yices prover at " + options.yices_path)

	# cropping validation
	if options.random_crop != None and options.random_crop < 0:
		parser.error("random cropping needs a non-negative integer as an argument")
	if options.random_crop != None and options.crop_load != None:
		parser.error("can't use both random cropping and crop loading")

	# explorator validation
	if options.explorator_state != None and not options.explorator_mode in explorator_choices:
		parser.error("incorrect option of explorator mode, must be one of: " + explorator_choices)
	if options.explorator_state != None and (options.explorator_mode == "execute" or options.explorator_mode == "check_pre"):
		if options.explorator_action==None:
			parser.error("exploration action and parameters must be given")

	# queries validation
	if options.query_transition_model != None:
		if len(options.query_transition_model.split(",")) != 3:
			parser.error("query for transition model must have Si,ACTION,Sj format")

	# save input filename for further use
	options.file = args[0]

	# save options in a wrapper class
	Options.options = options
