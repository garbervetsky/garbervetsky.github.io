# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import optparse
import os.path

class GUIOptions:
	options = None

def parse_gui_options():
	about_str = "Copyright (C) 2009\nG. de Caso, A. Tcach, V. Braberman, D. Garbervetsky, S. Uchitel\n{gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar\nLaFHIS - Departamento de Computación - FCEyN - Universidad de Buenos Aires\nPabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina\nTel: +54-11-4576-3390 eext. 704\n\nThis program comes with ABSOLUTELY NO WARRANTY; for details check the GNU\nGeneral Public License in http://www.gnu.org/licenses/gpl-3.0.txt"

	# parser options
	parser = optparse.OptionParser(usage="%prog [options] [file]", version="%prog 0.25\n" + about_str)

	# begin parsing and generate errors if necessary
	(options, args) = parser.parse_args()
	if len(args) > 1:
		parser.error("too many arguments")
	if len(args) == 1:
		if not os.path.exists(args[0]):
			parser.error("file does not exist: " + args[0])
		else:
			options.file = args[0]
	else:
		options.file = None

	# save options in a wrapper class
	GUIOptions.options = options
