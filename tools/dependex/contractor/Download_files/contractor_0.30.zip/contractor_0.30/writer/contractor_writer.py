# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import xml.dom.minidom

def contractor_write_fsm(fsm, contract):
	# Create the minidom document
	x_doc = xml.dom.minidom.Document()
	x_contractor = x_doc.createElement("contractor")
	x_doc.appendChild(x_contractor)

	# Create the <system> base element
	x_contract = x_doc.createElement("contract")
	x_contract.setAttribute("name", contract.name)
	x_contract.setAttribute("invariant", contract.invariant)
	x_contractor.appendChild(x_contract)

	# create enums
	for enum in contract.enums:
		x_enum = x_doc.createElement("enum")
		x_enum.setAttribute("name", enum.name)
		for value in enum.values:
			x_value = x_doc.createElement("value")
			x_value.setAttribute("name", value)
			x_enum.appendChild(x_value)
		x_contract.appendChild(x_enum)
		
	# create vars
	for variable in contract.variables:
		x_contract.appendChild(xml_variable(x_doc, variable))
		
	# create constructors
	for constructor in contract.constructors:
		x_contract.appendChild(xml_action(x_doc, constructor, "constructor"))
		
	# create actions
	for action in contract.actions:
		x_contract.appendChild(xml_action(x_doc, action))

	# Create the <abstraction> base element
	x_abs = x_doc.createElement("abstraction")
	x_abs.setAttribute("initial_state", fsm.initial_state)
	x_contractor.appendChild(x_abs)
	
	# create states
	for state in fsm.states:
		x_state = x_doc.createElement("state")
		x_state.setAttribute("name", state.name)
		x_state.setAttribute("invariant", state.invariant)
		if state.uncertain:
			x_state.setAttribute("uncertain", "true")
		
		for enabled_action in state.enabled_actions:
			x_enabled_action = x_doc.createElement("enabled_action")
			x_enabled_action.setAttribute("name", enabled_action.name)
			x_state.appendChild(x_enabled_action)
		
		for transition in state.transitions:
			x_trans = x_doc.createElement("transition")
			x_trans.setAttribute("action", transition.action)
			x_trans.setAttribute("destination", transition.destination)
			x_trans.setAttribute("guard", transition.guard)
			if transition.violates_invariant:
				x_trans.setAttribute("violates_invariant", "true")
			if transition.uncertain:
				x_trans.setAttribute("uncertain", "true")
			x_state.appendChild(x_trans)
		x_abs.appendChild(x_state)

	# Print our newly created XML
	print x_doc.toprettyxml(indent="  ")

def xml_variable(x_doc, variable, name = "variable"):
	x_variable = x_doc.createElement(name)
	x_variable.setAttribute("name", variable.name)
	x_variable.setAttribute("type", variable.type)
	return x_variable
	
def xml_action(x_doc, action, name = "action"):
	x_action = x_doc.createElement(name)
	x_action.setAttribute("name", action.name)
	x_action.setAttribute("pre", action.pre)
	x_action.setAttribute("post", action.post)
	for parameter in action.parameters:
		x_action.appendChild(xml_variable(x_doc, parameter, "parameter"))
	return x_action
	


