# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys

from model.fsm import State

from reader.options_parser import Options

def att_write_fsm(fsm, contract):
	
	# mapping of action (or constructor) to integer
	action_number = {}
	for i, constructor in enumerate(contract.constructors):
		action_number[constructor.name] = i + 1
	for i, action in enumerate(contract.actions):
		action_number[action.name] = i + len(contract.constructors) + 1

	# first of all write label file
	save_stdout = sys.stdout
	fsock = open(Options.options.att_label_file, 'w')  
	sys.stdout = fsock
	
	for action_name, number in action_number.iteritems():
		print action_name, number
		
	sys.stdout = save_stdout	
	fsock.close()

	# print the FSM in att format
	for state in fsm.states:
		for transition in state.transitions:
			print state_number(contract, state.name), state_number(contract, transition.destination), transition.action
			
	# print accepting states
	for state in fsm.states:
		if Options.options.att_accepting_states == None or state.name in Options.options.att_accepting_states:
			print state_number(contract, state.name)
				
def state_number(contract, state_name):
	if state_name == State.INIT_NAME:
		return init_state(contract)
	else:
		return state_name[1:]
		
def init_state(contract):
	return 2**len(contract.actions)
