# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys

from reader.options_parser import Options

from writer.att_writer import att_write_fsm
from writer.contractor_writer import contractor_write_fsm
from writer.graphviz_writer import graphviz_write_fsm
from writer.image_writer import image_write_fsm
from writer.ltsa_writer import ltsa_write_fsm

def write_fsm(fsm, contract):

	# open file if necessary
	if Options.options.output_file != None:
		save_stdout = sys.stdout
		fsock = open(Options.options.output_file, 'w')  
		sys.stdout = fsock
		
	if Options.options.output_format == "contractor":
		contractor_write_fsm(fsm, contract)
	if Options.options.output_format == "ltsa":
		ltsa_write_fsm(fsm, contract)
	if Options.options.output_format == "graphviz":
		graphviz_write_fsm(fsm, contract)
	if Options.options.output_format == "png" or Options.options.output_format == "pdf":
		image_write_fsm(fsm, contract)
	if Options.options.output_format == "att":
		att_write_fsm(fsm, contract)
		
	# close file if necessary
	if Options.options.output_file != None:
		sys.stdout = save_stdout
		fsock.close()
		
