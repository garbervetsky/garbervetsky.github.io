# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import re

from logic.formulae import cvc_identifier_matcher

VAR_COLOR = "#266BBD"
PAR_COLOR = "#26B1BD"
TYPE_COLOR = "#A82596"

ALT_COLORS = ["#EFEFEF", "#FCFCFC"]
alt_index = [0]

def contract_to_html(contract):
	ret = '<div>'
	ret += f_bigtitle("Contract " + contract.name) + cr()

	if len(contract.enums) > 0:
		ret += cr() + f_title("Enumerate types") + cr()
		for enum in contract.enums:
			enum_text = ""
			enum_text +=  f_type(enum.name) + " = "
			for i in range(len(enum.values)):
				enum_text += enum.values[i]
				if i < len(enum.values) - 1:
					enum_text += " | "
			ret += mono(enum_text) + cr()

	if len(contract.variables) > 0:
		ret += cr() + f_title("Variables") + cr()
		for variable in contract.variables:
			ret += mono(f_var(variable.name) + " : " + f_type(variable.type)) + cr()

	ret += cr() + f_title("Contract invariant") + cr() + f_exp(contract.invariant, contract.var_names()) + cr()

	if len(contract.constructors) > 0:
		ret += cr() + f_title("Constructors") + cr()
		for i, constructor in enumerate(contract.constructors):
			ret += alt_background(f_action(constructor, contract))
			if i < len(contract.constructors) - 1:
				ret += cr()

	if len(contract.actions) > 0:
		ret += cr() + f_title("Actions") + cr()
		for i, action in enumerate(contract.actions):
			ret += alt_background(f_action(action, contract))
			if i < len(contract.actions) - 1:
				ret += cr()

	ret += "</div>"
	return ret 

def f_action(action, contract):
	signature = action.name + "("
	for i, parameter in enumerate(action.parameters):
		signature += f_par(parameter.name) + " : " + f_type(parameter.type)
		if i < len(action.parameters) - 1:
			signature += ", "
	signature += ")"
	ret = mono(signature) + '<ul>'
	ret += "<li>" + f_exp(action.pre, contract.var_names(), action.par_names()) + "</li>"
	ret += "<li>" + f_exp(action.post, contract.var_names(), action.par_names()) + "</li>"
	ret += "</ul>"
	return ret

def f_bigtitle(text):
	return '<span style="font-size: 160%">' + bold(text) + "</span>"

def f_title(text):
	return '<span style="font-size: 110%">' + bold(text) + "</span>"

def f_exp(formula, variable_names, par_names = []):
	ret = formula
	
	# codify < (HTML parser needs this)
	ret = formula.replace("<", "&lt;")
	
	# format variables
	for variable_name in variable_names:
		matcher = cvc_identifier_matcher(variable_name)
		ret = matcher.sub(f_var(variable_name), ret)
		matcher = cvc_identifier_matcher(variable_name + "'")
		ret = matcher.sub(f_var(variable_name + "'"), ret)
		
	# format action parameters
	for par_name in par_names:
		matcher = cvc_identifier_matcher(par_name)
		ret = matcher.sub(f_par(par_name), ret)
		
	# font
	ret = mono(ret)
	
	return ret
	
def f_var(var_name):
	return color(bold(var_name), VAR_COLOR)

def f_par(par_name):
	return color(bold(par_name), PAR_COLOR)

def f_type(type_name):
	return color(bold(type_name), TYPE_COLOR)
	
def cr():
	return "<br/>\n"	

def background(text, color):
	return '<div style="background-color:' + color + '">' + text + "</div>"

def color(text, color):
	return '<span style="color: ' + color + '">' + text + "</span>"
	
def mono(text):
	return '<span style="font-family: monospace">' + text + '</span>'
	
def serif(text):
	return '<span style="font-family: serif">' + text + '</span>'
	
def bold(text):
	return '<span style="font-weight: bold">' + text + '</span>'

def underline(text):
	return '<span style="text-decoration:underline">' + text + '</span>'
	
def alt_background(text):
	color = ALT_COLORS[alt_index[0]]
	alt_index[0] = (alt_index[0] + 1) % len(ALT_COLORS)
	return background(text, color) 
