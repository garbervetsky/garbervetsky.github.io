# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import threading

class MonitorMap:
	def __init__(self):
		self.map = {}
		self.lock = threading.Lock()
		
	def put(self, key, value):
		self.lock.acquire()
		self.map[key] = value
		self.lock.release()
		
	def get(self, key):
		self.lock.acquire()
		ret = self.map[key]
		self.lock.release()
		return ret
		
	def has(self, key):
		self.lock.acquire()
		ret = key in self.map
		self.lock.release()
		return ret
		
	def remove(self, key):
		self.lock.acquire()
		del(self.map[key])
		self.lock.release()
		
	def __str__(self):
		return str(self.map)
	

class MonitorSet:
	def __init__(self):
		self.set = set()
		self.lock = threading.Lock()
		
	def add(self, elem):
		self.lock.acquire()
		self.set.add(elem)
		self.lock.release()
		
	def has(self, elem):
		self.lock.acquire()
		ret = elem in self.set
		self.lock.release()
		return ret


