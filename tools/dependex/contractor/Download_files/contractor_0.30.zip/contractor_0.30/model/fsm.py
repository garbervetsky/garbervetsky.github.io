# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from util.utils import Callable

class FSM:
	def __init__(self):
		self.states = []
		self.initial_state = None

	def get_transition(self, state_orig_name, transition_name, state_dest_name):
		s_orig = self.get_state(state_orig_name)
		if s_orig == None:
			raise Exception, "State of given transition invalid"
		for trans in s_orig.get_transitions(transition_name):
			if trans.action == transition_name and trans.destination == state_dest_name:
				return trans
		return None

	def get_state(self, state_name):
		for state in self.states:
			if state.name == state_name:
				return state

	def __str__(self):
		ret = ""
		for state in self.states:
			ret += str(state)
		ret += "initial state: " + str(self.initial_state) + "\n"
		return ret

class State:
	INIT_NAME = "Sinit"

	def __init__(self):
		self.name = ""
		self.invariant = "TRUE"
		self.transitions = []
		self.enabled_actions = []
		self.uncertain = False

	def get_transitions(self, trans_name):
		transitions = []
		for transition in self.transitions:
			if transition.action == trans_name:
				transitions.append(transition)
		return transitions

	# create a state from its state number (use None to create initial state)
	def from_state_number(state_number, contract):
		ret = State()
		if state_number == None:
			ret.name = State.INIT_NAME
			ret.enabled_actions = contract.constructors
		else:
			ret.name = "S" + str(state_number)
			ret.enabled_actions = []
			n = state_number
			for action in contract.actions:
				ret.invariant += " AND "
				if n & 1 == 0:
					ret.invariant += "NOT "
				else:
					ret.enabled_actions.append(action)
				ret.invariant += "(" + action.quantified_pre + ")"
				n = n >> 1
		return ret
	from_state_number = Callable(from_state_number)

	def __str__(self):
		ret = "state name: " + str(self.name) + " invariant: " + self.invariant 
		ret += " enabled actions: " 
		for enabled_action in self.enabled_actions:
			ret += str(enabled_action.name) + " "
		ret += "\n"
		for transition in self.transitions:
			ret += "\ttransition with " + str(transition) + "\n"
		if self.uncertain:
			ret += " --uncertain--"
		return ret
	
	def __cmp__(self, state):
		if state == None or state.name == None:
			return -1 
		elif self.name == State.INIT_NAME and state.name == State.INIT_NAME:
			return 0
		elif self.name == State.INIT_NAME:
			return -1
		elif state.name == State.INIT_NAME:
			return 1
		else:
			return cmp(self.name, state.name)

class Transition:
	def __init__(self):
		self.action = ""
		self.destination = None
		self.guard = ""
		self.violates_invariant = False
		self.uncertain = False
		
	def __str__(self):
		ret = "action: " + self.action + " destination: " + str(self.destination)
		if self.violates_invariant:
			ret += " --violates invariant--"
		if self.uncertain:
			ret += " --uncertain--"
		return ret

	def __cmp__(self, transition):
		if self.action == transition.action:
			return cmp(self.destination, transition.destination)
		else:
			return cmp(self.action, transition.action)
	
