# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys

from caller.call_command import call_command

command = "python contractor"

# calls contractor
def call_contractor(parameter, contract_xml_path = ""):
	execute_command = command + " " + parameter + " " + contract_xml_path
	out_data, err_data, execution_time, err_code = call_command(execute_command, "")
	
	# check the presence of errors
	if err_data != "":
		sys.stderr.write("Contractor engine quitted with errors. Error was:\n")
		sys.stderr.write(err_data)
		sys.stderr.write("Passed Values:\n")
		sys.stderr.write(command + " " + parameter + " " + contract_xml_path + "\n")
		exit()
		
	return out_data, err_data, execution_time, err_code

# calls the explorator and returns parameters in order to be able to use it in gui
def call_explorator(execution_mode, state, contract_xml_path = "", method = None , exclude_valuations = None, restriction = None):
	parameter = " --explorator-state="+state + " --explorator-mode="

	if execution_mode == "query":
		parameter += "query"
	
	elif execution_mode == "execute" or execution_mode == "check_pre":
		parameter += execution_mode
		if method == None:
			raise Exception, "Must execute a method"
		else:
			parameter += " --explorator-execute=\"" + method + "\"" 
			if (exclude_valuations != None):
				parameter += " --explorator-rule-out=" + exclude_valuations 
			if (restriction != None):
			    parameter += " --explorator-restriction=" + restriction 
	else:
	 raise Exception, "Unrecognized parameter to execute explorator [" + execution_mode  +"]" 
	out_data, err_data, execution_time, err_code = call_contractor(parameter, contract_xml_path)
	
	# get output
	if execution_mode == "query":
		 return out_data.replace("Available actions: ", "").strip()
	elif execution_mode == "check_pre":
		return "NOT" not in out_data
	else:
		# execution_mode == execute
		ret = []
		
		if out_data == "There are no valuations that satisfy the restrictions\n":
			return None
	
		for part in out_data.split("\n\n")[:-1]:
			valuation = []
			for line in part.split("\n"):
				if line == "Valuation:": # gather valuation
					continue
				elif line.startswith("Available actions: "): # gather actions
					actions = line.replace("Available actions: ", "").split(" ")
					 # This is because if we always have one more  
					actions = actions[1:]
				elif line.startswith("State name: "): # gather state name 					
					state_name = line.replace("State name: ", "")
				elif line == "":
					continue
				else:
					valuation.append(line.split(" = ")[1])
			ret.append((actions, valuation, state_name))

		return ret

#calls contractor to generate .dot (graphviz)
def generate_dot(fsm_xml, filename_to_generate):
	parameter = " -f graphviz --gv-print-state-numbers -o " + filename_to_generate
	
	out_data, err_data, execution_time, err_code = call_contractor(parameter, fsm_xml)
	
	# check the presence of errors
	if err_data != "":
		sys.stderr.write("Contractor quitted with errors. Error was:\n")
		sys.stderr.write(err_data)
		sys.stderr.write("Passed Values:\n")
		sys.stderr.write(execute_command + " "+ parameter +"\n")
		exit()
	
	# No output 
	return

#calls contractor to get things of feasability
def check_feasibility(si, action, sj, contract_path, restrictions = None):
	parameter = "--query-transition-model=" + si + "," + action + "," + sj
	if restrictions != None:
		parameter += " --query-restriction= \"" + restrictions + "\""
		
	out_data, err_data, execution_time, err_code = call_contractor(parameter, contract_path)
	
	# check the presence of errors
	if err_data != "":
		sys.stderr.write("Contractor quitted with errors. Error was:\n")
		sys.stderr.write(err_data)
		sys.stderr.write("Passed Values:\n")
		sys.stderr.write(execute_command + " "+ parameter +"\n")
		exit()
	
	# No output 
	return out_data


