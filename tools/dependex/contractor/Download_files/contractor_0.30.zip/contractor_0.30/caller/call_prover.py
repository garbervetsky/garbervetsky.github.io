# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import os
import time
import threading
import tempfile

from caller.call_command import call_command

from reader.options_parser import Options

from stats.statistics import Statistics

from util.exit import exit

def call_prover(contents, amount_of_queries = 1):

	# which prover to use?
	if Options.options.prover == "cvc3":
		command = Options.options.cvc3_path + " -output-lang smtlib"
	else:
		command = Options.options.cvc3_path + " -output-lang smtlib +translate | " + Options.options.yices_path + " -smt"

	out_data, err_data, execution_time, err_code = call_command(command, contents)
	
	# compute prover time
	Statistics.prover_time_add(execution_time)
		
	# check the presence of errors
	if err_data != "":
		sys.stderr.write("Prover quitted with errors, check the contract syntax. Error was:\n")
		sys.stderr.write(contents)
		sys.stderr.write("\n")
		sys.stderr.write(err_data)
		exit()
	
	# get output
	out = []
	splitted_out = out_data.strip().split("\n")
	for i in range(len(splitted_out)):
		out_line = splitted_out[i]
		# warning for unknown results
		if "unknown" in out_line:
			Statistics.prover_unknown_inc()
			sys.stderr.write("Warning! 'unknown' response from prover.\n")
			if Options.options.verbose:
				sys.stderr.write("For query number " + str(i + 1) + " of input:\n")
				sys.stderr.write(contents)
				sys.stderr.write("\n")
		elif "unsat" in out_line:
			Statistics.prover_unsat_inc()
		elif "sat" in out_line:
			Statistics.prover_sat_inc()
#		else: # FIXME Por Ale: Volver a poner, pero permitir mi parte
#			sys.stderr.write("Prover response is not recognized: " + out_line + "\n") # FIXME Por Ale: Volver a poner, pero permitir mi parte
#			exit() # FIXME Por Ale: Volver a poner, pero permitir mi parte
	
		out.append(out_line.strip())
			
	if amount_of_queries == 1 and not "COUNTERMODEL" in contents:
		return out[0]
	else:
		return out
