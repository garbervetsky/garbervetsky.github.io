# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import os
import time
import threading
import tempfile
import subprocess

from stats.statistics import Statistics

from util.exit import exit

# calls a command from commandline, return out, err and time of execution
# gets command to execute and if wanted contents of the input
def call_command(command, input):
	init_time = time.time()
	
  # create in, out and err temp files
	in_file = tempfile.TemporaryFile()
	out_file = tempfile.TemporaryFile()
	err_file = tempfile.TemporaryFile()

  # write contents to in_file
	in_file.write(input)
	in_file.seek(0)

  # call command 
	p = subprocess.Popen(command, shell=True, stdin=in_file, stdout=out_file, stderr=err_file)
	p.communicate()

  # close in
	in_file.close()

  # read out
	out_file.seek(0)
	out_data = out_file.read()
	out_file.close()

  # read err
	err_file.seek(0)
	err_data = err_file.read()
	err_file.close()
	execution_time = time.time() - init_time

	err_code = p.returncode
	return out_data, err_data, execution_time, err_code
	
