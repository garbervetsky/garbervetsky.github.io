# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#	LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#	Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#	Tel: +54-11-4576-3390 eext. 704
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

# This has the classes representing an exploration.

import string

from reader.options_parser import Options
from logic.formulae import *
from new_algorithm.explorer import *
from model.contract import *
from caller.call_prover import *
from caller.call_contractor import *

# not nice, but needs refactoring of contract_parser in order to avoid this
from reader.contract_parser import *

#some constants
first_state = State.INIT_NAME

# a Exploration is the abstraction of a real exploration/simulation.
class Exploration:
	def __init__(self):
		self.valuation = [first_state] # The valuation
		self.state_name = first_state
		self.possible_states_names = [] # Possible states  we can be in
		self.possible_valuations = {} # Possible valuation for each possible state
		self.possible_actions = {} # Possible actions for each possible state
		self.avail_actions = None 
		self.contract = None # The Contract 
		self.contract_path = None# The contract path, used by the explorator
		self.stack_back = [] # The stack of states and actions used in exploration.
		self.stack_forward = [] # The stack of states and actions used in exploration for forward
		self.fsm = None # FIXME  the fsm. Here is not used, but as returned by parse_contractor, we save it... But might be none.

	#define contract path
	def set_contract_path(self, contract_path):
		self.contract_path = contract_path
		self.contract, self.fsm = parse_contractor(contract_path)

	def get_contract(self):
		return self.contract

	def get_fsm(self):
		return self.fsm
	
	# returns the actual state of the exploration
	def get_actual_state_name(self):
		return self.state_name

	# returns actual valuation
	def get_actual_valuation(self):
		return self.valuation

	# query if a given parameter set satisfies an action precondition
	def check_precondition_is_satisfied(self, action_name, parameters):
		if action_name not in self.avail_actions:
			return False
		
		# if we are in a constructor
		if self.valuation == None:
			valuation_str = first_state 
		else:
			valuation_str = self.list_as_valuation(self.valuation)
		
		# construct action with parameters (if any)
		method = action_name
		if parameters != None:
			method += "["
			method += parameters
			method += "]"
		
		return call_explorator("check_pre", valuation_str, self.contract_path, method)

	# queries the explorator for possible actions
	def query_actions(self):
		return call_explorator("query", self.list_as_valuation(self.valuation), self.contract_path).split(" ")

#converts from an array to the form:
# S1/S2/S3 where SX = a,b,c....
	def valuations_to_argument(self, valuations):
		arg = ""
		for val in valuations:
			arg += self.array_as_string(val)+"/"
					 #remove last /
		return arg[:-1]


	def array_as_string(self, array):
		array_str = ""
		for element in array:
			array_str += element + ","
		#remove last ","
		return array_str[:-1]
	
	#list as valuation
	def list_as_valuation(self, valuation):

		valuation_str = self.array_as_string(valuation)
		# remove spaces and ( and ) from negative numbers
		valuation_str = valuation_str.replace("(", "")
		valuation_str = valuation_str.replace(")", "")
		valuation_str = valuation_str.replace(" ", "")
		return valuation_str
		
	  # calls the explorator and returns the returned valuation
	def execute_explorator(self, action_name, parameters, valuation, exclude_valuations = None, restriction = None):

		# if we are in a constructor
		if valuation == None:
			valuation_str = first_state 
		else:
			valuation_str = self.list_as_valuation(valuation)
			
		method = action_name
		if parameters != None:
			method += "["
			method += parameters
			method += "]"
		
		#Must be sent between ""
		if (restriction != None) and (len(restriction)) > 0 :
			restriction = "\""+ restriction + "\""
		else:
			restriction = None
		if exclude_valuations != None:
			exclude_valuations = "\"" + self.valuations_to_argument(exclude_valuations) + "\""
		return  call_explorator("execute", valuation_str, self.contract_path, method, exclude_valuations, restriction )

	# see if there is another possible valuation for the future state
	# receives the future state name
	# Comes from the actual state
	# Receives an array of valuations to exclude and a formula
	# If there is not other one it return None
	def get_another_valuation(self, action, parameters, state_name, exclude_valuations, restriction = None):
		ret_valuation = None
		# FIXME TODO verify restriction
		possible_destinations = self.execute_explorator(action, parameters, self.valuation, exclude_valuations, restriction)
		if possible_destinations !=None:
			for actions, internal_state, state_name2 in possible_destinations:
				if state_name2 == state_name:
					if internal_state not in self.possible_valuations[state_name]:
						self.possible_valuations[state_name].append(internal_state)
						ret_valuation = internal_state
		return ret_valuation
	
	# run a step of the exploration
	def run_step(self, action_name, parameters):
		# No need to check action and parameters validity, as is done in explorator
		self.possible_valuations = {}
		self.possible_actions = {}
		self.possible_states_names = []
		possible_destinations = self.execute_explorator(action_name, parameters, self.valuation)
		for actions, internal_state, state_name in possible_destinations:
			self.possible_valuations[state_name] = [internal_state]
			self.possible_actions[state_name] = actions
			if state_name not in self.possible_states_names:
				self.possible_states_names.append(state_name)
		return self.possible_states_names

	# gets the names of the possible states
	def get_possible_states_names(self):
		return self.possible_states_names

	# Returns the possible valations for a state. If we have tried more than one, then
	# return all known valuations
	# only works for a possible state
	def get_possible_valuations(self, state_name):
		if self.possible_states_names != None and self.possible_states_names != []:
			return self.possible_valuations[state_name]
	
	# we provide the used history
	def get_history_stack_back(self):
		return self.stack_back

		# we provide the forward history
	def get_history_stack_forward(self):
		return self.stack_forward
	

	#history forward
	def history_forward(self):
		if len(self.stack_forward) > 0:
			values = self.stack_forward[-1]
			self.avail_actions = values[0]
			self.valuation = values[1]
			self.state_name = values[2]
			self.possible_states_names = []
			self.possible_valuations = {}
			self.stack_back.append(self.stack_forward[-1])
			self.stack_forward = self.stack_forward[:-1]
		else:
			raise "No elements in stack !!"
		return None
	
	
	
	#return history stack in one
	def history_back(self):
		if len(self.stack_back) > 0:
			values = self.stack_back[-2]
			self.avail_actions = values[0]
			self.valuation = values[1]
			self.state_name = values[2]
			self.possible_states_names = []
			self.possible_valuations = {}
			self.stack_forward.append(self.stack_back[-1])
			self.stack_back = self.stack_back[:-1]
		else:
			raise "No elements in stack !!"
		return None
	
	# Go back to the first state
	def history_restart(self):
		rev = self.stack_back[:]
		rev.reverse()
		rev = rev[:-1] ## The first one is going to be put again with set_ actual_state
		if len(self.stack_forward) > 0:
			self.stack_forward.extend(rev) #reversed items as for forward will be used in other order
		else:
			self.stack_forward = rev
		
		self.stack_back = []
		self.set_actual_state(first_state)
		return None
	
	# gets the names of the possible actions
	def get_possible_actions_names(self):
		return self.avail_actions

	# return to a state without workflow being done
	def reset_posibilities(self):
		self.possible_valuations = {}
		self.possible_actions = {}
		self.possible_states_names = []
		
	# Define actual action from possible ones
	# It can take the valuation if we aren't using the standard one
	# TODO Check if valuation is possible for that state
	# TODO Check if action and parameters are valid
	def set_actual_state(self, state_name, valuation = None, action_name = None, action_parameters = None):
		if state_name != first_state:
			if state_name not in self.possible_states_names:
				raise Exception, "State selected no in possible ones State = [" + state_name + "]. Possible ones = ["+ self.possible_states_names + "]"
			if valuation == None:
				valuation = self.possible_valuations[state_name]
				#tipo = type(self.valuation)
			self.valuation = valuation
			self.avail_actions = self.possible_actions[state_name]
		else:
			self.valuation = [first_state]
			self.avail_actions = self.query_actions()
		self.state_name = state_name
		if len(self.stack_back) != 0:
			# Does not come from first move or reset (so it's a move from exploration)
			self.stack_forward = []	
		self.stack_back.append([self.avail_actions, self.valuation, self.state_name, action_name, action_parameters])
		self.possible_states_names = []
		self.possible_valuations = {}
