# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#	LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#	Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#	Tel: +54-11-4576-3390 eext. 704
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

# This has the classes representing an exploration.

import string

from reader.options_parser import Options
from logic.formulae import *
from new_algorithm.explorer import *
from model.contract import *
from caller.call_prover import *
from caller.call_contractor import *

# A state in our exploration path
class Path_State:
	def __init__(self, name, restriction = None):
		self.name = name
		self.restriction = restriction 

	def get_name(self):
		return self.name
	
	def get_restriction(self):
		return self.restriction
		
#An action in our exploration path
class Path_Action:
	def __init__(self, action_name, params = None):
		self.name = action_name
		self.params = params
		
	def get_name(self):
		return name
	
	def get_parameters(self):
		return params
	
# a transition for our exploration path. Just a tuple, but with renames
class Path_Transition:
	def __init__(self, path_action = None, path_state = None):
		self.path_action = path_action
		self.path_state = path_state
		
	def get_action(self):
		return self.path_action
	
	def get_state(self):
		return self.path_state
	
	
# 
	
class Path:
	def __init__(self, path_state):
		self.path = []
		self.init_state = path_state

	
	def append_connection(self, action, path_state):
		self.path.append(Path_Transition(action,path_state))
	
	# TOD FUTURE METHODS TO DEVELOP
	#  changes a node
	def change(self, position, transition):
		return 
 
 	#Appends without knowing the action taken  (Which action to take to get to a given state ???)
 	def append_state(path_state):
  		self.path.append(Path_Transition(None, path_state))
  		
  	#Appends an action without knowing the resulting state
  	def append_action(path_action):
  		self.path.append(Path_Transition(path_action, None))
  		
  	#reads and creates a Path from String (Static as it's a factory Method)
  	def read_from_string(path_str):
  		# Strings read are in the form of [(S0_name, S0_restrictions), (A1_name, A1_params, S1_....,,) .....(An, Sn)]
  		# That's an array of quadruples (and the first one a tuple)
  		# We only check here the size. The contents are to be checked in the contractor/query part
  		path_array = eval(path_str)
  
    	# Minnimun 3 elements  and always a transition plus an action. (that's why %)
  		if (len(path_array) < 3) or (((len(path_array) -1) % 2) != 0):
  			raise Exception('Value not a possible path' + path_str)
  		
  		name, rest = path_array[0]
  		path_array = path_array[1:]
  		path = Path(Path_State(name, rest))
  		for elem in path_array:
  			action, aparams, state, state_rest = elem
  			path.append_connection(Path_Transition(Path_Action(action, aparams), Path_State(state, state_rest)))
  		
  		return path
  		