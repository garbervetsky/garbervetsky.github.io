# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

# This file has all the explorator methods.

import string
import sys

from caller.call_prover import call_prover

from logic.formulae import cvc_identifier_matcher, cvc_define_variable, cvc_assert, cvc_check_validity, cvc_prime_variables, cvc_check_satisfiability, cvc_countermodel

from model.contract import Variable
from model.fsm import State

from new_algorithm.explorer import get_availabilities, complete_uncertainties

from reader.options_parser import Options

# valuation: dictionary of variables (name + type) and values
class Valuation:
	def __init__(self):
		self.values = {}
	
	def __str__(self):
		if self.is_initial():
			return "initial_valuation\n"
		else:
			ret = ""
			for variable, value in self.values.iteritems():
				ret += str(variable) + " " + value + "\n"
			return ret
	
	def __setitem__(self, variable, value):
		self.values[variable] = value
		
	def __getitem__(self, variable):
		return self.values[variable]
		
	# returns True iff this is the initial valuation (constructed from Sinit)
	def is_initial(self):
		return len(self.values) == 0
	
	# primes all the variables in variable_names and retains values
	def prime_variables(self, variable_names):
		new_values = {}
		for variable, value in self.values.iteritems():
			if variable.name in variable_names:
				new_values[Variable(variable.name + "'", variable.type)] = value
			else:
				new_values[variable] = value
		self.values = new_values
	
	# translates it to a cvc statement
	def to_cvc(self):
		ret = ""
		if not self.is_initial():
			for variable, value in self.values.iteritems():
				ret += cvc_define_variable(variable)
				ret += cvc_assert(equality(variable, value))
		return ret
	
	# checks that an action pre is satisfied by the valuation
	def check_satisfies_precondition(self, action, action_parameters):
		cvc = self.to_cvc()
		for i, parameter in enumerate(action.parameters):
			cvc += cvc_define_variable(action.parameters[i]) 
			cvc += cvc_assert(equality(action.parameters[i], action_parameters[i]))
		return call_prover(cvc + cvc_check_validity(action.pre)) == "unsat"
			
		
	# checks that a valuation satisfies the contract invariant
	def check_satisfies_invariant(self, contract):
		if self.is_initial():
			return
		else:
			to_be_sent_cvc = self.to_cvc()
			to_be_sent_cvc += cvc_check_validity(contract.invariant)
			if call_prover(to_be_sent_cvc) != "unsat":
				sys.exit("valuation violates contract invariant")
				
	# return available actions from this valuation
	def get_available_actions(self, contract):
		actions = []
		
		# on the first state we can only choose a constructor
		if self.is_initial():
			return contract.constructor_names()
		else:
			to_be_sent_cvc = self.to_cvc()
			for action in contract.actions:
				if (call_prover(to_be_sent_cvc + cvc_check_validity(action.quantified_pre)) == "unsat"):
					actions.append(action.name)
			return actions
			
	# Explores execution of action, with its parameters from this valuation
	def explore_action(self, contract, action, action_parameters):
		ret = []				
		cvc = self.to_cvc()
		
		# define primed variables
		primed_variables = [ Variable(v + "'", contract.get_variable(v).type) for v in action.mod_vars ]
		for pv in primed_variables:
			cvc += cvc_define_variable(pv)
		
		# first we prepare the variables of the action
		for i, parameter in enumerate(action.parameters):
			cvc += cvc_define_variable(action.parameters[i]) 
			cvc += cvc_assert(equality(action.parameters[i], action_parameters[i]))

		# we assert the effect of the action
		cvc += cvc_assert(action.post) 
		
		# we add the exploration restriction
		cvc += cvc_assert(Options.options.explorator_restriction)
	
		# parse ruled-out valuations
		if Options.options.explorator_rule_out != None:
			for ruled_out_part in Options.options.explorator_rule_out.split("/"):
				ruled_out_valuation = parse_valuation(contract, ruled_out_part)
				ruled_out_valuation.prime_variables(action.mod_vars)
				ruling_out = "TRUE"
				for variable, value in ruled_out_valuation.values.iteritems():
					ruling_out += " AND " + equality(variable,value)
				cvc += cvc_assert("NOT(" + ruling_out + ")")
									
		# we want to deambiguate non-determinism. so we need the set of states that can be reached from here
		availabilities = get_availabilities(action, cvc, contract)
		possible_patterns = complete_uncertainties(availabilities)
		for pattern in possible_patterns:
			
			# create state from pattern
			pattern_long = 0
			for i in range(len(contract.actions)):
				if pattern[i] == '1':
					pattern_long += 1 << i
			candidate_destination_state = State.from_state_number(pattern_long, contract)
			
			# destination in candidate invariant
			dest_invariant = cvc_prime_variables(candidate_destination_state.invariant, action.mod_vars)
			
			# see if we can reach it
			this_cvc = cvc + cvc_assert(dest_invariant) + cvc_check_satisfiability(pushpop=False)
			if call_prover(this_cvc) == "sat":
				# get valuation
				prover_response = call_prover(this_cvc + cvc_countermodel())
		
				# now we need to read the variables, in order to return the desired state (values and state number). We are only interested in primed (changed) values.
				new_values = get_values_from_prover(primed_variables, prover_response)
																
				# we construct a new valuation using the new primed variables
				new_valuation = Valuation()
				for variable in contract.variables:
					if variable.name + "'" in new_values:
						new_valuation[variable] = new_values[variable.name + "'"]
					else:
						new_valuation[variable] = self.values[variable]
				ret.append(new_valuation)
		return ret

#generates an exploration
def exploration_analyze(contract):
	#TODO Test possible actions for each state, etc.
	pass
	
# explorator main interface
def explorator_main_interface(contract):
	if Options.options.explorator_mode == " path_check" or Options.options.explorator_mode == 'path_produce':
		exploration_analyze(contract)
		return
	
	# parse the valuation
	valuation = parse_valuation(contract, Options.options.explorator_state)
	valuation.check_satisfies_invariant(contract)

	if Options.options.explorator_mode == "query":
		# let's see what can we do from this action
		print "Available actions:", 
		for avail_action in valuation.get_available_actions(contract):
			print avail_action,
		print
		
	elif Options.options.explorator_mode == "execute" or Options.options.explorator_mode == "check_pre" :
		# Let's rock and roll.............
		(action_name, action_parameters) = parse_action(Options.options.explorator_action)
		if valuation.is_initial():
			action = contract.get_constructor(action_name)
		else:
			action = contract.get_action(action_name)
		
		if action == None:
			sys.exit("action " + action_name + " is not present in the contract")
		if len(action_parameters) != len(action.parameters):
			sys.exit("action " + action_name + " has to be used with " + str(len(action.parameters)) + " parameters")
		for i, ap in enumerate(action_parameters):
			if ap == None or ap == "":
				sys.exit("parameter " + str(i+1) + " of action " + action_name + " is empty")

		avail_actions = valuation.get_available_actions(contract)	
		
		if not action_name in avail_actions:
			sys.exit("action " + action_name + " not allowed from given valuation")

		# check that we can execute that action in the given state
		satisfies_pre = valuation.check_satisfies_precondition(action, action_parameters)
		if Options.options.explorator_mode == "check_pre":
			if satisfies_pre:
				print "Precondition is satisfied"
			else:
				print "Precondition is NOT satisfied"
			return
		else:
			if not satisfies_pre:
				sys.exit("action parameters do not comply with precondition of " + action.name)	
			
		new_valuations = valuation.explore_action(contract, action, action_parameters)
		if len(new_valuations) == 0:
			print "There are no valuations that satisfy the restrictions"
		else:	
			for new_valuation in new_valuations:
				print "Valuation:"
				for variable in contract.variables:
					print "\t" + variable.name + " = " + new_valuation[variable]
			
				new_avail_actions = new_valuation.get_available_actions(contract)
				print "Available actions: ", 
				for avail_action in new_avail_actions:
					print avail_action,
				print
				
				new_state = get_state_name(new_avail_actions, contract)
				print "State name: S"+ str(new_state)
				print

# converts a list of enabled actions to a state name
def get_state_name(actions, contract):
	state_name = long(0)
	contract_actions = contract.action_names()
	for i, caction in enumerate(contract.action_names()):
		if caction in actions:
			state_name += 1 << i
	return state_name	

#from a separated list of values, it returns a valuation. 
def parse_valuation(contract, var_values):
	ret = Valuation()
	parsed = string.split(var_values, ",")
	if parsed != [State.INIT_NAME]:
		if len(parsed) != len(contract.variables):
			sys.exit("valuation should have as many values as variables in the contract")

		for i, value in enumerate(parsed):
			ret[contract.variables[i]] = value
	return ret
		
# parse parameters and action name
def parse_action(explorator_action):
	data = string.split(explorator_action, "[")
	action = data[0]
	if len(data) > 1:
		data = string.split(data[1], "]")
		action_parameters = string.split(data[0], ",")
	else:
		action_parameters = ""
	return (action, action_parameters)
		
# gets the values of the given variables from a prover response (in SMT format)
def get_values_from_prover(variables, response):
	values = {}
	for variable in variables:
		finder = cvc_identifier_matcher(variable.name)
		for line in response:
			place = finder.search(line)
			if place != None:
				if variable.type == "BOOLEAN":
					if line.find("(not " + variable.name + ")") != -1:
						values[variable.name] = "FALSE"
					else:
						values[variable.name] = "TRUE"
				else:
					line = line = line.replace(":assumption (= " + variable.name + " ","")
					line = line[:-1]
					# XXX this is an ugly hack (the new CVC3 smt output uses '~' instead of '-')
					if line.startswith("(~"):
						line = line.replace("(~","(-")
					values[variable.name] = line
	return values
	
# auxiliary: produces an equality using the appropiate symbol depending on the type
def equality(variable, value):
	if variable.type == "BOOLEAN":
		return variable.name + " <=> " + value
	else:
		return variable.name + " = " + value
