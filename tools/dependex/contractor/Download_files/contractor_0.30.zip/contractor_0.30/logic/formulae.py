# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import re

# surround an expression with a quantifier for each of the variables
def cvc_close_expression(expression, variables, quant="EXISTS"):
	ret = expression
	for v in variables:
		if v.type != "BOOLEAN":
			m = cvc_identifier_matcher(v.name)
			if m.search(ret) != None:
				ret = quant + " (" + v.name + ":" + v.type + "): (" + ret + ")"
		else:
			if quant == "EXISTS":
				op = "OR"
			else:
				op = "AND"
				# FIXME No usar ret.replace, usar un matcher
			ret = "(" + ret.replace(v.name,"TRUE") + ") " + op + " (" + ret.replace(v.name,"FALSE") + ")"
	return ret

# define an enumerate variable type
def cvc_define_enumerate(enum):
	return "DATATYPE " + str(enum) + " END;\n"
		
# define the given variable (with the suffix on its name)
def cvc_define_variable(variable, suffix=""):
	# use INT to encode NAT
	if variable.type == "NAT":
		var_type = "INT"
	else:
		var_type = variable.type
	
	ret = variable.name + suffix + " : " + var_type + ";\n"
	
	# add bounds assertion for NAT variables
	if variable.type == "NAT":
		ret += cvc_assert(variable.name + suffix + " >= 0")
	
	return ret

# assert the given expression
def cvc_assert(expression):
	return "ASSERT " + expression + ";\n"

# check satisfiability of the given expression	
def cvc_check_satisfiability(expression = "TRUE", pushpop = True):
	ret = ""
	if pushpop:
		ret += "PUSH;\n\t"
	ret += "CHECKSAT " + expression + ";\n"
	if pushpop:
		ret += "POP;\n"
	return ret
	
# check universal validity of the given expression
def cvc_check_validity(expression, pushpop = True):
	ret = ""
	if pushpop:
		ret += "PUSH;\n\t"
	ret += "QUERY " + expression + ";\n"
	if pushpop:
		ret += "POP;\n"
	return ret
	
# prime variables in an expression
def cvc_prime_variables(expression, variable_names):		
	ret = expression
	for variable_name in variable_names:
		replacer = cvc_identifier_matcher(variable_name)
		ret = replacer.sub(variable_name + "'", ret)
	return ret

# ask for a valuation to the prover
def cvc_countermodel():
	return "COUNTERMODEL;\n"

# regular expression that matches a whole identifier
def cvc_identifier_matcher(identifier):
	chars = "[,.\[\] \t\n;()\-\+\*/%=<>\\\\]"
	return re.compile("((?<=" + chars + ")|\A)" + identifier + "(?=" + chars + "|$)")
	
# returns the set of variables names such that they appear primed on the expression
def cvc_get_primed_variables(expression, candidate_variable_names):
	ret = []
	for var_name in candidate_variable_names:
		finder = cvc_identifier_matcher(var_name + "'")
		if finder.search(expression) != None:
			ret.append(var_name)
	return ret
			
