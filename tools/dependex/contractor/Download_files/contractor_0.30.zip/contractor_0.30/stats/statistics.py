# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import threading
import time
import sys

from reader.options_parser import Options

from util.utils import Callable

class Statistics:
	lock = threading.Lock()

	initial_time = time.time()

	prover_time = 0
	def prover_time_add(time):
		Statistics.lock.acquire()
		Statistics.prover_time += time
		Statistics.lock.release()
	prover_time_add = Callable(prover_time_add)

	states = 0
	def states_add(states):
		Statistics.lock.acquire()
		Statistics.states += states
		Statistics.lock.release()
	states_add = Callable(states_add)

	transitions = 0
	def transitions_add(transitions):
		Statistics.lock.acquire()
		Statistics.transitions += transitions
		Statistics.lock.release()
	transitions_add = Callable(transitions_add)
	
	prover_sat = 0
	def prover_sat_inc():
		Statistics.lock.acquire()
		Statistics.prover_sat += 1
		Statistics.lock.release()
	prover_sat_inc = Callable(prover_sat_inc)

	prover_unsat = 0
	def prover_unsat_inc():
		Statistics.lock.acquire()
		Statistics.prover_unsat += 1
		Statistics.lock.release()
	prover_unsat_inc = Callable(prover_unsat_inc)

	prover_unknown = 0
	def prover_unknown_inc():
		Statistics.lock.acquire()
		Statistics.prover_unknown += 1
		Statistics.lock.release()
	prover_unknown_inc = Callable(prover_unknown_inc)
	
	# only for on-the-fly algorithm
	states_visited_hit = 0
	def states_visited_hit_inc():
		Statistics.lock.acquire()
		Statistics.states_visited_hit += 1
		Statistics.lock.release()
	states_visited_hit_inc = Callable(states_visited_hit_inc)

	states_inconsistent_hit = 0
	def states_inconsistent_hit_inc():
		Statistics.lock.acquire()
		Statistics.states_inconsistent_hit += 1
		Statistics.lock.release()
	states_inconsistent_hit_inc = Callable(states_inconsistent_hit_inc)

	states_new = 0
	def states_new_inc():
		Statistics.lock.acquire()
		Statistics.states_new += 1
		Statistics.lock.release()
	states_new_inc = Callable(states_new_inc)

	secondstep_true = 0
	def secondstep_true_inc():
		Statistics.lock.acquire()
		Statistics.secondstep_true += 1
		Statistics.lock.release()
	secondstep_true_inc = Callable(secondstep_true_inc)

	secondstep_false = 0
	def secondstep_false_inc():
		Statistics.lock.acquire()
		Statistics.secondstep_false += 1
		Statistics.lock.release()
	secondstep_false_inc = Callable(secondstep_false_inc)

	secondstep_unknown = 0
	def secondstep_unknown_inc():
		Statistics.lock.acquire()
		Statistics.secondstep_unknown += 1
		Statistics.lock.release()
	secondstep_unknown_inc = Callable(secondstep_unknown_inc)

	# only for old algorithm
	inconsistent_states = 0
	def inconsistent_states_inc():
		Statistics.lock.acquire()
		Statistics.inconsistent_states += 1
		Statistics.lock.release()
	inconsistent_states_inc = Callable(inconsistent_states_inc)

def print_statistics():
	# execution time
	print >> sys.stderr, "Execution took %d days, %d hours, %d minutes and %.2f seconds." % dhms(time.time() - Statistics.initial_time)
	print >> sys.stderr, "Theorem proving used %d days, %d hours, %d minutes and %.2f seconds." % dhms(Statistics.prover_time)
	print >> sys.stderr, ""
	
	# amount of states and transitions
	print >> sys.stderr, "Output has %d states and %d transitions." % (Statistics.states, Statistics.transitions)
	print >> sys.stderr, ""
	
	# prover statistics
	prover_total = Statistics.prover_sat + Statistics.prover_unsat + Statistics.prover_unknown
	print >> sys.stderr, "Prover returned definite answer %d times (%.2f%%)." \
		% (Statistics.prover_sat + Statistics.prover_unsat, float(Statistics.prover_sat + Statistics.prover_unsat) / prover_total * 100)
	print >> sys.stderr, "Prover returned unknown answer %d times (%.2f%%)." \
		% (Statistics.prover_unknown, float(Statistics.prover_unknown) / prover_total * 100)
	print >> sys.stderr, ""
	
	# statistics for different algorithms
	if Options.options.old_algorithm:
		# inconsistent states
		print >> sys.stderr, "Inconsistent states found = %d (%.2f%%)" \
			% (Statistics.inconsistent_states, float(Statistics.inconsistent_states) / (Statistics.states + Statistics.inconsistent_states) * 100)
	else:
		# states and hits
		states_total = Statistics.states_visited_hit + Statistics.states_inconsistent_hit + Statistics.states_new
		print >> sys.stderr, "States not added due to already visited          = %d (%.2f%%)" \
			% (Statistics.states_visited_hit, float(Statistics.states_visited_hit) / states_total * 100)
		print >> sys.stderr, "States not added due to be known as inconsistent = %d (%.2f%%)" \
			% (Statistics.states_inconsistent_hit, float(Statistics.states_inconsistent_hit) / states_total * 100)
		print >> sys.stderr, "States checked if consistent (first appearence)  = %d (%.2f%%)" \
			% (Statistics.states_new, float(Statistics.states_new) / states_total * 100)
		print >> sys.stderr, ""
	
		# second step availability
		secondstep_total = Statistics.secondstep_true + Statistics.secondstep_false + Statistics.secondstep_unknown
		print >> sys.stderr, "Actions fixed due to certainty of availability   = %d (%.2f%%)" \
			% (Statistics.secondstep_true, float(Statistics.secondstep_true) / secondstep_total * 100)
		print >> sys.stderr, "Actions fixed due to certainty of unavailability = %d (%.2f%%)" \
			% (Statistics.secondstep_false, float(Statistics.secondstep_false) / secondstep_total * 100)
		print >> sys.stderr, "Actions explored due to uncertainty              = %d (%.2f%%)" \
			% (Statistics.secondstep_unknown, float(Statistics.secondstep_unknown) / secondstep_total * 100)
	
	
def dhms(s):
   temp = float(s) / (60*60*24)
   d    = int(temp)
   temp = (temp - d) * 24
   h = int(temp)
   temp = (temp - h) * 60
   m = int(temp)
   temp = (temp - m) * 60
   sec = temp
   return d,h,m,sec

