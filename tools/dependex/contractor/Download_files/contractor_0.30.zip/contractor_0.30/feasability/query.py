# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys

from caller.call_prover import call_prover

from explore.explorator import get_values_from_prover

from logic.formulae import cvc_assert, cvc_check_satisfiability, cvc_define_variable, cvc_prime_variables

from model.fsm import State
from model.contract import Variable

from reader.options_parser import Options

def query_main_interface(contract):
	parts = Options.options.query_transition_model.split(",")
	origin = parts[0]
	action = parts[1]
	destination = parts[2]

	# origin and destination must be present
	if origin == "" or origin[0] != "S":
		sys.exit("origin state of transition model query has to start with 'S'")
	if destination == "" or destination[0] != "S":
		sys.exit("destination state of transition model query has to start with 'S'")
	
	# origin and destination must be numbers (origin can be "init")
	try:
		origin = int(origin[1:])
	except:
		if origin == State.INIT_NAME:
			origin = None
		else:
			sys.exit("origin state of transition model query must be " + State.INIT_NAME + " or S<number>")
	try:
		destination = int(destination[1:])
	except:
		sys.exit("destination state of transition model query must be S<number>")
	
	# origin and destination must be in bounds 
	if origin != None and origin < 0:
		sys.exit("origin state of transition model query must be non negative")
	if origin != None and origin >= 2**len(contract.actions):
		sys.exit("origin state of transition model query must be less than 2**|actions|")
	if destination < 0:
		sys.exit("destination state of transition model query must be non negative")
	if destination >= 2**len(contract.actions):
		sys.exit("destination state of transition model query must be less than 2**|actions|")

	# action must be present (if origin is None ("init") it must be a constructor)
	if origin == None:
		action = contract.get_constructor(action)
		if action == None:
			sys.exit("action of transition model query must be a valid constructor name (since origin state is " + State.INIT_NAME + ")")
	else:
		action = contract.get_action(action)
		if action == None:
			sys.exit("action of transition model query must be a valid action name")

	# create origin state and check its consistency
	o_state = State.from_state_number(origin, contract)
	o_state_cvc = contract.cvc() + cvc_assert(o_state.invariant)
	prover_result = call_prover(o_state_cvc + cvc_check_satisfiability("TRUE"))
	if prover_result == "unsat":
		sys.exit("origin state of transition model query is not consistent")
	if prover_result == "unknown":
		sys.stderr.write("origin state of transition model query may not be consistent\n")
	
	# create destination state and check its consistency
	d_state = State.from_state_number(destination, contract)
	d_state_cvc = contract.cvc() + cvc_assert(d_state.invariant)
	prover_result = call_prover(d_state_cvc + cvc_check_satisfiability("TRUE"))
	if prover_result == "unsat":
		sys.exit("destination state of transition model query is not consistent")
	if prover_result == "unknown":
		sys.stderr.write("destination state of transition model query may not be consistent\n")
	
	# check if action is in origin enabled actions 
	if action not in o_state.enabled_actions:
		sys.exit("action of transition model query is not available in origin state")

	# construct query
	vs = [v for v in contract.variables] # shallow copy (_not_ an actual reference)
	cvc = o_state_cvc
	for parameter in action.parameters:
		vs.append(parameter)
		cvc += cvc_define_variable(parameter)
	cvc += cvc_assert(action.pre)
	for mod_var in action.mod_vars:
		mv = Variable(mod_var + "'", contract.get_variable(mod_var).type)
		vs.append(mv)
		cvc += cvc_define_variable(mv)
	cvc += cvc_assert(action.post)
	cvc += cvc_assert(cvc_prime_variables(d_state.invariant, action.mod_vars))
	
	# user restriction for variables
	cvc += cvc_assert(Options.options.query_restriction)
	
	prover_result = call_prover(cvc + "CHECKSAT;\n")
	if prover_result == "sat":  # TODO see if we can call prover only once here
		response = call_prover(cvc + "CHECKSAT;\nCOUNTERMODEL;\n")
		valuation = get_values_from_prover(vs, response)
		if origin != None:
			print "-- Values in S" + str(origin) + ":"
			for var in contract.variables:
				print "\t" + var.name + " = " + valuation[var.name]
			print
		if len(action.parameters) > 0:
			print "-- Values for parameters:"
			for par in action.parameters:
				print "\t" + par.name + " = " + valuation[par.name]
			print		
		print "-- Values in S" + str(destination) + ":"
		for var in contract.variables:
			if var.name + "'" in valuation:
				print "      * " + var.name + " = " + valuation[var.name + "'"]
			else:
				print "\t" + var.name + " = " + valuation[var.name]
			
	elif prover_result == "unknown":
		print "Could not determine if transition is possible."
	else:
		print "Transition is not possible."
