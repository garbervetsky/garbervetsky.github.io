# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys

# check if there are any actions that appear in the enabled set but they don't move the machine in any outgoing transition. that is a sign of a postcondition that is necessarily FALSE.
def postconditions_unsat(fsm):
	for state in fsm.states:
		for enabled_action in state.enabled_actions:
			if enabled_action.name not in [transition.action for transition in state.transitions]:
				sys.stderr.write("Action " + enabled_action.name + " is enabled in state " + str(state.name)  + " but it has a postcondition that is semantically equal to FALSE.\n")
				
# check if there are any actions that are not enabled on any state. that is a sign of a precondition that is necessarily FALSE.
def preconditions_unsat(contract, fsm):
	for action in contract.actions:
		appears = False
		for state in fsm.states:
			if action in state.enabled_actions:
				appears = True
				break
		if not appears:
			sys.stderr.write("Action " + action.name + " is not enabled on any state. It has a precondition that is semantically equal to FALSE.\n")

