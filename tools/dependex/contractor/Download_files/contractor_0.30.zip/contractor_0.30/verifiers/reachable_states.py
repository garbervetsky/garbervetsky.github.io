# -*- coding: iso-8859-15 -*-

# Contractor, a contract validation tool
#    Copyright (C) 2009  Guido de Caso, Alexis Tcach, Víctor Braberman, Diego Garbervetsky, Sebastián Uchitel
#    {gdecaso, atcach, vbraber, diegog, suchitel}@dc.uba.ar
#    LaFHIS - Departamento de Computación - Facultad de Ciencias Exactas y Naturales - Universidad de Buenos Aires
#    Pabellón I - Ciudad Universitaria - (C1428EGA) - Buenos Aires - Argentina
#    Tel: +54-11-4576-3390 eext. 704
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from stats.statistics import Statistics

def restrict_to_reachable_states(fsm):
	reachable_states = []
	work_list = [fsm.get_state(fsm.initial_state)]
	
	while len(work_list) > 0:
		state = work_list.pop()
		reachable_states.append(state)
		Statistics.states_add(1)
		Statistics.transitions_add(len(state.transitions))
		for transition in state.transitions:
			destination = fsm.get_state(transition.destination)
			if not destination in reachable_states and not destination in work_list:
				work_list.append(destination)
				
	fsm.states = reachable_states
