// http://cprogramminglanguage.net/singly-linked-list-c-source-code.aspx

#include <stdio.h>
#include <stdlib.h>

typedef int boolean;

typedef struct node{
	int data;
	struct node *next;
} node;

node* head;

boolean invariant() {
	return 1;
	// TODO: add non-cyclic-property invariant
}

boolean sys_pre_List() {
	return 1;
}
boolean par_pre_List() {
	return 1;
}
void List() {
	head = (node*) malloc(sizeof(node));
	if (head == 0) {
		printf("Error! memory is not available\n");
		return;
	}
	head->data = -1;
	head->next = head;
}

boolean sys_pre_add() {
	return head != 0;
}
boolean par_pre_add(int data) {
	return 1;
}
void add(int data){
	node *tmp = head;
	
	while (tmp->next != head)
		tmp = tmp->next;
		
	tmp->next = (node*) malloc(sizeof(node)); 
	if(tmp->next == 0) {
		printf("Error! memory is not available\n");
		destroy();
		return;
	}
	
	tmp = tmp->next;
	tmp->data = data;
	tmp->next = head;
}

boolean sys_pre_destroy() {
	return head != 0;
}
boolean par_pre_destroy() {
	return 1;
}
void destroy() 
{
	node* current;
	node* tmp;
	
	current = head->next;
	head->next = 0;
	while(current != 0) {
		tmp = current->next;
		free(current);
		current = tmp;
	}
	head = 0;
}

